---
source: https://pachulski.dev/course/backend-ops/
tags: [course/backend-ops]
---

# Backend and DevOps for Android developers

Build a bookmark service, survive a lost reply, ship a replacement and recover the data. Finish with a backend change and an operations incident report.

From [pachulski.dev](https://pachulski.dev/course/backend-ops/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Build the backend

Trace one write from the phone into durable storage.

- [[00 Which process answers the phone]]: Follow one bookmark from a client to the process that owns it.
- [[01 Did the first write happen]]: Make a lost reply safe to retry.
- [[02 Can two clients prove the rule]]: Test a retry through the running service and read what survived.

## Operate the service

Release, observe and recover the same service.

- [[03 Where does the data live during a release]]: Replace the running service while keeping its bookmark file.
- [[04 Alive, ready, or serving the wrong thing]]: Diagnose a storage failure and rehearse recovery.


[[Glossary]]
