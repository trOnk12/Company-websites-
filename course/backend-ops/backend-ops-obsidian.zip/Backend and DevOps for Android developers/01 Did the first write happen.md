---
course: "Backend and DevOps for Android developers"
puzzle: 1
source: https://pachulski.dev/course/backend-ops/01-retry
tags: [course/backend-ops]
---

# Did the first write happen?

> [!summary] The idea to keep
> A stable bookmark name and a unique database key let repeated writes converge on one row.

**Builds on:** [[00 Which process answers the phone]]

## The problem

The save route accepts a bookmark name. Your app times out after tapping Save. The phone cannot tell whether the server wrote the row just before the reply disappeared. What must stay the same on retry?

## See it

![Did the first write happen?](https://pachulski.dev/course/backend-ops/gifs/retry.gif)

Step through it: https://pachulski.dev/course/backend-ops/01-retry

## The building block

A **unique key** lets the database enforce one row per name, even when two callers write together. Use river as the identity of the desired bookmark. The database accepts at most one row for that name. The insert asks it to ignore a conflicting key. The handler waits for the transaction to commit before replying. The first insertion returns 201. Repeating the same write returns 200 and leaves one row. Checking for the row in application code and inserting later leaves a gap where two callers can both see it missing.

## Try it

Run both writes. Predict the list after a third write with a new name. Check it and explain which component enforces uniqueness.

[Open the runnable bookmark lab](https://github.com/trOnk12/Company-websites-/tree/main/labs/bookmark-service)

## Check yourself

#flashcards/backend-ops

What if the retry invents a fresh name?::A second row can be created. A stable bookmark name and a unique database key let repeated writes converge on one row.

## Sources

- [Technical reference](https://www.sqlite.org/lang_upsert.html)
