# Glossary: Backend and DevOps for Android developers

Every word the course teaches, in the order it does. #flashcards/backend-ops/words

route::The rule that pairs a request method and path with the code that handles it. (taught in [[00 Which process answers the phone]])

unique key::A database rule allowing only one row for a given identity. (taught in [[01 Did the first write happen]])

integration test::A test that exercises several real components together. (taught in [[02 Can two clients prove the rule]])

named volume::A storage location Docker can attach to successive containers. (taught in [[03 Where does the data live during a release]])

readiness probe::A check that asks whether an instance can currently serve its expected work. (taught in [[04 Alive, ready, or serving the wrong thing]])
