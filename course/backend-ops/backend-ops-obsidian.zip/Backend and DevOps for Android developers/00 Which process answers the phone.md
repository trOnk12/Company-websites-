---
course: "Backend and DevOps for Android developers"
puzzle: 0
source: https://pachulski.dev/course/backend-ops/00-request
tags: [course/backend-ops]
---

# Which process answers the phone?

> [!summary] The idea to keep
> A route matches the method and path before a handler runs.

## The problem

Your Android screen already calls a repository. Move the write behind a network connection. Which program now decides whether the requested bookmark exists?

## See it

![Which process answers the phone?](https://pachulski.dev/course/backend-ops/gifs/request.gif)

Step through it: https://pachulski.dev/course/backend-ops/00-request

## The building block

A **route** pairs a request method and path with the code that handles it. Start the lab server in one terminal. In another, send the first write from the lab guide. The server listens on port 8080. Its handler receives the method and path and checks the name. A valid write returns a status and the saved name. Change only the path to /unknown. The server can answer 404 because the request reached it. Stop the process and repeat. Now the client cannot connect to that port, so there is no response status.

## Try it

Compare the wrong-path response with the stopped-process result. Save both outputs.

[Open the runnable bookmark lab](https://github.com/trOnk12/Company-websites-/tree/main/labs/bookmark-service)

## Check yourself

#flashcards/backend-ops

After stopping the only listener, what arrives?::A connection error. A route matches the method and path before a handler runs.

## Sources

- [Technical reference](https://docs.python.org/3/library/http.server.html)
