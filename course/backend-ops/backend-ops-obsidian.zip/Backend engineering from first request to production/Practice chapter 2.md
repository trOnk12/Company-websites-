# Build and roll out a service under resource limits

## What exactly is inside the image you deploy?

A multi-stage Docker build separates compilation from the runtime filesystem. Each FROM begins a stage. COPY --from transfers named outputs from one stage into another. The final stage still needs every runtime dependency required by the distributed application.

### Worked example

Compile a JVM service with a JDK in the build stage and copy its application artifact into a runtime stage with a suitable Java runtime. Start the final image against a disposable database, wait for readiness, send a write, restart and read the row. A passing test in the build stage did not exercise that runtime filesystem.

### Try it

The final image starts but fails only when exporting a report. Which check would expose the packaging mistake?

### Compare your answer

Exercise that path in the final image and inspect the missing dependency, file or permission it reports. Ensure the exact tested image digest is promoted. Rebuilding the same tag between verification and rollout can change what is shipped.

[Source · Docker · Multi-stage builds](https://docs.docker.com/build/building/multi-stage/)

## Why can a healthy rollout temporarily need more capacity?

A rolling Deployment scales a new ReplicaSet up while scaling the old one down. maxSurge controls extra pods and maxUnavailable controls permitted unavailability during the update. A new pod that has started may still be unready. Scheduling capacity and probe behavior therefore affect rollout progress.

### Worked example

Start with four ready replicas, maxSurge=1 and maxUnavailable=0. The controller can create one replacement while retaining all four ready old pods. If that new pod cannot be scheduled, the rollout can stall without reducing the existing four ready replicas. Inspect scheduling events and availability separately.

### Try it

The new pod is scheduled and starts, but its readiness check never succeeds. Would more space in the cluster solve this case?

### Compare your answer

Inspect the readiness failure, its configuration and the dependency it checks. Extra scheduling capacity addressed a different failure. Verify that old and new versions can coexist with the current database schema before resuming or rolling back.

[Source · Kubernetes · Deployments](https://kubernetes.io/docs/concepts/workloads/controllers/deployment/)

## Why can a pod be pending while a node looks idle?

The scheduler evaluates resource requests when choosing a placement. CPU utilization at one instant is a different measurement. Resource limits constrain a running container: CPU limits can throttle it and exceeding a memory limit under pressure can cause termination.

### Worked example

A node with 2 allocatable CPU cores already has 1.6 cores requested. A new pod requests 0.6 cores and no other node fits. Even if current CPU use is only 0.3 cores, adding the pod would bring requests to 2.2. Describe this as a scheduling constraint before changing limits.

### Try it

A pod runs, periodically times out under load and never restarts. What evidence distinguishes CPU throttling from a slow database?

### Compare your answer

Compare throttling metrics and CPU demand with database checkout and query latency over the same interval. Reproduce under a controlled request mix and adjust one limit at a time. Low average CPU across a minute can hide short bursts.

[Source · Kubernetes · Resource management](https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/)

[[Practice chapter 3|Follow one booking through Spring MVC and a database transaction]]

[[Course map]]