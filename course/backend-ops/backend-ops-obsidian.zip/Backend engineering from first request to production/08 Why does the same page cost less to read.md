---
course: "Backend engineering from first request to production"
puzzle: 8
source: https://pachulski.dev/course/backend-ops/08-query
tags: [course/backend-ops]
---

# Why does the same page cost less to read?

> [!summary] The idea to keep
> An index matching the owner and sort order can serve the same page with less searching and sorting.

**Builds on:** [[00 What happens when a client sends a request]]

## The problem

A route lists five recent bookmarks. Reading five rows sounds cheap. What if the database must inspect two thousand candidates first?

## See it

![Why does the same page cost less to read?](https://pachulski.dev/course/backend-ops/gifs/query.gif)

Step through it: https://pachulski.dev/course/backend-ops/08-query

## The building block

The data drill generates repeated timestamps and several owners. The query filters by owner and sorts by time, then by a unique row number to settle ties. Without a matching index the database scans the table and uses temporary storage for sorting in this example. An index arranged by owner, time and row number can locate the matching range in order. Compare the plans and the actual rows. Extra indexes occupy space and must be maintained on writes. For the next page, carry the last time and row number together and continue below that pair using the same ordering.

## Try it

Run the data drills, inspect both plans and implement a second page. Check that two tied rows across the page boundary are each returned once.

[Open the local exercise](https://github.com/trOnk12/Company-websites-/tree/main/labs/bookmark-service#data-drills)

## Check yourself

#flashcards/backend-ops

Two bookmarks share a time. What belongs in the page cursor?::Time and the unique row number. An index matching the owner and sort order can serve the same page with less searching and sorting.

## Sources

- [Technical reference](https://www.sqlite.org/queryplanner.html)
