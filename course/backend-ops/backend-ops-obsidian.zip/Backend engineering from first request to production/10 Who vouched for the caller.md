---
course: "Backend engineering from first request to production"
puzzle: 10
source: https://pachulski.dev/course/backend-ops/10-session
tags: [course/backend-ops]
---

# Who vouched for the caller?

> [!summary] The idea to keep
> Session expiry and resource ownership answer different questions.

**Builds on:** [[00 What happens when a client sends a request]]

## The problem

Ada can read river before lunch. After the session expires she asks for the same row. What changed if the database row is identical?

## See it

![Who vouched for the caller?](https://pachulski.dev/course/backend-ops/gifs/session.gif)

Step through it: https://pachulski.dev/course/backend-ops/10-session

## The building block

After a successful sign-in, a service may issue a session identifier and keep its owner and expiry on the server. On each protected route it checks the session and then the permission for the resource. The workbench starts with invented session records. An unknown or expired record yields 401. In this exercise a known user without permission gets 403. A real login also needs secure credential handling, protected transport and a revocation policy. Use an established identity provider when implementing the portfolio version.

## Try it

Freeze time one tick before expiry and then exactly at expiry. Revoke a fixture and show that a subsequent request requires authentication.

[Open the local exercise](https://github.com/trOnk12/Company-websites-/tree/main/labs/bookmark-service#core-workbench)

## Check yourself

#flashcards/backend-ops

The session expired but the owner still matches. What happens?::Require fresh authentication. Session expiry and resource ownership answer different questions.

## Sources

- [Technical reference](https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html)
