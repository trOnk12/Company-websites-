---
source: https://pachulski.dev/course/backend-ops/
tags: [course/backend-ops]
---

# Backend engineering from first request to production

Learn to design, build, test and operate a bookmark API. Start with a local request, then work through databases, identity, caching, Docker, Kubernetes and a release project.

From [pachulski.dev](https://pachulski.dev/course/backend-ops/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Build and test your first service

Start with one request, one durable row and a test.

- [[00 What happens when a client sends a request]]: Follow one bookmark from a client to the process that owns it.
- [[01 Did the first write happen]]: Make a lost reply safe to retry.
- [[02 Can two clients prove the rule]]: Test a retry through the running service and read what survived.

## Release and recover a first version

Follow the same row through a release and a storage incident.

- [[03 Where does the data live during a release]]: Replace the running service while keeping its bookmark file.
- [[04 Alive, ready, or serving the wrong thing]]: Diagnose a storage failure and rehearse recovery.

## API contracts and relational databases

Validate inputs, model owners, commit related changes and paginate results.

- [[05 Can an old client read the new response]]: Define the shape and meaning of a request before changing it.
- [[06 Can a bookmark point to a missing owner]]: Model relationships and query accounts that have no saved rows.
- [[07 What if the service stops between two writes]]: Save the bookmark and the work it creates together.
- [[08 Why does the same page cost less to read]]: Inspect a query plan before and after adding an index.

## Identity and changes over time

Limit access by owner, expire sessions, refresh caches and migrate data.

- [[09 Whose bookmark may this request read]]: Trace identity from the caller to the storage query.
- [[10 Who vouched for the caller]]: Follow a session from an identity check to permission on one row.
- [[11 When does a reader see yesterday’s list]]: Predict the exact interval during which a saved response can be stale.
- [[12 Can two releases share one schema]]: Change the shape of stored data while an older reader is still running.

## Docker, Kubernetes and production operations

Package the service, replace a pod, measure performance and deliver your final project.

- [[13 What goes in a Docker image]]: Predict which files a replacement container can read and write.
- [[14 Who replaces a missing pod]]: Watch a local cluster restore a process and inspect what survives.
- [[15 Which users felt the slowdown]]: Compare request durations, failures and resource pressure.
- [[16 What evidence earns a release]]: Ship a change with tests, a recovery path and a capacity argument.

## Concurrent edits

A check at save time that detects a change since the client read a record.

- [[17 What does the second editor see]]: Follow two clients editing the same saved title.

## Practice chapters

- [[Practice chapter 1|Reading production evidence]]
- [[Practice chapter 2|Build and roll out a service under resource limits]]
- [[Practice chapter 3|Follow one booking through Spring MVC and a database transaction]]
- [[Practice chapter 4|Diagnose a running Docker container]]
- [[Practice chapter 5|Build a SQL report that survives awkward data]]

[[Final project]]


[[Glossary]]
