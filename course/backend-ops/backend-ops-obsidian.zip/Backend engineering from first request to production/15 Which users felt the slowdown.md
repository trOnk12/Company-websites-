---
course: "Backend engineering from first request to production"
puzzle: 15
source: https://pachulski.dev/course/backend-ops/15-signals
tags: [course/backend-ops]
---

# Which users felt the slowdown?

> [!summary] The idea to keep
> A percentile describes an ordered sample. Averages can hide a slow group.

**Builds on:** [[00 What happens when a client sends a request]]

## The problem

**Response time** is elapsed time from sending a request to receiving its response. A route usually answers in ten milliseconds. Six of a hundred requests now take two hundred. Which measurement exposes the slow group?

## See it

![Which users felt the slowdown?](https://pachulski.dev/course/backend-ops/gifs/signals.gif)

Step through it: https://pachulski.dev/course/backend-ops/15-signals

## The building block

Sort the hundred timings. Using nearest rank, the ninety-fifth percentile is the value at position 95. Here it is 200 milliseconds even though the mean is only 21.4. Record request count and failures separately. A fast error can lower mean response time while availability worsens. A log gives details for one event, a metric aggregates events, and a trace connects steps of one request. Compare a database span with total request time before blaming the database.

## Try it

Run the response-time fixture. Reduce the slow group to five and predict the nearest-rank result. Write a service objective with a time window and an error threshold.

[Open the local exercise](https://github.com/trOnk12/Company-websites-/tree/main/labs/bookmark-service#core-workbench)

## Check yourself

#flashcards/backend-ops

All failed requests return quickly. Which signal is essential alongside response time?::The fraction of failed requests. A percentile describes an ordered sample. Averages can hide a slow group.

## Sources

- [Technical reference](https://sre.google/sre-book/monitoring-distributed-systems/)
