---
course: "Backend engineering from first request to production"
puzzle: 7
source: https://pachulski.dev/course/backend-ops/07-commit
tags: [course/backend-ops]
---

# What if the service stops between two writes?

> [!summary] The idea to keep
> A transaction can commit both the bookmark and a pending event, or roll back both.

**Builds on:** [[00 What happens when a client sends a request]]

## The problem

Your save route writes river. A second write records that a worker should announce it. The process stops between those writes. What should the next process find?

## See it

![What if the service stops between two writes?](https://pachulski.dev/course/backend-ops/gifs/commit.gif)

Step through it: https://pachulski.dev/course/backend-ops/07-commit

## The building block

A transaction groups database changes behind one commit. Put the saved row and the pending event in the same database transaction. A failure before commit leaves neither change. A successful commit makes both available. A worker can deliver the pending event afterward. If it sends successfully but stops before recording completion, it may send again. Give the event a stable identity. The consumer can record that identity and a database effect together to avoid applying that effect twice. Sending an email introduces another system and needs its own delivery contract.

### Move the crash one statement at a time

Think of the event as a durable to-do note named E17. With separate commits, a crash after saving river can leave a bookmark and no E17. The worker can never discover the missing note by polling its event table. In one transaction, a crash before commit discards both writes; after commit, the worker can find E17 again after restart. This is the **transactional outbox** pattern. A later crash after sending but before marking E17 delivered creates a different problem: the worker knows it owes delivery, but cannot tell whether the receiver already acted.

## Try it

[Run the browser experiment](https://pachulski.dev/labs/backend-workbench/#07-commit)

### Optional local lab

Run the data drills. Move the pending insert to a second transaction in a disposable copy. Stop between commits and inspect both tables.

[Open the local exercise files](https://github.com/trOnk12/Company-websites-/tree/main/labs/bookmark-service#data-drills)

## Check yourself

#flashcards/backend-ops

The worker loses the acknowledgement. Which value should a second delivery reuse?::The original event identity. A transaction can commit both the bookmark and a pending event, or roll back both.

Which database state contradicts the promise that every saved bookmark schedules delivery?::River exists but its pending event was never recorded. A committed bookmark must have scheduled its event.

Where must a consumer record an event identity to guard a local balance update against repeats?::In the same transaction as the balance update. The deduplication decision and the protected effect must survive a crash together.

## Sources

- [Technical reference](https://www.sqlite.org/lang_transaction.html)
