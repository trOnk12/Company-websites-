---
course: "Backend engineering from first request to production"
puzzle: 2
source: https://pachulski.dev/course/backend-ops/02-test
tags: [course/backend-ops]
---

# Can two clients prove the rule?

> [!summary] The idea to keep
> An integration test can check replies, stored state and persistence across a fresh process.

**Builds on:** [[01 Did the first write happen]]

## The problem

A test double standing in for the database can return success without writing anything. How would a reviewer know your server actually preserved the bookmark?

## See it

![Can two clients prove the rule?](https://pachulski.dev/course/backend-ops/gifs/test.gif)

Step through it: https://pachulski.dev/course/backend-ops/02-test

## The building block

An **integration test** checks several real components together. Here the client, server and database all run. Run the supplied test. It creates an empty database, starts the server and sends two writes with the same name from separate workers. It expects one creation and one existing result in either order. It stops the process, starts another against the same file and reads back the list. This distinguishes a durable write from a value held only in memory. Two workers exercise contention without proving correctness for every possible ordering. The unique key provides the underlying guarantee.

## Try it

Complete the deletion assignment in the lab. Show that removing the row survives a restart and that a second delete follows your documented contract.

[Open the runnable bookmark lab](https://github.com/trOnk12/Company-websites-/tree/main/labs/bookmark-service)

## Check yourself

#flashcards/backend-ops

Both calls return a success status. What evidence is still missing?::The saved rows after restart. An integration test can check replies, stored state and persistence across a fresh process.

## Sources

- [Technical reference](https://docs.python.org/3/library/sqlite3.html)
