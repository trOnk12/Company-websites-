# Diagnose a running Docker container

## Why does localhost work in one container and fail in its neighbor?

A port belongs to a listening process at a network address. With ordinary bridge networking, each container has its own loopback address. On a user-defined Docker bridge, peers can also resolve each other's container names. Publishing a port sets up a host entry point. Two containers on the same bridge can talk directly to a listening service without publishing it.

### Worked example

On a machine with Docker Engine running Linux containers, create an isolated exercise network with `docker network create course-peer-net`. Start a tiny server with `docker run -d --name course-peer-web --network course-peer-net busybox:1.36 sh -c 'echo READY > /tmp/index.html && exec httpd -f -p 8080 -h /tmp'`. No host port is published. Inside the server, `docker exec course-peer-web wget -qO- http://127.0.0.1:8080` prints READY.

### Try it

Start a second container with `docker run --rm --network course-peer-net busybox:1.36 wget -qO- http://course-peer-web:8080`. Predict the result. Repeat with 127.0.0.1 in place of course-peer-web. Which machine would have to be listening for that second command to succeed?

### Compare your answer

The name reaches the server and prints READY. Loopback reaches the short-lived client container, where nothing serves port 8080. Publishing the server port would leave the meaning of the client's loopback unchanged. Remove the exercise server with `docker rm -f course-peer-web`, then remove its bridge with `docker network rm course-peer-net`.

[Source · Docker · User-defined bridge networks](https://docs.docker.com/engine/network/drivers/bridge/)

## Where did the image's welcome page go?

A mount places a second filesystem at a path. Opening a file under that path now searches the mounted directory. Files from the underlying image can still be in the image even when the running process cannot see them. Docker normally copies existing image files into a newly mounted empty volume. The volume-nocopy option suppresses that initialization.

### Worked example

Read the original page size with `docker run --rm nginx:alpine wc -c /usr/share/nginx/html/index.html`. You should see a positive byte count. Create a fresh exercise volume with `docker volume create course-empty-web`. Use a new name if that volume already exists. Run `docker run --rm --mount type=volume,src=course-empty-web,dst=/usr/share/nginx/html,volume-nocopy nginx:alpine ls -A /usr/share/nginx/html`. The empty listing describes the mounted volume.

### Try it

Repeat the original byte-count command without the mount. Predict whether the file returns. Then run the listing with a second fresh volume named course-seeded-web and omit volume-nocopy. Explain both results before changing any Dockerfile.

### Compare your answer

The image-only container still finds index.html. The second fresh volume receives the image's files on its first ordinary mount. Rebuilding the image would not fix a deployment mounting an existing volume with the wrong contents. Check the mount destination and the actual contents. Release these exercise volumes with `docker volume rm course-empty-web course-seeded-web`.

[Source · Docker · Mounting a volume over existing data](https://docs.docker.com/engine/storage/volumes/)

## What can a worker finish during docker stop?

Stopping a container gives its main process a chance to finish. With the default stop signal Docker sends SIGTERM. After the configured timeout it can force termination with SIGKILL. A worker needs a shutdown policy for any job already in progress. Here the job is a two-second cleanup that announces its beginning and end.

### Worked example

Use a disposable worker. Run `docker run -d --name course-drain busybox:1.36 sh -c 'trap "echo draining; sleep 2; echo finished; exit 0" TERM; echo ready; while :; do sleep 1; done'`. Wait until `docker logs course-drain` shows ready. Run `docker stop -t 6 course-drain`, then inspect its logs and exit status with `docker inspect --format '{{.State.ExitCode}}' course-drain`.

### Try it

After the successful run, use `docker start course-drain`. Wait for a second ready line before repeating with `docker stop -t 1 course-drain`. Which output marks completed cleanup? Can the first line of cleanup prove a job was committed?

### Compare your answer

Six seconds allows this fixture to print finished and exit with zero under ordinary scheduling. One second cannot cover the two-second cleanup. The forced stop usually yields 137 and no second finished line. A production worker should record its durable outcome and acknowledge its job according to that outcome. A log line announcing cleanup establishes only that the handler began. Remove the stopped fixture with `docker rm course-drain`.

[Source · Docker · Container stop signals and timeout](https://docs.docker.com/reference/cli/docker/container/stop/)

[[Practice chapter 5|Build a SQL report that survives awkward data]]

[[Course map]]