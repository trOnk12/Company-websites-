# Glossary: Backend engineering from first request to production

Every word the course teaches, in the order it does. #flashcards/backend-ops/words

Hypertext Transfer Protocol::The rules clients and servers use to exchange requests and responses. (taught in [[00 What happens when a client sends a request]])

route::The rule that pairs a request method and path with the code that handles it. (taught in [[00 What happens when a client sends a request]])

status code::A number describing the outcome of a request. (taught in [[00 What happens when a client sends a request]])

SQL::A language for working with tables in a relational database. (taught in [[01 Did the first write happen]])

unique key::A database rule allowing only one row for a given identity. (taught in [[01 Did the first write happen]])

integration test::A test that exercises several real components together. (taught in [[02 Can two clients prove the rule]])

named volume::A storage location Docker can attach to successive containers. (taught in [[03 Where does the data live during a release]])

readiness probe::A check that asks whether an instance can currently serve its expected work. (taught in [[04 Alive, ready, or serving the wrong thing]])

application programming interface::The interface a program offers to its callers. (taught in [[05 Can an old client read the new response]])

JavaScript Object Notation::A text format for structured values. (taught in [[05 Can an old client read the new response]])

pod::A unit scheduled by Kubernetes that can hold one or more containers. (taught in [[14 Who replaces a missing pod]])

response time::Elapsed time for a request to receive a response. (taught in [[15 Which users felt the slowdown]])

ETag::A response field that labels the version of the representation sent. (taught in [[17 What does the second editor see]])

header::A named field carrying information about a request or response. (taught in [[17 What does the second editor see]])

optimistic locking::A check at save time that detects a change since the client read a record. (taught in [[17 What does the second editor see]])
