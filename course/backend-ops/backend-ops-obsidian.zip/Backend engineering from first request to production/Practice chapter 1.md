# Reading production evidence

## Which index matches the question?

A B-tree orders keys lexicographically. In an index on (owner_id, created_at, id), entries for each owner are contiguous. The next two columns order that owner's bookmarks and break timestamp ties. A query can seek to the owner and a cursor boundary, then stop when it has enough rows.

### Worked example

For owner 7, two bookmarks have the same timestamp and IDs 31 and 32. Order by created_at DESC, id DESC. A page ending at (T,32) must admit (T,31) on the next page. The predicate (created_at,id) < (T,32), combined with owner_id = 7, preserves that boundary. A strict timestamp-only predicate skips ID 31.

### Try it

Would this index also be your first choice for listing the latest ten bookmarks across every owner?

### Compare your answer

The leading owner key groups entries by owner. A global time-ordered feed has a different access pattern. Compare plans and representative loads for an index beginning with created_at and id. Include the storage and write cost of maintaining another index.

[Source · PostgreSQL · Multicolumn indexes](https://www.postgresql.org/docs/17/indexes-multicolumn.html)

## What is a query plan counting?

A plan is a tree of operations chosen by the database. Estimates guide that choice. EXPLAIN ANALYZE runs the statement and reports measurements. Inspect the first large divergence in row estimates, and remember that actual rows at a node with multiple loops are reported as a per-loop average.

### Worked example

A nested loop finds 200 owners and probes bookmarks once per owner. The inner node says actual rows=5 loops=200. It returned about 1,000 rows across its invocations. If the estimate was one row per probe, the work diverged by roughly five times there. A ten-row development table cannot reproduce the distribution of a few very large owners.

### Try it

Your colleague adds the times of every parent and child node to explain total latency. What would you measure instead?

### Compare your answer

Parent time includes child work, so that sum double-counts it. Record the top-level execution time, inspect the costly subtree, and compare equivalent runs with the same inputs and cache conditions. Use buffers and representative distributions to test the proposed explanation.

[Source · PostgreSQL · Using EXPLAIN](https://www.postgresql.org/docs/17/using-explain.html)

## Should the platform restart this process?

A startup probe grants a slow-starting container time to initialize before the other probes take over. Readiness controls eligibility to receive service traffic. Persistent liveness failure tells the kubelet to restart the container according to its restart policy. A probe therefore encodes a recovery decision, not just a health label.

### Worked example

Six pods share a database. For thirty seconds the database refuses connections. Restarting all six application processes cannot restore that dependency and adds startup load. Choose whether these pods can still serve meaningful requests. Test a readiness policy against that contract, and reserve a liveness failure for a condition a restart can plausibly fix.

### Try it

A pod passes its HTTP readiness probe after a rollback. What evidence would let you declare bookmark writes recovered?

### Compare your answer

Send a representative synthetic write, read it through another eligible instance, and verify its owner and contents. Observe user error rates during the same window. A successful probe establishes only that its specific check passed.

[Source · Kubernetes · Container probes](https://kubernetes.io/docs/concepts/workloads/pods/probes/)

[[Practice chapter 2|Build and roll out a service under resource limits]]

[[Course map]]