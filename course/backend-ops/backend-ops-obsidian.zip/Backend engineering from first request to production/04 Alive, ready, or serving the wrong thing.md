---
course: "Backend engineering from first request to production"
puzzle: 4
source: https://pachulski.dev/course/backend-ops/04-incident
tags: [course/backend-ops]
---

# Alive, ready, or serving the wrong thing?

> [!summary] The idea to keep
> A process can answer a simple probe while its storage path fails.

**Builds on:** [[00 What happens when a client sends a request]]

## The problem

The process is running and the phone still gets errors. Should the operator restart the program, replace its image or investigate storage first?

## See it

![Alive, ready, or serving the wrong thing?](https://pachulski.dev/course/backend-ops/gifs/incident.gif)

Step through it: https://pachulski.dev/course/backend-ops/04-incident

## The building block

A **readiness probe** asks whether an instance can currently serve its expected work. The live route only proves the handler can answer. The ready route reads from the bookmark table. In the disposable incident drill, rename the table while the process runs. Live still returns 200. Ready and bookmark writes return 503. The server log points to storage. Restore the table and retry a real write. A successful read probe alone cannot prove that a disk accepts writes. For a code regression with a compatible database, practice starting the previous image and checking the saved row.

### Read the incident as a sequence of observations

At 10:00, a bookmark write succeeds. After a table rename, the same write fails and the readiness response changes from 200 to 503. The live response stays at 200. Those observations point to the work performed by the ready route after it reaches storage. Replacing the image still leaves the renamed table in the database. In the local drill restore the original name, send a new write, then read its exact value. Keep the old sample too: reading only the new row would miss accidental loss of the earlier data.

## Try it

[Run the browser experiment](https://pachulski.dev/labs/backend-workbench/#04-incident)

### Optional local lab

Run the incident drill. Write a short incident report and rehearse the rollback. Include one condition under which reverting the image would be insufficient.

[Open the local service source files](https://github.com/trOnk12/Company-websites-/tree/main/labs/bookmark-service)

## Check yourself

#flashcards/backend-ops

The read probe succeeds after recovery. What should you verify next?::A real write and its stored result. A process can answer a simple probe while its storage path fails.

Both versions fail on the same renamed table. Which change addresses that observation?::Restore the table layout the versions expect. The incompatible layout persists across restarts.

Why keep the bookmark written before the incident as a test case?::It detects loss of earlier data. A successful new write can coexist with missing old rows.

## Sources

- [Technical reference](https://docs.docker.com/engine/storage/volumes/)
