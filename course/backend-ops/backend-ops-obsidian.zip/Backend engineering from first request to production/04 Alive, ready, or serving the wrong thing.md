---
course: "Backend engineering from first request to production"
puzzle: 4
source: https://pachulski.dev/course/backend-ops/04-incident
tags: [course/backend-ops]
---

# Alive, ready, or serving the wrong thing?

> [!summary] The idea to keep
> A process can answer a simple probe while its storage path fails.

**Builds on:** [[00 What happens when a client sends a request]]

## The problem

The process is running and the phone still gets errors. Should the operator restart the program, replace its image or investigate storage first?

## See it

![Alive, ready, or serving the wrong thing?](https://pachulski.dev/course/backend-ops/gifs/incident.gif)

Step through it: https://pachulski.dev/course/backend-ops/04-incident

## The building block

A **readiness probe** asks whether an instance can currently serve its expected work. The live route only proves the handler can answer. The ready route reads from the bookmark table. In the disposable incident drill, rename the table while the process runs. Live still returns 200. Ready and bookmark writes return 503. The server log points to storage. Restore the table and retry a real write. A successful read probe alone cannot prove that a disk accepts writes. For a code regression with a compatible database, practice starting the previous image and checking the saved row.

### Read the incident as a sequence of observations

At 10:00, a bookmark write succeeds. After a table rename, the same write fails and the readiness response changes from 200 to 503. The live response stays at 200. Those observations point to the work performed by the ready route after it reaches storage. Compare two branches from that failure. Before restarting, restoring the original table name makes river visible again. Restarting instead runs the startup routine: it creates an empty bookmarks table because that name is free. Readiness now returns 200 and a new write can succeed, while river is still in the renamed table. Check both identities. Once new writes exist in the replacement table, preserve both tables and reconcile their contents; a blind rename is no longer a complete recovery.

## Try it

[Run the browser experiment](https://pachulski.dev/labs/backend-workbench/#04-incident)

### Optional local lab

Run the incident drill. Write a short incident report and rehearse the rollback. Include one condition under which reverting the image would be insufficient.

[Open the local service source files](https://github.com/trOnk12/Company-websites-/tree/main/labs/bookmark-service)

## Check yourself

#flashcards/backend-ops

The read probe succeeds after recovery. What should you verify next?::A real write and its stored result. A process can answer a simple probe while its storage path fails.

After restarting, readiness returns 200 but river is missing from the list. Where should you look?::In the renamed table that held river. A successful probe checked the replacement table.

Why keep the bookmark written before the incident as a test case?::It detects loss of earlier data. A successful new write can coexist with missing old rows.

## Sources

- [Technical reference](https://docs.docker.com/engine/storage/volumes/)
