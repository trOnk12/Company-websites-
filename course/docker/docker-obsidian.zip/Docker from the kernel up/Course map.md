---
source: https://pachulski.dev/course/docker/
tags: [course/docker]
---

# Docker from the kernel up

What a container really is underneath docker run: one ordinary Linux process, fenced in by namespaces and held to limits by cgroups, on the same kernel as everything else. Every puzzle shows real output from a real machine, and you can run the same commands yourself. For Android and Kotlin engineers who use Docker but have never looked under it.

From [pachulski.dev](https://pachulski.dev/course/docker/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: What a container really is

Find a container's program in the host's process list, compare it with a virtual machine, then open the fence one piece at a time: process IDs, files, hostname and network, users and capabilities, memory limits, processor time, and finally who builds it all when you type docker run.

- [[00 A container is a process]]: Docker starts a program for you. Find that program on the machine, and see the one thing that makes it different from every other program running there.
- [[01 One kernel, or many]]: Puzzle 0's container is a process on the host's kernel. So which kernel does it really use, the host's or one that came with its image? And how is that different from a virtual computer?
- [[02 Whose PID 1]]: Inside puzzle 0's container, sleep was PID 1; on the host, the same process was 3393. Here's how one process gets two numbers, and why it can't see anything outside.
- [[03 A file tree of its own]]: Puzzle 1's Alpine container read a different /etc/os-release from the host's, on the same kernel. Here's the second fence: how a process gets its own file tree, and where a container's tree comes from.
- [[04 A namespace per resource]]: Puzzles 2 and 3 fenced off process IDs and files. A program also reads its machine's name and talks through the network. Here's how to read, for any process, which fences it has, and what two more of them change.
- [[05 Root in the container is root on the host]]: Puzzle 4's table showed one link that matched the host's, user. Here's what that one equal number means when a container's program touches a file on the host, and the namespace that would change it.
- [[06 How much memory may it use]]: The namespaces of puzzles 2 to 5 decide what a container can see. Nothing so far stops it from taking all of the machine's memory. Here's the other half of the fence, what happens at its edge, and why the program inside never sees it.
- [[07 How much processor time]]: Puzzle 6's cgroup held memory to a limit. Processor time is the other thing a busy container takes from its neighbours. Here's how the same group limits it, and why a limited container can wait while the processors sit idle.
- [[08 Who builds the container]]: Puzzles 0 to 7 took the fence apart: namespaces and a cgroup around one process. Somebody asks the kernel for all of it when you type docker run. Here's the chain of programs that does, and the one file that describes the whole container.

[[Final project]]

## Coming next

- Module 2: Images (coming): Layers as stacked file changes, overlayfs (lower and upper directories, copy-up, whiteouts), overlay2 versus the containerd image store, the writable layer, content-addressed digests versus movable tags, registries (pulling, authentication, mirrors, rate limits), and the OCI image spec: index, manifest, config, layers and referrers.
- Module 3: The Dockerfile and the build (coming): Which instructions make layers, the build context and .dockerignore, the build cache's rules, multi-stage builds, BuildKit (cache and secret mounts, remote caches, bake), reproducible builds, and provenance and SBOM attestations.
- Module 4: Running a container well (coming): PID 1 and signals, exec form versus shell form, docker stop's grace period and --init, exit codes (128 + signal, OOMKilled), restart policies and health checks, logs and their drivers (json-file needs max-size), and ulimits.
- Module 5: Data and networking (coming): Volumes versus bind mounts versus tmpfs, the bridge network and veth pairs, publishing ports through iptables or nftables, user-defined networks and the embedded DNS, host, none and macvlan, IPv6, Compose, and rootless networking.
- Module 6: Limits and failures (coming): cgroup v2 first: the OOM kill in depth (memory.events), memory.high, pressure stall information, CPU weight versus quota and throttling, io.max, a JVM in a container, PIDs limits, and disk space and prune.
- Module 7: Security (coming): Non-root users, capabilities, --privileged and no-new-privileges, seccomp, AppArmor and SELinux, devices, read-only filesystems, rootless mode and idmapped mounts, secrets in env and inspect, scanning, SBOMs and signing with cosign or Notation, and the Docker socket.
- Module 8: Small, fast images, and Docker in your own work (coming): Distroless and Alpine trade-offs (musl versus glibc), layer ordering, multi-architecture images with buildx, an Android Gradle build in a container, Testcontainers for Kotlin tests, Docker in CI, and Docker Desktop for Mac users.
- Module 9: To production (coming): Promoting an image by digest, a bridge to Kubernetes pods and CRI, debugging a running container (exec, inspect, nsenter, a debug container), a container that won't start, live restore and daemon upgrades, and rebuilding for security fixes.

[[Glossary]]
