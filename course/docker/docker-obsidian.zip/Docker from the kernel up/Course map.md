---
source: https://pachulski.dev/course/docker/
tags: [course/docker]
---

# Docker from the kernel up

What a container really is underneath docker run: one ordinary Linux process, fenced in by namespaces and held to limits by cgroups, on the same kernel as everything else. Every puzzle shows real output from a real machine, and you can run the same commands yourself. For Android and Kotlin engineers who use Docker but have never looked under it.

From [pachulski.dev](https://pachulski.dev/course/docker/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: What a container really is

Find a container's program in the host's process list, compare it with a virtual machine, then open the fence one piece at a time: process IDs, files, hostname and network, users, resource limits, and finally who builds it all when you type docker run.

- [[00 A container is a process]]: Docker starts a program for you. Find that program on the machine, and see the one thing that makes it different from every other program running there.
- [[01 One kernel, or many]]: Puzzle 0's container is a process on the host's kernel. So which kernel does it really use, the host's or one that came with its image? And how is that different from a virtual computer?
- [[02 Whose PID 1]]: Inside puzzle 0's container, sleep was PID 1; on the host, the same process was 3393. Here's how one process gets two numbers, and why it can't see anything outside.
- [[03 A file tree of its own]]: Puzzle 1's Alpine container read a different /etc/os-release from the host's, on the same kernel. Here's the second fence: how a process gets its own file tree, and where a container's tree comes from.
- [[04 A namespace per resource]]: Puzzles 2 and 3 fenced off process IDs and files. A program also reads its machine's name and talks through the network. Here's how to read, for any process, which fences it has, and what two more of them change.
- [[05 Root in the container is root on the host]]: Puzzle 4's table showed one link that matched the host's, user. Here's what that one equal number means when a container's program touches a file on the host, and the namespace that would change it.
- [[06 How much may it use]]: The namespaces of puzzles 2 to 5 decide what a container can see. Nothing so far stops it from taking all of the machine's memory or processor time. Here's the other half of the fence, and what happens at its edge.
- [[07 Who builds the container]]: Puzzles 0 to 6 took the fence apart: namespaces and a cgroup around one process. Somebody asks the kernel for all of it when you type docker run. Here's the chain of programs that does, and the one file that describes the whole container.

[[Final project]]

## Coming next

- Module 2: Images (coming): Layers as stacked file changes, the union filesystem (overlayfs: lower and upper directories, copy-up, whiteouts), content-addressed digests versus movable tags, registries and pulling, and the OCI image spec: index, manifest, config and layers.
- Module 3: The Dockerfile and the build (coming): Which instructions make layers, the build cache's rules, multi-stage builds, .dockerignore and the build context, BuildKit, and reproducible builds with pinned base images and versions.
- Module 4: Running a container well (coming): PID 1 and signals (SIGTERM, exec form versus shell form, docker stop's grace period, --init), exit codes, restart policies, health checks, and logs.
- Module 5: Data and networking (coming): Volumes versus bind mounts, the bridge network and veth pairs, publishing ports, DNS between containers on a user-defined network, and Compose.
- Module 6: Limits and failures (coming): Memory limits and the OOM killer (exit code 137), CPU shares versus quota and throttling, and a JVM in a container: container-aware heap sizing.
- Module 7: Security (coming): Root versus a non-root user, capabilities, seccomp, read-only filesystems, rootless mode and user namespace remapping, image scanning, and secrets that must never end up in a layer.
- Module 8: Small, fast images (coming): Distroless and Alpine trade-offs (musl versus glibc), layer ordering for cache hits, multi-architecture images with buildx, and an Android Gradle build in a container.
- Module 9: To production (coming): Promoting an image by digest, a bridge to Kubernetes pods, and debugging a running container with exec, inspect, nsenter and a debug sidecar.

[[Glossary]]
