# Glossary: Docker from the kernel up

Every word the course teaches, in the order it does. #flashcards/docker/words

--name::Gives a new container a name you choose. (taught in [[00 A container is a process]])

-d::docker run's option that starts the container in the background and gives you the terminal back. (taught in [[00 A container is a process]])

alpine:3.20::The image of Alpine Linux 3.20, a small Linux distribution. (taught in [[00 A container is a process]])

container::An ordinary process (or a few) that the kernel runs inside a fence limiting what it can see and how much it can use. (taught in [[00 A container is a process]])

container image::A package of the files a program needs to start, plus settings such as which command to run; a container starts from one. (taught in [[00 A container is a process]])

docker exec::Runs one more program inside a container that is already running. (taught in [[00 A container is a process]])

docker rm::Removes a container (with -f, even a running one), and with it the files it wrote. (taught in [[00 A container is a process]])

docker run::Starts a new container from an image. (taught in [[00 A container is a process]])

docker.sock::The special file, /var/run/docker.sock, through which the docker command sends its requests to dockerd. (taught in [[00 A container is a process]])

PID::Process ID: the number the kernel gives a process when it starts it. (taught in [[00 A container is a process]])

ps::Prints the processes the kernel is running, one line each, with their PIDs. (taught in [[00 A container is a process]])

sleep 1000::A tiny program that waits 1000 seconds and exits. (taught in [[00 A container is a process]])

--rm::docker run's option that removes the container as soon as its program exits. (taught in [[01 One kernel, or many]])

/etc/os-release::A file that names the Linux distribution whose files you are looking at. (taught in [[01 One kernel, or many]])

hypervisor::The program that runs virtual machines and keeps them apart, each behind its own pretend hardware. (taught in [[01 One kernel, or many]])

system call::A request a process makes to the kernel, such as open this file or start a process: the only way a program reaches anything outside its own memory. (taught in [[01 One kernel, or many]])

uname -r::Prints the version of the kernel the calling process runs on. (taught in [[01 One kernel, or many]])

virtual machine::A whole pretend computer, with its own operating system and its own kernel, run by a hypervisor. (taught in [[01 One kernel, or many]])

--fork::unshare's option that starts the program as a child, so it becomes PID 1 of the new PID namespace. (taught in [[02 Whose PID 1]])

--mount-proc::unshare's option that gives the new process a fresh /proc for its PID namespace. (taught in [[02 Whose PID 1]])

--pid=host::docker run's option that keeps the container in the host's PID namespace. (taught in [[02 Whose PID 1]])

/proc::A folder whose files the kernel fills in as you read them: one entry per process, and more; ps reads it. (taught in [[02 Whose PID 1]])

kill -0::Asks the kernel whether a PID exists (and may be signalled), without sending anything. (taught in [[02 Whose PID 1]])

namespace::A kernel feature that gives the processes inside it their own copy of one global resource, such as the list of PIDs, invisible to processes outside. (taught in [[02 Whose PID 1]])

pgrep::Prints the PIDs of processes with a given name. (taught in [[02 Whose PID 1]])

PID namespace::A namespace for process IDs: inside it, PIDs start again at 1, and only the processes in it (and in namespaces it contains) can be seen. (taught in [[02 Whose PID 1]])

unshare::Runs a program in new namespaces of the kinds you name. (taught in [[02 Whose PID 1]])

chroot::An older system call that changes where one process's paths start, leaving the mounts as they are. (taught in [[03 A file tree of its own]])

mount::Attaching a filesystem (a disk, or a set of files) to a folder in the one file tree that starts at /. (taught in [[03 A file tree of its own]])

mount namespace::A namespace for the list of mounts: processes in different mount namespaces see different file trees. (taught in [[03 A file tree of its own]])

pivot_root::The system call that makes a new set of files the root mount of a mount namespace, so the old one can be unmounted. (taught in [[03 A file tree of its own]])

root filesystem::The files mounted at /, the root (top) of a process's file tree; a container's comes from its image. (taught in [[03 A file tree of its own]])

tmpfs::A filesystem kept in memory. (taught in [[03 A file tree of its own]])

/proc/PID/ns::The folder that holds one link per namespace a process is in; equal numbers mean the same namespace. (taught in [[04 A namespace per resource]])

hostname::The machine's name, which programs can read and set; with no other name given, Docker sets a container's to the start of its ID. (taught in [[04 A namespace per resource]])

network interface::One connection to a network, with its own address, such as eth0 or lo. (taught in [[04 A namespace per resource]])

network namespace::A namespace for networking: its own network interfaces, addresses, routes and ports. (taught in [[04 A namespace per resource]])

UTS namespace::A namespace for the hostname: changing it inside changes it only for the processes in that namespace. (taught in [[04 A namespace per resource]])

--cap-drop::docker run's option that removes a capability from the container's root. (taught in [[05 Root in the container is root on the host]])

--user::docker run's option that sets the UID the container's program runs as. (taught in [[05 Root in the container is root on the host]])

-v::docker run's option that mounts a host folder into the container's tree. (taught in [[05 Root in the container is root on the host]])

CAP_DAC_OVERRIDE::The capability that lets a process past file read, write and execute permission checks. (taught in [[05 Root in the container is root on the host]])

capability::One piece of root's power, such as passing file permission checks, that the kernel can grant or withhold on its own. (taught in [[05 Root in the container is root on the host]])

chmod 600::Lets only a file's owner read or write it. (taught in [[05 Root in the container is root on the host]])

chown::Changes which UID owns a file. (taught in [[05 Root in the container is root on the host]])

id -u::Prints the UID of the process that runs it. (taught in [[05 Root in the container is root on the host]])

root user::The user with UID 0, called root, whom the kernel lets past its permission checks. (taught in [[05 Root in the container is root on the host]])

UID map::A user namespace's table that says which UID outside each UID inside really is. (taught in [[05 Root in the container is root on the host]])

user namespace::A namespace for user IDs: a process can be UID 0 inside it and an ordinary UID outside it. (taught in [[05 Root in the container is root on the host]])

userns-remap::A Docker daemon setting that gives every container a user namespace, mapping its root to an unprivileged host UID. (taught in [[05 Root in the container is root on the host]])

--memory::docker run's option that sets a container's memory limit. (taught in [[06 How much memory may it use]])

--memory-swap::docker run's option for memory plus swap; set equal to --memory, the limit covers swap too. (taught in [[06 How much memory may it use]])

cgroup::Control group: a group of processes whose use of memory, processor time and more the kernel counts and limits. (taught in [[06 How much memory may it use]])

docker info::Prints how the Docker daemon and its machine are set up. (taught in [[06 How much memory may it use]])

docker inspect::Prints a container's details, such as its ID, state and exit code. (taught in [[06 How much memory may it use]])

docker-ID.scope::The folder name that systemd gives a container's cgroup on version 2 machines. (taught in [[06 How much memory may it use]])

free -m::Prints how much memory the machine has and uses, read from /proc. (taught in [[06 How much memory may it use]])

memory limit::The most memory a cgroup's processes may use together; past it, the kernel reclaims memory or kills one of them. (taught in [[06 How much memory may it use]])

memory.limit_in_bytes::cgroup version 1's file for a group's memory limit, in bytes. (taught in [[06 How much memory may it use]])

memory.usage_in_bytes::cgroup version 1's file for the memory a group uses now, in bytes. (taught in [[06 How much memory may it use]])

tail /dev/zero::Reads an endless stream of zero bytes and keeps it in memory: a quick way to use memory up. (taught in [[06 How much memory may it use]])

--cpu-shares::docker run's option that sets a relative CPU weight, which counts only when processors are busy. (taught in [[07 How much processor time]])

--cpus::docker run's option that sets a container's CPU quota, in processors. (taught in [[07 How much processor time]])

CPU quota::How much processor time a cgroup may use in each period (100 ms by default) before the kernel makes it wait. (taught in [[07 How much processor time]])

cpu.cfs_quota_us::cgroup version 1's file for the CPU quota, in microseconds. (taught in [[07 How much processor time]])

cpu.max::cgroup version 2's file for the CPU quota and period, such as 50000 100000. (taught in [[07 How much processor time]])

cpu.stat::The cgroup file that counts periods, throttled periods and waiting time. (taught in [[07 How much processor time]])

docker stats::Shows each running container's use of processor time and memory. (taught in [[07 How much processor time]])

config.json::The file, defined by the OCI runtime spec, that tells runc which program to run, from which root filesystem, in which namespaces, with which limits. (taught in [[08 Who builds the container]])

containerd::The program dockerd asks to manage each container's life: create, start, stop. (taught in [[08 Who builds the container]])

dockerd::The Docker daemon: the long-running program that the docker command sends every request to. (taught in [[08 Who builds the container]])

OCI runtime spec::The Open Container Initiative's standard for config.json: which program to run, its root filesystem, namespaces and limits. (taught in [[08 Who builds the container]])

runc::The small program that reads a container's config.json, asks the kernel for its namespaces and cgroup, starts its process, and exits. (taught in [[08 Who builds the container]])

shim::containerd-shim-runc-v2: a small process that stays behind as the container process's parent once runc has gone. (taught in [[08 Who builds the container]])

blob::One stored piece of an image (a layer, a config or one of the small JSON files that tie them together), kept as one file and, in a registry, fetched by its name. (taught in [[09 What is inside an image]])

docker commit::Turns a container's file changes into a new layer and a new image. (taught in [[09 What is inside an image]])

docker diff::Lists the files a container added (A), changed (C) or deleted (D) since it started. (taught in [[09 What is inside an image]])

docker history::Lists an image's layers, newest first, with the step that made each and its size. (taught in [[09 What is inside an image]])

docker save::Writes an image, all its layers and JSON files, into one tar archive. (taught in [[09 What is inside an image]])

image config::The JSON file of an image that says how to run it (command, environment, working folder) and lists its layers in order. (taught in [[09 What is inside an image]])

layer::A tar archive of file changes (files added, changed, or deleted); an image's layers, applied in order, make its root filesystem. (taught in [[09 What is inside an image]])

notes:v1::The small image this module builds: alpine:3.20 plus one layer that adds /notes.txt and deletes /etc/motd. (taught in [[09 What is inside an image]])

tar::An archive format that packs many files, with their names and permissions, into one; also the program that makes and reads it. (taught in [[09 What is inside an image]])

whiteout::An empty file named .wh.<name> in a layer, meaning: delete <name> from the layers below. (taught in [[09 What is inside an image]])

copy-up::The overlay filesystem copying a file from a lower directory into the upper one the first time it is written. (taught in [[10 Stacking layers into one tree]])

lower directory::A read-only directory of an overlay mount, such as one unpacked image layer. (taught in [[10 Stacking layers into one tree]])

overlay filesystem::A filesystem in the kernel (OverlayFS) that shows several directories stacked as one: read-only lower ones and one writable upper one. (taught in [[10 Stacking layers into one tree]])

upper directory::The one writable directory of an overlay mount: every write and every deletion lands there. (taught in [[10 Stacking layers into one tree]])

docker ps -s::Lists running containers with the size of each one's writable layer. (taught in [[11 The container's own layer]])

docker restart::Stops a container and starts it again; -t sets how long to wait for its program to exit. (taught in [[11 The container's own layer]])

writable layer::A container's own upper directory: everything it writes, kept until the container is removed. (taught in [[11 The container's own layer]])

containerd image store::Docker 29's default way to keep images: containerd keeps each layer compressed, as it was downloaded, and unpacked by a snapshotter. (taught in [[12 Where images live on disk]])

docker image ls::Lists local images with their ID, disk usage and content size. (taught in [[12 Where images live on disk]])

docker pull::Downloads an image by tag or by digest. (taught in [[12 Where images live on disk]])

docker system df::Shows how much disk space images, containers, volumes and the build cache use. (taught in [[12 Where images live on disk]])

snapshotter::The containerd component that unpacks layers into directories (snapshots) and prepares a container's root filesystem from them. (taught in [[12 Where images live on disk]])

storage driver::The older part of Docker (overlay2 is the usual one) that stores image layers and containers' writable layers on disk. (taught in [[12 Where images live on disk]])

DiffID::The digest of a layer's uncompressed tar; the image config lists layers by DiffID, the manifest by the digest of the compressed blob. (taught in [[13 Named by its content]])

digest::A content's name made from its bytes: the algorithm, a colon, and a SHA-256 fingerprint, such as sha256:25f1d6…; any change to the bytes changes it. (taught in [[13 Named by its content]])

hash function::A function that turns any bytes into a fixed-size number, the same for the same bytes, and practically never the same for different bytes. (taught in [[13 Named by its content]])

sha256sum::Prints the SHA-256 fingerprint of a file's bytes. (taught in [[13 Named by its content]])

-p 5000:5000::docker run's option that makes a container's port reachable on a port of the host (Module 5). (taught in [[14 Tags move, digests don't]])

docker push::Uploads an image's blobs and manifest to a registry under a tag. (taught in [[14 Tags move, digests don't]])

docker tag::Gives an image one more name (repository and tag). (taught in [[14 Tags move, digests don't]])

image tag::A movable name for one image in a repository, such as 3.20 or latest; whoever pushes can point it at a different image. (taught in [[14 Tags move, digests don't]])

registry::A server that stores images as blobs and manifests and hands them out over HTTP, such as Docker Hub. (taught in [[14 Tags move, digests don't]])

repository::A named collection of an image's versions in a registry, such as library/alpine; tags pick versions in it. (taught in [[14 Tags move, digests don't]])

curl::A command that makes one HTTP request and prints the answer. (taught in [[15 Pulling from a registry]])

HTTP header::A named line of extra information at the top of an HTTP request or answer, such as Accept or Docker-Content-Digest. (taught in [[15 Pulling from a registry]])

image manifest::The small JSON file a registry hands out first: one image config and its layers, each named by digest and size. (taught in [[15 Pulling from a registry]])

--platform::docker run's and docker pull's option that picks a platform from an image index. (taught in [[16 One name, many machines]])

docker buildx imagetools inspect::Prints an image's index or manifest straight from its registry. (taught in [[16 One name, many machines]])

image index::A JSON list of image manifests, one per platform (and attestations), so one tag can serve many kinds of machine. (taught in [[16 One name, many machines]])

OCI image spec::The Open Container Initiative's standard for images: the index, the manifest, the config, layers and digests. (taught in [[16 One name, many machines]])

platform::The operating system and processor an image's programs are built for, such as linux/amd64 or linux/arm64. (taught in [[16 One name, many machines]])

SPDX::A standard format for a software bill of materials: the list of packages inside something. (taught in [[16 One name, many machines]])

x86_64::The 64-bit Intel and AMD processor family; as a Docker platform it is called amd64. (taught in [[16 One name, many machines]])
