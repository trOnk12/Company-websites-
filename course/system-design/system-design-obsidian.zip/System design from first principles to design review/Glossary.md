# Glossary: System design from first principles to design review

Every word the course teaches, in the order it does. #flashcards/system-design/words

invariant::A rule that must hold after every completed change. (taught in [[00 Can two green maps promise the last space]])

reservation::A durable claim by one driver on a space. (taught in [[00 Can two green maps promise the last space]])

in flight::Already arrived, with the reply still outstanding. (taught in [[01 How much traffic arrives after a concert]])

PostgreSQL::A relational database management system. (taught in [[03 How does the database choose a winner]])

replica::A separate copy that replays changes to the primary store. (taught in [[06 Why does a confirmed space still look free]])

transactional outbox::A durable list of messages stored with the business changes that create them. (taught in [[07 How do you send an event after a crash]])

token::One permit consumed to admit a request. (taught in [[08 Why can retries prolong an outage]])

CAP::A theorem relating consistency and availability during a network partition. (taught in [[10 Who can confirm a write when regions cannot talk]])

error budget::The number or fraction of bad outcomes allowed by a service objective. (taught in [[12 Is the database slow, or is the request waiting to reach it]])
