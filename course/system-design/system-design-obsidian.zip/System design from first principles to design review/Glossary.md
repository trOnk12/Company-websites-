# Glossary: System design from first principles to design review

Every word the course teaches, in the order it does. #flashcards/system-design/words

FROM::Chooses the table whose rows the query will read. (taught in [[00 Can two green maps promise the last space]])

GROUP BY::Groups rows with the same values so each group can be counted or summarized. (taught in [[00 Can two green maps promise the last space]])

HAVING::Keeps groups whose aggregate result passes a condition. (taught in [[00 Can two green maps promise the last space]])

invariant::A rule that must hold after every completed change. (taught in [[00 Can two green maps promise the last space]])

reservation::A durable claim by one driver on a space. (taught in [[00 Can two green maps promise the last space]])

SQL::A language for asking questions about records and changing them in a database. (taught in [[00 Can two green maps promise the last space]])

WHERE::Keeps rows for which a condition is true. (taught in [[00 Can two green maps promise the last space]])

in flight::Already arrived, with the reply still outstanding. (taught in [[01 How much traffic arrives after a concert]])

PostgreSQL::A relational database management system. (taught in [[03 How does the database choose a winner]])

RETURNING::Asks a write statement to return values from the rows it actually affected. (taught in [[03 How does the database choose a winner]])

replica::A separate copy that replays changes to the primary store. (taught in [[06 Why does a confirmed space still look free]])

transactional outbox::A durable list of messages stored with the business changes that create them. (taught in [[07 How do you send an event after a crash]])

token::One permit consumed to admit a request. (taught in [[08 Why can retries prolong an outage]])

hash::A repeatable value computed from a key and used here to route it to a storage owner. (taught in [[09 When does splitting the data help]])

CAP::A theorem relating consistency and availability during a network partition. (taught in [[10 Who can confirm a write when regions cannot talk]])

error budget::The number or fraction of bad outcomes allowed by a service objective. (taught in [[12 Is the database slow, or is the request waiting to reach it]])

round robin::Sending successive requests to the next eligible worker in a repeating order. (taught in [[15 Why does an idle worker watch a request wait]])

request coalescing::Letting callers for the same key share one pending operation. (taught in [[16 Can two cache misses share one read]])

circuit breaker::A policy that uses earlier call outcomes to decide when to refuse calls and when to probe for recovery. (taught in [[17 When is it worth calling a failing dependency again]])
