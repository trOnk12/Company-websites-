# Glossary: System design from first principles to design review

Every word the course teaches, in the order it does. #flashcards/system-design/words

FROM::Chooses the table whose rows the query will read. (taught in [[00 Two drivers tap Reserve. Who gets the last space]])

invariant::A rule that must hold after every completed change. (taught in [[00 Two drivers tap Reserve. Who gets the last space]])

reservation::A saved booking that assigns a space to one driver for a particular time. (taught in [[00 Two drivers tap Reserve. Who gets the last space]])

SQL::A language for asking questions about records and changing them in a database. (taught in [[00 Two drivers tap Reserve. Who gets the last space]])

WHERE::Keeps rows for which a condition is true. (taught in [[00 Two drivers tap Reserve. Who gets the last space]])

GROUP BY::Groups rows with the same values so each group can be counted or summarized. (taught in [[01 How much traffic arrives after a concert]])

in flight::Already arrived, with the reply still outstanding. (taught in [[01 How much traffic arrives after a concert]])

PostgreSQL::A relational database management system. (taught in [[03 How does the database choose a winner]])

RETURNING::Asks a write statement to return values from the rows it actually affected. (taught in [[03 How does the database choose a winner]])

bookings.allocateId::Reserves a number for a possible booking without consuming a parking space. (taught in [[04 The booking succeeded, but the reply was lost]])

bookings.createWithId::Creates the booking under an already allocated number. (taught in [[04 The booking succeeded, but the reply was lost]])

getById::Looks for a saved request record in the example handler. (taught in [[04 The booking succeeded, but the reply was lost]])

idempotent::Having the same effect when the same request is processed more than once. (taught in [[04 The booking succeeded, but the reply was lost]])

request ID::A value created for one user action and reused when that same action is retried. (taught in [[04 The booking succeeded, but the reply was lost]])

RequestIdAlreadyExists::The example error used when the unique request row already exists. (taught in [[04 The booking succeeded, but the reply was lost]])

requireNotNull::Stops the example if an expected saved request is unexpectedly absent. (taught in [[04 The booking succeeded, but the reply was lost]])

return@transaction::Returns an answer from the transaction function without returning from the outer function. (taught in [[04 The booking succeeded, but the reply was lost]])

savedRequests::The durable request records used by the example handler. (taught in [[04 The booking succeeded, but the reply was lost]])

unique constraint::A database rule that allows only one row for the same chosen value or values. (taught in [[04 The booking succeeded, but the reply was lost]])

cursor::A saved position after the last record returned, sent back to continue a sorted list. (taught in [[05 Where does the next page of history begin]])

index::An additional ordered structure that a database maintains to find some rows with less work. (taught in [[05 Where does the next page of history begin]])

query plan::The route a database proposes for finding and processing the rows requested by a query. (taught in [[05 Where does the next page of history begin]])

freshness limit::The greatest allowed age of information when the user receives it. (taught in [[06 Why does a confirmed booking still look missing]])

map cache::A place that keeps an answer so another request can reuse it without repeating the original work. (taught in [[06 Why does a confirmed booking still look missing]])

primary store::The database copy that accepts the booking writes in this design. (taught in [[06 Why does a confirmed booking still look missing]])

read-your-writes::A promise that a client's reads will not go behind a write already confirmed to that client. (taught in [[06 Why does a confirmed booking still look missing]])

replica::A separate copy that replays the changes it receives from the primary store. (taught in [[06 Why does a confirmed booking still look missing]])

write position::An ordered marker identifying how far a database copy has applied changes. (taught in [[06 Why does a confirmed booking still look missing]])

consumer effect::A durable change made by the service that receives an event. (taught in [[07 How do you send an event after a crash]])

relay::A worker that finds committed outbox rows and publishes their messages. (taught in [[07 How do you send an event after a crash]])

transactional outbox::A durable list of messages stored with the business changes that create them. (taught in [[07 How do you send an event after a crash]])

admission control::A decision at entry that refuses work which should not join the service. (taught in [[08 Why can retries prolong an outage]])

backlog::Work already accepted but not yet completed. (taught in [[08 Why can retries prolong an outage]])

retry budget::A limit on retry attempts or the elapsed time they may consume. (taught in [[08 Why can retries prolong an outage]])

hash::A repeatable value computed from a key and used here to route it to a storage owner. (taught in [[09 When does splitting the data help]])

CAP::A theorem relating consistency and availability during a network partition. (taught in [[10 Who can confirm a write when regions cannot talk]])

error budget::The number or fraction of bad outcomes allowed by a service objective. (taught in [[12 Is the database slow, or is the request waiting to reach it]])

round robin::Sending successive requests to the next eligible worker in a repeating order. (taught in [[15 Why does an idle worker watch a request wait]])

request coalescing::Letting callers for the same key share one pending operation. (taught in [[16 Can two cache misses share one read]])

circuit breaker::A policy that uses earlier call outcomes to decide when to refuse calls and when to probe for recovery. (taught in [[17 When is it worth calling a failing dependency again]])
