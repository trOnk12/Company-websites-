---
source: https://pachulski.dev/course/system-design/
tags: [course/system-design]
---

# System design from first principles to design review

Design a parking service that can refuse the last space, survive a lost reply and recover its booking history. Trace each decision in a diagram, then inspect the rows or timings that would prove it wrong.

From [pachulski.dev](https://pachulski.dev/course/system-design/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Bookings, busy periods and lost replies

Check who booked the last space, size a test for the busy minutes and find a saved booking after a process stops.

- [[00 Two drivers tap Reserve. Who gets the last space]]: Separate what the map shows from what the app promises when it confirms.
- [[01 How much traffic arrives after a concert]]: Work out how many map requests to send in a test for the minutes after a concert.
- [[02 Where is Ada’s booking when her reply is lost]]: Find Ada’s booking after the program that saved it stops.

## Data under concurrent use

Protect inventory, handle retries, page history and bound staleness.

- [[03 How does the database choose a winner]]: Follow Ada and Ben as they try to take the last space from the same database.
- [[04 The booking succeeded, but the reply was lost]]: Retry one tap without creating a second booking.
- [[05 Where does the next page of history begin]]: Keep a moving list continuous by saving the last record's complete position.
- [[06 Why does a confirmed booking still look missing]]: Make Ada's next read include the booking the service just confirmed.

## Distributed work

Deliver events, handle overload, move data and survive a partition.

- [[07 How do you send an event after a crash]]: Follow one booking and one event through both crash windows.
- [[08 Why can retries prolong an outage]]: Follow one queue until retries either stop or keep it full.
- [[09 When does splitting the data help]]: Choose a key by following the reads and writes.
- [[10 Who can confirm a write when regions cannot talk]]: Understand majority agreement and the cost of losing contact.

## Operating and defending a design

Reconcile payments, diagnose delays, recover data and defend a design under changed assumptions.

- [[11 What if the space expires before payment is confirmed]]: Make uncertain outcomes and compensation explicit.
- [[12 Is the database slow, or is the request waiting to reach it]]: Connect a user-facing objective to a concrete trace.
- [[13 Can you recover the right history after a bad release]]: Test restoration with real reads and writes.
- [[14 Does the design survive a changed assumption]]: Defend a decision, then transfer it to a different domain.

## Operate a busy read path

Route uneven work, share simultaneous cache misses and test a recovering dependency.

- [[15 Why does an idle worker watch a request wait]]: Route four reads and measure time spent waiting behind earlier work.
- [[16 Can two cache misses share one read]]: Make overlapping requests for the same reading share the work and observe how a failed read propagates.
- [[17 When is it worth calling a failing dependency again]]: Use failure replies and a quiet interval to control how many calls reach a recovering dependency.
- [[18 If one driver gives up, whose read should stop]]: Give two callers different deadlines and trace what survives the first timeout.

## Practice chapters

- [[Practice chapter 1|Guarantees under load and partial failure]]
- [[Practice chapter 2|Choosing boundaries that hold during overload]]
- [[Practice chapter 3|Rebuild a concert seating map from reservation events]]
- [[Practice chapter 4|Follow a record through Apache Kafka]]
- [[Practice chapter 5|Design a search across independent shards]]

[[Final project]]


[[Glossary]]
