---
source: https://pachulski.dev/course/system-design/
tags: [course/system-design]
---

# System design from first principles to design review

Build a parking reservation service on paper and on the JVM. Estimate a concert peak, race for the last space, lose a payment reply and recover after a bad release. Transfer your reasoning to tickets, feeds and private uploads.

From [pachulski.dev](https://pachulski.dev/course/system-design/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## From promises to a write path

Estimate demand and decide who owns the last space.

- [[00 Can two green maps promise the last space]]: Define what success means before choosing storage.
- [[01 How much traffic arrives after a concert]]: Estimate peak demand and concurrent work with units.
- [[02 Who can grant the last space]]: Trace a request through two service instances and one store.

## Data under concurrent use

Protect inventory, handle retries, page history and bound staleness.

- [[03 How does the database choose a winner]]: Keep the claim and the inventory change together.
- [[04 What if a successful reply disappears]]: Recognize a retry after the database has committed.
- [[05 Where does the next page of history begin]]: Order records and handle ties before choosing an index.
- [[06 Why does a confirmed space still look free]]: Give map reads and confirmation reads explicit freshness rules.

## Distributed work

Deliver events, handle overload, move data and survive a partition.

- [[07 How do you send an event after a crash]]: Save the business change and the work it creates together.
- [[08 Why can retries prolong an outage]]: Calculate backlog growth and recovery time.
- [[09 When does splitting the data help]]: Choose a key by following the reads and writes.
- [[10 Who can confirm a write when regions cannot talk]]: Understand majority agreement and the cost of losing contact.

## Operating and defending a design

Reconcile payments, diagnose delays, recover data and defend a design under changed assumptions.

- [[11 What if the space expires before payment is confirmed]]: Make uncertain outcomes and compensation explicit.
- [[12 Is the database slow, or is the request waiting to reach it]]: Connect a user-facing objective to a concrete trace.
- [[13 Can you recover the right history after a bad release]]: Test restoration with real reads and writes.
- [[14 Does the design survive a changed assumption]]: Defend a decision, then transfer it to a different domain.

[[Final project]]


[[Glossary]]
