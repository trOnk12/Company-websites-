---
course: "System design from first principles to design review"
puzzle: 11
source: https://pachulski.dev/course/system-design/11-payment
tags: [course/system-design]
---

# What if the space expires before payment is confirmed?

> [!summary] The idea to keep
> A missing payment reply leaves an unknown outcome that needs reconciliation.

**Builds on:** [[00 Can two green maps promise the last space]]

## The problem

Payment introduces a second decision beyond the reservation itself. The lot holds a space for five minutes. The payment provider charges the driver, but its reply disappears. What should the phone show?

## See it

![What if the space expires before payment is confirmed?](https://pachulski.dev/course/system-design/gifs/payment.gif)

Step through it: https://pachulski.dev/course/system-design/11-payment

## The building block

Represent the process with explicit states such as pending, confirmed, expired and refund pending. Save a payment-attempt identity before contacting the provider. Silence leaves the result unknown. A later authoritative notification or status query lets the service reconcile both records. A saga coordinates local steps and explicitly defined compensating actions.

Expiry and payment success can race. Both try to transition from pending. The winner determines which transitions remain valid. If the space has been released, late payment success creates durable refund work. A refund is another operation that can fail or take time. The driver needs to distinguish an outstanding refund from one completed by the provider.

### Trace one late payment

At minute zero, hold H owns seat 12. At minute two, expiry releases it. At minute three a different driver acquires the seat. The provider then reports a successful charge for H. Keep the new owner's seat. Record the old charge reference and a pending refund as a durable decision. A second success notification for the same charge finds that decision and produces no additional refund work.

Now lose the refund response. A worker needs a provider-supported way to query the refund or safely repeat the same refund identity. Mark it complete only after obtaining a confirmed outcome. If neither operation is available, keep it unresolved for reconciliation. Announcing a completed refund from the local send alone would give the driver a false financial status.

## Try it

Write the allowed transitions. Trace success before expiry, success after expiry, duplicate success and no notification at all. In the last case, decide when to query the provider and when to escalate unresolved work. What stable identity prevents a repeated refund?

## Check yourself

#flashcards/system-design

What does a missing provider reply mean?::The result is unknown. The charge may already have completed.

A charge succeeds after the space was released. What follows here?::Create refund work. The original hold no longer owns the space.

Does sending a refund request complete the refund?::Confirm the provider's result. Compensation can also have an uncertain outcome.

## Sources

- [Azure Architecture Center · Saga](https://learn.microsoft.com/en-us/azure/architecture/patterns/saga) — “coordinating a sequence of local transactions across multiple services”
