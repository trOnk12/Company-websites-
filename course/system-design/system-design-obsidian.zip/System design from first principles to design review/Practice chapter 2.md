# Choosing boundaries that hold during overload

## Does splitting a table distribute its writes across machines?

Declarative partitioning divides one logical table into partitions using a routing rule. Partition pruning can avoid scanning irrelevant partitions when a predicate restricts the partition key. This feature alone does not give every partition its own independently writable database server.

### Worked example

Bookings are partitioned by month. A report for January can avoid unrelated months when its predicate allows pruning. A single popular event in January still places all its concurrent reservations in the same month. A partitioning scheme good for retention need not spread the hot event.

### Try it

The business wants to delete whole months quickly and handle one hot concert. What two measurements should determine your next design?

### Compare your answer

Measure pruning and retention maintenance for the time-based layout, then measure lock contention and write throughput for the hot event. If proposing independent shards, identify the routing key and which reservations must still share a transaction. Prove the invariant during a shard move.

[Source · PostgreSQL · Table partitioning](https://www.postgresql.org/docs/17/ddl-partitioning.html)

## Which requests should an overloaded service admit?

Load shedding refuses some work early so admitted work can still finish. Bounded queues constrain memory and waiting time. A queue that accepts everything can spend most of its capacity finishing requests after callers have already left. Define how callers distinguish an overload response from an unknown committed outcome.

### Worked example

At 100 completed requests per second, 500 already ahead of a new request imply roughly five seconds of waiting in a simple FIFO model before service. With a one-second client deadline, acceptance alone offers little value. Track rejected requests alongside successful latency so dropping difficult work cannot artificially improve the dashboard.

### Try it

Would raising the queue limit from 500 to 1,000 improve throughput when the processor is already saturated?

### Compare your answer

Under the stated constant capacity it adds waiting space, not service rate. A short burst may be absorbed if callers can wait and spare capacity follows. Compare useful completions before deadline, rejected work and recovery time under the same arrival trace.

[Source · AWS Builders’ Library · Load shedding](https://aws.amazon.com/builders-library/using-load-shedding-to-avoid-overload/)

## How can losing a single replica take down its neighbors?

A load balancer redistributes traffic when it removes an unhealthy replica. If the remaining capacity is below demand, the extra load can make previously healthy replicas slow. Retries and failed health checks can amplify the effect. Recovery requires a path back to a sustainable load.

### Worked example

Three replicas each handle 100 requests per second. At 240 arrivals per second they average 80 each. Losing one sends 120 to each survivor, 20 beyond its assumed capacity even before retries. Steady backlog now grows by 40 requests per second. A restart loop can remove more useful capacity.

### Try it

One replica comes back. Is 300 requests per second of nominal capacity sufficient to declare recovery?

### Compare your answer

Observe its readiness and actual useful throughput as caches warm. With an existing backlog, sustainable service must exceed arrivals long enough to drain it. Limit retries, protect critical requests and verify client-side latency until the backlog falls.

[Source · Google SRE · Addressing cascading failures](https://sre.google/sre-book/addressing-cascading-failures/)

[[Final project]]

[[Course map]]