# Glossary: Mobile system design, from a packet to an app

Every word the course teaches, in the order it does. #flashcards/sysdesign/words

connection::An agreement between two sides to talk, set up before data flows, so TCP can keep its bookkeeping. (taught in [[00 What actually travels]])

IP::The Internet Protocol: addresses each packet and routes it, best effort. (taught in [[00 What actually travels]])

packet::A small chunk of data, up to about 1.5 KB, with an address on it. (taught in [[00 What actually travels]])

TCP::Turns lost, reordered packets into a reliable, ordered stream, over a connection. (taught in [[00 What actually travels]])

bandwidth::How much data a link can carry per second. (taught in [[01 Round trips, not bandwidth]])

latency::The time a packet takes to travel from sender to receiver. (taught in [[01 Round trips, not bandwidth]])

round trip::A message there and its answer back: twice the latency, plus the server's work. (taught in [[01 Round trips, not bandwidth]])

connection reuse::Sending new requests over a connection that's already open, skipping its handshakes. (taught in [[02 One connection, many requests]])

HTTP/2::A version of HTTP that sends many requests at once over one connection. (taught in [[02 One connection, many requests]])

multiplexing::Interleaving several requests and responses on one connection at the same time. (taught in [[02 One connection, many requests]])

batching::Sending several pieces of network work together, so the radio wakes up once. (taught in [[03 The radio is the battery]])

radio state::The power level the phone's radio is in: idle and sipping power, or connected and drawing a lot. (taught in [[03 The radio is the battery]])

tail time::How long the radio stays at high power after the last packet, waiting for more. (taught in [[03 The radio is the battery]])

Cache-Control::The response header that tells a cache how long the response stays fresh. (taught in [[04 Ask before you download]])

conditional request::A request that says which version you already have; the server answers 304 if it hasn't changed. (taught in [[04 Ask before you download]])

ETag::A short tag that names one version of a resource. (taught in [[04 Ask before you download]])

fresh::A cached response young enough to use without asking the server. (taught in [[04 Ask before you download]])

offline-first::An app that reads and writes local data first, and syncs with the network when it can. (taught in [[05 The database is the truth]])

repository::The class that combines the local and network data sources and gives the rest of the app its data. (taught in [[05 The database is the truth]])

source of truth::The one place the app reads a piece of data from; everything else copies it. (taught in [[05 The database is the truth]])

exponential backoff::Waiting longer after each failed try: 1 s, 2 s, 4 s and so on. (taught in [[06 Retry without charging twice]])

idempotency key::A unique ID the client sends with a request so the server can recognise a retry. (taught in [[06 Retry without charging twice]])

idempotent::Doing it twice has the same effect as doing it once. (taught in [[06 Retry without charging twice]])

jitter::Randomness added to the wait, so clients that failed together don't retry together. (taught in [[06 Retry without charging twice]])
