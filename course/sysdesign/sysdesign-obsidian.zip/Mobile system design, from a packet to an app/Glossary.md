# Glossary: Mobile system design, from a packet to an app

Every word the course teaches, in the order it does. #flashcards/sysdesign/words

connection::An agreement between two sides to talk, set up before data flows, so TCP can keep its bookkeeping. (taught in [[00 What actually travels]])

IP::The Internet Protocol: addresses each packet and routes it, best effort. (taught in [[00 What actually travels]])

packet::A small chunk of data, up to about 1.5 KB, with an address on it. (taught in [[00 What actually travels]])

router::A machine that passes data along toward its address. (taught in [[00 What actually travels]])

TCP::Turns lost, reordered packets into a reliable, ordered stream, over a connection. (taught in [[00 What actually travels]])

TLS::Transport Layer Security: encrypts the stream, detects changes, and proves who the server is. (taught in [[00 What actually travels]])

cached::Kept for a while so it doesn't have to be fetched again. (taught in [[01 Finding the server]])

DNS::The Domain Name System: the internet's phone book, turning hostnames into IP addresses. (taught in [[01 Finding the server]])

hostname::The name code uses for a server, like api.example.com. (taught in [[01 Finding the server]])

IP address::The number routers use to deliver packets to a machine. (taught in [[01 Finding the server]])

body::The data an HTTP message carries, like JSON. (taught in [[02 Anatomy of an HTTP call]])

header::A name–value pair about an HTTP message, not its data. (taught in [[02 Anatomy of an HTTP call]])

HTTP method::What a request asks for: GET reads, POST creates, PUT replaces, DELETE removes. (taught in [[02 Anatomy of an HTTP call]])

path::Which resource on the server a request is about, like /users/42. (taught in [[02 Anatomy of an HTTP call]])

status code::The number a response starts with; its first digit is the family: 2xx worked, 3xx elsewhere, 4xx your fault, 5xx the server's. (taught in [[02 Anatomy of an HTTP call]])

bandwidth::How much data a link can carry per second. (taught in [[03 Round trips, not bandwidth]])

latency::The time a packet takes to travel from sender to receiver. (taught in [[03 Round trips, not bandwidth]])

round trip::A message there and its answer back: twice the latency, plus the server's work. (taught in [[03 Round trips, not bandwidth]])

certificate::A document, signed by an authority the phone trusts, saying a key belongs to a hostname. (taught in [[04 What HTTPS adds]])

handshake::The exchange that sets up a connection before data flows. (taught in [[04 What HTTPS adds]])

HTTPS::HTTP sent through TLS. (taught in [[04 What HTTPS adds]])

connection pool::The set of open connections a client keeps for reuse. (taught in [[05 One connection, many requests]])

connection reuse::Sending new requests over a connection that's already open, skipping its handshakes. (taught in [[05 One connection, many requests]])

HTTP/2::A version of HTTP that sends many requests at once over one connection. (taught in [[05 One connection, many requests]])

multiplexing::Interleaving several requests and responses on one connection at the same time. (taught in [[05 One connection, many requests]])

3G::The older mobile network before LTE. (taught in [[06 The radio is the battery]])

batching::Sending several pieces of network work together, so the radio wakes up once. (taught in [[06 The radio is the battery]])

LTE::Today's 4G mobile network. (taught in [[06 The radio is the battery]])

radio state::The power level the phone's radio is in: idle and sipping power, or connected and drawing a lot. (taught in [[06 The radio is the battery]])

tail time::How long the radio stays at high power after the last packet, waiting for more. (taught in [[06 The radio is the battery]])

Cache-Control::The response header that tells a cache how long the response stays fresh. (taught in [[07 Ask before you download]])

conditional request::A request that says which version you already have; the server answers 304 if it hasn't changed. (taught in [[07 Ask before you download]])

ETag::A short tag that names one version of a resource. (taught in [[07 Ask before you download]])

fresh::A cached response young enough to use without asking the server. (taught in [[07 Ask before you download]])

offline-first::An app that reads and writes local data first, and syncs with the network when it can. (taught in [[08 The database is the truth]])

repository::The class that combines the local and network data sources and gives the rest of the app its data. (taught in [[08 The database is the truth]])

source of truth::The one place the app reads a piece of data from; everything else copies it. (taught in [[08 The database is the truth]])

timeout::When the app stops waiting: connect timeout (no connection made) or read timeout (no answer arrived). (taught in [[09 When the connection breaks]])

exponential backoff::Waiting longer after each failed try: 1 s, 2 s, 4 s and so on. (taught in [[10 Retry without charging twice]])

idempotency key::A unique ID the client sends with a request so the server can recognise a retry. (taught in [[10 Retry without charging twice]])

idempotent::Doing it twice has the same effect as doing it once. (taught in [[10 Retry without charging twice]])

jitter::Randomness added to the wait, so clients that failed together don't retry together. (taught in [[10 Retry without charging twice]])
