---
course: "Mobile system design, from a packet to an app"
puzzle: 1
source: https://pachulski.dev/course/sysdesign/01-finding-the-server
tags: [course/sysdesign]
---

# Finding the server

> [!summary] The idea to keep
> Every machine on the internet has an IP address, a number that routers use to deliver packets. People and code use hostnames instead, like api.example.com. Before the first connection, the phone asks DNS, the internet's phone book, which address a hostname has. That lookup is one more round trip on a cold start, so the answer is cached for a while.

**Builds on:** [[00 What actually travels]]

## The problem

Your Retrofit base URL is `https://api.example.com`. Puzzle 0 said IP delivers packets by address. A name isn't an address. So before the first packet can leave, something has to turn the name into a number. What, and how long does it take?

## See it

![Finding the server](https://pachulski.dev/course/sysdesign/gifs/dns.gif)

Step through it: https://pachulski.dev/course/sysdesign/01-finding-the-server

## The building block

Every machine reachable on the internet has an **IP address**: a number, like `93.184.215.14`, that routers read to deliver each packet.

Numbers are hard to remember and change when a company moves servers, so people and code use a **hostname** instead: `api.example.com`.

**DNS**, the Domain Name System, is the internet's phone book: a worldwide system of servers that answers "which address does this hostname have?". Before your app's first connection to a host, the phone sends that question and waits for the answer.

Two consequences for an app:

- The very first request to a host waits for a DNS answer first: more waiting before anything useful happens.
- The answer is **cached**: kept for a while by the phone (and by DNS servers on the way), so the next requests skip the lookup.

## The analogy

Looking up a friend's number in your contacts before you can call. The first time, you search; after that, the number's on your recent calls list.

## Check yourself

#flashcards/sysdesign

Your app's first-ever request to `api.example.com` is slower than the next ones. Which part of that is DNS?::Looking up the host's IP address before anything can be sent. Name to address, once.

Why are DNS answers cached?::So later requests skip the lookup and its waiting. Look up once, reuse.

What's the difference between a hostname and an IP address?::A hostname is the name code uses, while an IP address is the number routers deliver to. Name vs number.

## Sources

- [MDN: DNS](https://developer.mozilla.org/en-US/docs/Glossary/DNS) ("DNS (Domain Name System) is a hierarchical and decentralized naming system for Internet-connected resources. DNS maintains a list of domain names along with the resources, such as IP addresses, that are associated with them.")
