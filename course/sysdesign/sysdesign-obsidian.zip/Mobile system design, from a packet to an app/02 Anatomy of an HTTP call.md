---
course: "Mobile system design, from a packet to an app"
puzzle: 2
source: https://pachulski.dev/course/sysdesign/02-anatomy-of-an-http-call
tags: [course/sysdesign]
---

# Anatomy of an HTTP call

> [!summary] The idea to keep
> An HTTP request is a method (GET to read, POST to create, PUT to replace, DELETE to remove), a path, headers (name: value pairs about the message) and an optional body. The response has a status code, headers and a body. Status codes come in families: 2xx worked, 3xx look elsewhere or use what you have, 4xx your request was wrong, 5xx the server failed.

**Builds on:** [[01 Finding the server]]

## The problem

You write `@GET("users/42")` and get a `User`. When something fails, Retrofit gives you a code like 404 or 503, and later puzzles talk about parts of the request it hides. What exactly travels, and what do those numbers mean?

## See it

![Anatomy of an HTTP call](https://pachulski.dev/course/sysdesign/gifs/http.gif)

Step through it: https://pachulski.dev/course/sysdesign/02-anatomy-of-an-http-call

## The building block

An HTTP request has four parts:

| Part | Example | In Retrofit |
|---|---|---|
| **HTTP method** | `GET`, `POST`, `PUT`, `DELETE` | `@GET`, `@POST`… |
| **path** | `/users/42` | the annotation's string |
| **headers** | `Authorization: Bearer …` | `@Header`, or an interceptor |
| **body** | JSON of a new order | `@Body` |

The method says what you want: `GET` reads, `POST` creates something new, `PUT` replaces something at that path, `DELETE` removes it. **Headers** are name–value pairs about the message, not the data itself: who you are, what format you accept, how long something may be cached.

The response comes back with a **status code**, headers, and a body. Status codes come in families, by their first digit:

| Family | Meaning | Examples |
|---|---|---|
| 2xx | it worked | 200 OK, 201 Created |
| 3xx | look elsewhere, or use what you have | 301 Moved Permanently |
| 4xx | your request was wrong | 400 Bad Request, 401, 404, 429 Too Many Requests |
| 5xx | the server failed | 500, 503 |

The family is what your code usually decides on: a 4xx won't fix itself if you send the same request again; a 5xx might.

## The analogy

A letter to an office: the method is what you're asking for ("please file this", "please send me that"), the path is which department, the headers are the notes on the envelope, the body is the letter. The reply comes with a stamp: approved, see the other office, your form is wrong, or we're closed.

## Check yourself

#flashcards/sysdesign

Your app gets a 404 from `GET /users/42`. Should it retry the same request?::No: a 4xx means the request itself was wrong. 4xx won't fix itself.

Where does a request say "this response can be cached for a minute"?::In a header, a name–value pair about the message. Notes about the message: headers.

What's the difference between GET and POST?::GET reads something, while POST creates something new. Read vs create.

## Sources

- [MDN: An overview of HTTP](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview) ("HTTP headers make this protocol easy to extend and experiment with"; requests and responses as HTTP messages)
- [MDN: HTTP response status codes](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status) ("Responses are grouped in five classes: Informational responses (100 – 199), Successful responses (200 – 299), Redirection messages (300 – 399), Client error responses (400 – 499), Server error responses (500 – 599)")
