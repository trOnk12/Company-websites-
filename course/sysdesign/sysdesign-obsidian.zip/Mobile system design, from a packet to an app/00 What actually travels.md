---
course: "Mobile system design, from a packet to an app"
puzzle: 0
source: https://pachulski.dev/course/sysdesign/00-what-actually-travels
tags: [course/sysdesign]
---

# What actually travels

> [!summary] The idea to keep
> Data crosses the internet in packets. IP addresses each packet and routes it, but can lose, delay or reorder it. TCP turns those packets into a reliable, ordered stream: it numbers bytes, waits for acknowledgements and resends what's lost, and needs a connection set up first. TLS encrypts that stream, and HTTP is the language of requests and responses on top.

## The problem

In your code, a request is one call, and a user object comes back. But the phone and the server are joined by Wi-Fi, a cell tower, cables and a dozen **routers**, machines that pass data along toward its address, any of which can drop data. How does a request survive that trip, and what does it cost?

## See it

![What actually travels](https://pachulski.dev/course/sysdesign/gifs/layers.gif)

Step through it: https://pachulski.dev/course/sysdesign/00-what-actually-travels

## The building block

Data travels in **packets**. A small message can fit in one; a large stream spans many. About 1,500 bytes is a common link limit, not a universal packet size.

**IP**, the Internet Protocol, is the postal service: it addresses each packet and passes it from router to router toward the server. It does its best, nothing more. A packet can be lost, delayed, or overtaken by the one sent after it.

**TCP**, the Transmission Control Protocol, builds something reliable on top. The sender numbers positions in the byte stream. Each segment carries the position of its first byte. An acknowledgement gives the next byte expected; the sender can retransmit missing data, and the receiver delivers bytes in order. Your code sees one clean stream of bytes. To keep that bookkeeping, both sides must first agree to talk: a TCP **connection**, set up with a short exchange before any data flows.

This diagram follows the stack that uses TCP; other web transports exist. On top of TCP, two more layers:

| Layer | Its job |
|---|---|
| HTTP | the request and the response (puzzle 2) |
| TLS | encrypts the stream, so intermediaries cannot read the content or alter it undetected (puzzle 4) |
| TCP | reliable, ordered delivery, over a connection |
| IP | addresses and routes each packet, best effort |

Every puzzle that follows is about the cost of this stack: how long packets take to cross (puzzle 3), what setting up a connection costs (puzzle 5), and what the phone's radio pays to send them (puzzle 6).

## The analogy

Sending a book by post, one page per envelope. The post office (IP) delivers most envelopes, in any order, and loses a few. Your friend (TCP) numbers the pages, writes back "got pages 1 to 40", and you resend the missing ones. Before the first page, you agree by letter that you're sending a book at all: the connection.

## Check yourself

#flashcards/sysdesign

A packet of your request is lost between two routers. Who notices and fixes it?::TCP: the missing bytes are retransmitted. Numbering, acknowledging, resending: TCP.

Why must a TCP connection be set up before the first request?::To agree on initial byte sequence numbers. Reliability needs shared bookkeeping.

What's the difference between IP and TCP?::IP delivers single packets as best it can, while TCP makes them a reliable, ordered stream. Best effort vs reliable.

## Sources

- [RFC 9293 · Sequence numbers](https://www.rfc-editor.org/rfc/rfc9293.html#section-3.4)

- [High Performance Browser Networking: Building blocks of TCP](https://hpbn.co/building-blocks-of-tcp/) ("The IP, or Internet Protocol, is what provides the host-to-host routing and addressing, and TCP, or Transmission Control Protocol, is what provides the abstraction of a reliable network running over an unreliable channel"; TCP hides "retransmission of lost data, in-order delivery, congestion control and avoidance, data integrity")
