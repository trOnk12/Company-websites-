# Design a feed from the screen to storage

## Continue from a cursor without losing tied rows

Choose one stable total order, such as descending publication time followed by descending unique post ID. A cursor records the boundary of the last result using the same keys. In an offline-capable client, write returned rows and the next-page key together. Let the screen observe local storage so it has one consistent view of appended pages.

### Worked example

The server has (time 10, id 9), (10, 8) and (9, 7). A one-row page ends at (10, 9). Filtering only for times below 10 skips ID 8. Seeking below the full pair returns (10, 8). A repeated page can be merged by stable post ID.

### Try it

A post can change its ranking score while the reader pages. Does a tie-breaker alone prevent all gaps?

### Compare your answer

No. A tie-breaker solves equal-key ordering. A changing rank moves a post across the boundary. Freeze a ranking version, accept defined movement or refresh the list. Specify which behavior the reader can rely on.

[Source · Android Developers · Paging with network and database](https://developer.android.com/topic/libraries/architecture/paging/v3-network-db)

## Cache the representation you actually display

An image cache key identifies a specific representation. Include identity, version and requested transformation when they affect bytes or pixels. Encoded file size and decoded memory occupy different budgets. Honor HTTP cache directives and validators when reusing server responses, and keep private images scoped to an authorized user.

### Worked example

A 2,000 × 1,500 image decoded into four bytes per pixel takes about 12 MB before overhead. A 200 × 150 thumbnail needs about 120 kB with the same format. A compressed download of 250 kB is not the correct number to use for the full-size memory cache.

### Try it

The avatar URL stays constant across profile edits. How can the next screen show the new image without unconditionally downloading every old avatar?

### Compare your answer

Use a versioned representation identity or a freshness policy with a validator. When stale, validate the cached response and replace it if changed. Invalidate transformed thumbnails associated with the obsolete version.

[Source · RFC 9111 · HTTP caching](https://www.rfc-editor.org/rfc/rfc9111.html)

## Reconcile an offline edit against the version it changed

An offline-first client persists the user’s intended change and a pending synchronization record locally. Attach a stable operation identity for retries and the base record version for conflict detection. An acknowledged write and a stale edit require different recovery paths. Define per-field or whole-record merge semantics before automating reconciliation.

### Worked example

Two phones read bookmark v4. Ada changes its title while offline; Ben changes its title online, producing v5. When Ada reconnects, a conditional save against v4 fails. Preserve her draft, fetch v5 and present both titles. If they changed independent fields and the product permits merging, the client can build and submit a fresh conditional update.

### Try it

The connection closes after Ada’s write is accepted and before its reply arrives. Is that the same as a confirmed conflict?

### Compare your answer

No. Recover the operation’s outcome by identity before deciding to overwrite or prompt for a merge. A version mismatch on replay alone does not establish who made the previous change.

[Source · Android Developers · Offline-first data layer](https://developer.android.com/topic/architecture/data-layer/offline-first)

## Choose an update channel by the freshness promise

Periodic polling asks on a schedule even when nothing changed. Long polling holds a request until an event or timeout and then opens another. A WebSocket maintains a bidirectional channel for foreground exchanges. Platform push can wake or notify the client under platform delivery policies. Each approach needs reconnection and a way to find changes missed during a gap.

### Worked example

At an idealized 30-second poll interval, 6,000 continuously active clients generate about 200 polls/s before retries. A long poll can reduce empty responses but consumes open connections. A foreground collaborative screen may justify a socket; a background feed can treat a push as a hint to fetch a durable change list.

### Try it

A phone has applied event 51, sleeps, then receives a hint for event 58. Which data should it request?

### Compare your answer

Request the durable changes after 51, apply them in order or according to the chosen merge rule, and persist the new cursor with the local update. If the server no longer retains the gap, perform a snapshot resync.

[Source · RFC 6202 · Long polling and streaming](https://www.rfc-editor.org/rfc/rfc6202.html)

## Roll out an implementation independently of installation

A feature flag lets compatible clients select between code paths. Define a default, a stable cohort assignment and a measurable condition for expanding or stopping. Keep both paths compatible with any stored data they may encounter. Disabling a flag cannot reverse an irreversible data conversion.

### Worked example

Release a new feed loader disabled. Enable it for a stable 5% cohort; compare load success, latency and stale-list reports with a control group on the same client version. Persist a safe default when configuration is unavailable. Test switching the flag off after the new loader has cached a page.

### Try it

Why can a repeatedly randomized five-percent choice per request make a mobile rollout harder to diagnose?

### Compare your answer

One person can move between implementations within one session and carry state between them. Use stable assignment for the experiment, label measurements by exposure and preserve a compatible fallback.

[Source · Firebase · Remote Config rollouts](https://firebase.google.com/docs/remote-config/rollouts)

[[Practice chapter 2|Measure what happened on real devices]]

[[Course map]]