# Measure what happened on real devices

## Give crash and unresponsive rates a denominator

A crash ends a process abnormally; an application-not-responding event captures a failure to respond under platform conditions. Define whether you count events, affected users, sessions or operations and over which interval. Platform vitals have specific user-based definitions. Avoid comparing them directly to an independently defined per-request rate.

### Worked example

In a fictional day 100 users open the app. One user crashes five times and another crashes once. The affected-user fraction is 2%, while the raw event count is six. If one of those users also experiences an unresponsive screen, summing separate affected-user counts double-counts that person.

### Try it

A release with fewer overall users has fewer total crashes. What would make a comparison informative?

### Compare your answer

Compare equivalent affected-user measures over the same window, with cohort sizes, version, device mix and uncertainty visible. Inspect the new stack or trace grouping as well as the aggregate.

[Source · Android Developers · Android vitals](https://developer.android.com/google/play/vitals)

## Spend a network error budget on a user journey

A service-level indicator is an observed fraction, such as completed feed refreshes divided by eligible refreshes. A service-level objective sets its target over a window. The error budget is the permitted shortfall. Decide what counts as good when offline reading works but refreshing fails, and avoid counting each transport retry as an independent user journey.

### Worked example

A target of 99.5% successful refreshes across 20,000 attempts allows 100 unsuccessful journeys. If 70 have failed, 30 remain. Five hundred failed low-level calls could represent fewer failed refreshes if retries eventually completed within the deadline. Track both layers with separate names.

### Try it

If 40 of the next already-budgeted journeys fail, what has happened to the original allowance?

### Compare your answer

There are now 110 failures against the fixed 100 allowance, ten beyond it. For a rolling window, recalculate numerator and denominator as older events leave and new ones arrive.

[Source · Google SRE · Implementing SLOs](https://sre.google/workbook/implementing-slos/)

## Connect a slow screen to searchable events

Emit structured observations with stable fields for operation, app version, outcome and elapsed time. Use a correlation or trace ID to follow one refresh through the phone and server when available. Prefer an operation name to a full URL containing user data. Keep credentials and private content out of diagnostic events.

### Worked example

An event for feed.refresh has outcome timeout, version 14, elapsed 1,980 ms and a trace ID. The server trace shows a 90 ms handler after the request arrived. Inspect client queueing, connectivity, network transit and rendering; the difference does not automatically belong to any single stage.

### Try it

Two logs contain the same bookmark title. Is that reliable evidence that they belong to one refresh?

### Compare your answer

No. Different users and retries can produce identical titles. Use a generated request or trace identity with a clear retry relationship. Query by structured fields without copying user content into logs.

[Source · OpenTelemetry · Logs Data Model](https://opentelemetry.io/docs/specs/otel/logs/data-model/)

## Read the tail without discarding the average

A percentile is a position in ordered observations. For nearest-rank p99 of 100 successful requests, inspect position 99. A mean describes total duration divided by count; the tail describes a different experience. State whether timeouts and failed requests are excluded and report their frequency separately.

### Worked example

Ninety-eight requests take 100 ms and two take 2,000 ms. The mean is (9,800 + 4,000) / 100 = 138 ms. Position 99 is 2,000 ms. A change that improves the fast requests can lower the mean while leaving both very slow users unaffected.

### Try it

Can you average the p99 from a small Wi-Fi cohort and a large cellular cohort to get the overall p99?

### Compare your answer

No. Combine underlying observations or compatible histograms weighted by their actual counts and compute the percentile again. Keep cohort-level tails too, because a small affected population can disappear in the aggregate.

[Source · Google SRE · Monitoring distributed systems](https://sre.google/sre-book/monitoring-distributed-systems/)

[[Final project]]

[[Course map]]