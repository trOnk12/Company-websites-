---
source: https://pachulski.dev/course/sysdesign/
tags: [course/sysdesign]
---

# Mobile system design, from a packet to an app

What really decides how fast, how frugal and how reliable your app's networking is: round trips, handshakes, the phone's radio, HTTP caching, offline-first data and safe retries. The building blocks every mobile system design interview stands on, one small puzzle at a time.

From [pachulski.dev](https://pachulski.dev/course/sysdesign/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: The network under your app

Round trips, handshakes, the radio, caching, offline-first data and safe retries.

- [[00 What actually travels]]: Your app calls an API and gets JSON back, as if the two were joined by a pipe. Underneath, there's no pipe: only small chunks of data that can get lost. Here's the stack of layers that turns them into a request and a response.
- [[01 Finding the server]]: Puzzle 0 said every packet carries an address. Your code never writes one: it writes a name like api.example.com. Here's how the phone turns that name into a number, and what that costs.
- [[02 Anatomy of an HTTP call]]: Retrofit hides the request behind an annotation and hands you an object back. The rest of this course reads the parts it hides. Here they are, once, mapped to the Retrofit code you already write.
- [[03 Round trips, not bandwidth]]: Your profile screen loads in a blink on office Wi-Fi and crawls on the train. The data is 60 KB. Here's what the user is actually waiting for, and why a faster network barely helps.
- [[04 What HTTPS adds]]: Every request your app makes is encrypted. That adds three promises on top of TCP, and one more step before the first byte. Here's what you get and what it costs, without the cryptography.
- [[05 One connection, many requests]]: Puzzle 3 counted round trips per request. A brand-new HTTPS connection adds its own before the first request even leaves. Here's what they cost, and how OkHttp makes them a one-time price.
- [[06 The radio is the battery]]: Your app sends a tiny analytics ping every 20 seconds. Each is a few hundred bytes. Users report the app drains their battery. Here's why the size of a request has almost nothing to do with its cost.
- [[07 Ask before you download]]: Your feed downloads the same 200 KB every time the screen opens, even when nothing changed. HTTP already has the answer. Here's how a response says how long it stays good, and how the app asks "has this changed?" for almost nothing.
- [[08 The database is the truth]]: The user opens your notes app in a tunnel: a spinner, then an error. On the next screen, a note they just wrote is missing. Both have one cause. Here's the structure Android recommends instead: one place every screen reads from.
- [[09 When the connection breaks]]: Puzzle 0 said TCP resends lost packets. Yet requests still fail after a while, and sometimes you can't tell whether the server did the work. Here's where TCP's promise ends, and the question the app then can't answer.
- [[10 Retry without charging twice]]: The user taps Pay. The request times out. Did the payment go through? Retrying might charge them twice; not retrying might lose the order. Here's how a key makes retries safe, and how to retry without flooding a struggling server.

## Coming next

- Module 2: Designing a feature end to end (coming): A feed with pagination and cursors; images and their cache; sync with conflicts; real-time updates (polling, long polling, WebSockets, push); rolling out safely with flags.
- Module 3: Seeing it in production (coming): Metrics that matter, crash and ANR rates, network error budgets, logs you can search, and why p99 matters more than the average.

[[Glossary]]
