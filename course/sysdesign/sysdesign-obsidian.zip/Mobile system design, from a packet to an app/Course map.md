---
source: https://pachulski.dev/course/sysdesign/
tags: [course/sysdesign]
---

# Mobile system design, from a packet to an app

What really decides how fast, how frugal and how reliable your app's networking is: round trips, handshakes, the phone's radio, HTTP caching, offline-first data and safe retries. The building blocks every mobile system design interview stands on, one small puzzle at a time.

From [pachulski.dev](https://pachulski.dev/course/sysdesign/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: The network under your app

Round trips, handshakes, the radio, caching, offline-first data and safe retries.

- [[00 Round trips, not bandwidth]]: Your profile screen loads in a blink on office Wi-Fi and crawls on the train. The data is 60 KB. Here's what the user is actually waiting for, and why a faster network barely helps.
- [[01 One connection, many requests]]: Puzzle 0 counted round trips per request. A brand-new HTTPS connection adds its own before the first request even leaves. Here's what they cost, and how OkHttp makes them a one-time price.
- [[02 The radio is the battery]]: Your app sends a tiny analytics ping every 20 seconds. Each is a few hundred bytes. Users report the app drains their battery. Here's why the size of a request has almost nothing to do with its cost.
- [[03 Ask before you download]]: Your feed downloads the same 200 KB every time the screen opens, even when nothing changed. HTTP already has the answer. Here's how a response says how long it stays good, and how the app asks "has this changed?" for almost nothing.
- [[04 The database is the truth]]: The user opens your notes app in a tunnel: a spinner, then an error. On the next screen, a note they just wrote is missing. Both have one cause. Here's the structure Android recommends instead: one place every screen reads from.
- [[05 Retry without charging twice]]: The user taps Pay. The request times out. Did the payment go through? Retrying might charge them twice; not retrying might lose the order. Here's how a key makes retries safe, and how to retry without flooding a struggling server.

## Coming next

- Module 2: Designing a feature end to end (coming): A feed with pagination and cursors; images and their cache; sync with conflicts; real-time updates (polling, long polling, WebSockets, push); rolling out safely with flags.
- Module 3: Seeing it in production (coming): Metrics that matter, crash and ANR rates, network error budgets, logs you can search, and why p99 matters more than the average.

[[Glossary]]
