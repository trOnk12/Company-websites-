# Glossary: Android from the foundation

Every word the course teaches, in the order it does. #flashcards/android/words

memory::The data a program keeps while it runs; each process has its own. (taught in [[00 A running app is a process]])

process::A running program, with its own private memory. (taught in [[00 A running app is a process]])

kernel::The core of the operating system: it shares the CPU, memory and files among processes, and is the only code that can reach into any process. (taught in [[01 The kernel is in charge]])

Linux::A free operating system, first made for computers shared by many people; Android is built on it. (taught in [[01 The kernel is in charge]])

operating system::The software that runs the phone itself and lets apps run on it; Android is one, built on Linux. (taught in [[01 The kernel is in charge]])

main thread::The one thread in your app that runs all screen code: the clerk. (taught in [[02 Threads are the workers]])

thread::One worker inside a process that runs code, one step after another. (taught in [[02 Threads are the workers]])

lock::Something that lets only one thread at a time into a piece of code; the others wait. (taught in [[03 Threads share one house]])

race condition::A bug where the result depends on the exact order two threads ran their steps in, like a lost update. (taught in [[03 Threads share one house]])

thread-safe::Safe to use from several threads at the same moment. (taught in [[03 Threads share one house]])

Activity::One screen of an Android app. (taught in [[04 Who decides about your screens]])

lifecycle::The stages a screen goes through (created, started, resumed, paused, stopped, destroyed), each decided by system_server. (taught in [[04 Who decides about your screens]])

system_server::The Android process that keeps the register of every app and screen and decides what happens to them: the town hall. (taught in [[04 Who decides about your screens]])

Binder::The kernel's way of carrying messages between processes: the post office. (taught in [[05 The post office carries letters]])

driver::A part of the kernel that does one job, like carrying Binder messages. (taught in [[05 The post office carries letters]])

callback::A method you write that someone else calls when it's time. (taught in [[06 You don't call. You're called]])

onCreate()::The callback that sets up an Activity. You write it; the system calls it. (taught in [[06 You don't call. You're called]])

sandbox::The walls the kernel keeps around each app's files and memory. (taught in [[07 Each app gets its own account]])

UID::The Linux user ID Android gives each app at install: its key. (taught in [[07 Each app gets its own account]])

Intent::A letter asking system_server to open a screen, in another app or your own. (taught in [[08 Letters between apps]])

permission::A right an app must be granted, such as using the camera; system_server checks it. (taught in [[08 Letters between apps]])

ART::The Android Runtime: the translator inside each app's process that runs DEX. (taught in [[09 What's inside the APK]])

DEX::The instructions your Kotlin compiles to: not tied to any CPU, shipped in the APK. (taught in [[09 What's inside the APK]])

interpreting::Running DEX one instruction at a time, without translating it first. (taught in [[09 What's inside the APK]])

machine code::Instructions one particular CPU runs directly. (taught in [[09 What's inside the APK]])

AOT::Ahead-of-time: code is translated to machine code before it's needed, by a system tool. (taught in [[10 Faster code, now and later]])

Baseline Profile::A profile written by the app's developers and shipped inside the APK. (taught in [[10 Faster code, now and later]])

dex2oat::The system tool that translates DEX ahead of time. (taught in [[10 Faster code, now and later]])

JIT::Just-in-time: ART translates busy (hot) code to machine code while the app runs. (taught in [[10 Faster code, now and later]])

profile::ART's notebook of which code was hot. (taught in [[10 Faster code, now and later]])

boot::The phone starting up. (taught in [[11 Zygote, the process every app starts from]])

fork::Asking the kernel for a new process that starts as a copy of an existing one. (taught in [[11 Zygote, the process every app starts from]])

framework::Android's own code that every app uses, such as the Activity class. (taught in [[11 Zygote, the process every app starts from]])

main()::The method where a program starts running. (taught in [[11 Zygote, the process every app starts from]])

Zygote::The process Android starts at boot with ART and the framework loaded; every app starts as a copy of it. (taught in [[11 Zygote, the process every app starts from]])

ZygoteInit.main()::Zygote's starting point in the Android source. (taught in [[11 Zygote, the process every app starts from]])

copy-on-write::Shared pages are copied only when one process writes to them. (taught in [[12 Sharing memory without sharing mistakes]])

page::A small fixed-size block of memory: the unit the kernel hands out. (taught in [[12 Sharing memory without sharing mistakes]])

cached process::A process of an app the user left, kept only so it starts faster; the first to be ended. (taught in [[13 When memory runs out, who goes]])

foreground process::The process of the app the user is using right now; the last to be ended. (taught in [[13 When memory runs out, who goes]])

importance::A measure of how much the user would notice if a process disappeared; it helps Android choose candidates for reclaim. (taught in [[13 When memory runs out, who goes]])

low-memory killer::The Android daemon that selects eligible processes for termination under memory pressure, taking importance into account. (taught in [[13 When memory runs out, who goes]])

Application::Your app's one object per process, created before any screen. (taught in [[14 Starting an app, cold, warm and hot]])

Application.onCreate()::The callback that runs once per process, before the first screen. (taught in [[14 Starting an app, cold, warm and hot]])

cold start::Starting an app that has no process yet. (taught in [[14 Starting an app, cold, warm and hot]])

Binder thread::A thread each process keeps waiting for incoming Binder calls: a courier. (taught in [[15 Inside a Binder call]])

Binder.getCallingUid()::Reads the UID the kernel stamped on the current call. (taught in [[15 Inside a Binder call]])

drivers/android/binder::Where the Binder driver lives in the Linux source. (taught in [[15 Inside a Binder call]])

Parcel::The flat envelope of bytes that carries a call's arguments between processes. (taught in [[15 Inside a Binder call]])

proxy::A stand-in in your process that looks like a service in another process. (taught in [[15 Inside a Binder call]])

startActivity()::How your app asks system_server to open a screen. (taught in [[15 Inside a Binder call]])

ActivityThread::Android's own code in your process that creates and destroys your Activities on the main thread. (taught in [[16 The main thread's queue]])

ActivityThread.main()::Where every app process starts; it runs the main thread's loop. (taught in [[16 The main thread's queue]])

Handler::The slot that drops a message into one thread's queue. (taught in [[16 The main thread's queue]])

Looper::The endless loop that takes the next message and runs it. (taught in [[16 The main thread's queue]])

message queue::The main thread's in-tray: the list of messages waiting to run. (taught in [[16 The main thread's queue]])

ANR::Application Not Responding: the dialog shown when a touch waits too long. (taught in [[17 Frames, jank and ANRs]])

frame::One redraw of the screen, about every 16 ms. (taught in [[17 Frames, jank and ANRs]])

input channel::A direct line from system_server into your app, one per window, that carries touches. (taught in [[17 Frames, jank and ANRs]])

jank::Visible stutter when frames are skipped. (taught in [[17 Frames, jank and ANRs]])

window::The rectangle of the display a screen of your app is drawn in. (taught in [[17 Frames, jank and ANRs]])

runOnUiThread { }::An Activity's shortcut to post code to the main thread. (taught in [[18 Slow work off the main thread, and back]])

thread { }::Kotlin's way to start a new thread that runs the code in the braces. (taught in [[18 Slow work off the main thread, and back]])

worker thread::Any thread that isn't the main thread, used for slow work. (taught in [[18 Slow work off the main thread, and back]])

Binder buffer::The mailbox each process has for incoming Binder calls: about 1 MB, shared by all calls in progress. (taught in [[19 How big can a Binder call be]])

transaction::One Binder call, carried from one process to another. (taught in [[19 How big can a Binder call be]])

TransactionTooLargeException::Thrown when a call doesn't fit the Binder buffer. (taught in [[19 How big can a Binder call be]])

configuration change::A change to the phone's setup that can change how screens should look: turning the phone, dark mode, language. (taught in [[20 Turn the phone, lose your screen]])

recreated::Destroyed and built again from scratch as a new object. (taught in [[20 Turn the phone, lose your screen]])

isChangingConfigurations::True while an Activity is being destroyed only to be recreated. (taught in [[21 The ViewModel outlives the screen]])

onCleared()::The ViewModel callback that runs when its store is cleared for good. (taught in [[21 The ViewModel outlives the screen]])

ViewModel::An object made to hold one screen's data, kept across configuration changes. (taught in [[21 The ViewModel outlives the screen]])

viewModels()::Gets this screen's ViewModel from its store, creating it the first time. (taught in [[21 The ViewModel outlives the screen]])

ViewModelStore::The small map an Activity keeps its ViewModels in: name → ViewModel. (taught in [[21 The ViewModel outlives the screen]])

Bundle::A small map of simple values (text, numbers) that can be packed into a Parcel. (taught in [[22 When the process is gone]])

onSaveInstanceState()::The Activity callback where it fills its Bundle before it's stopped. (taught in [[22 When the process is gone]])

process death::Android ending an app's process, usually in the background to free memory. (taught in [[22 When the process is gone]])

saved state::A small Bundle your app hands to system_server to keep, so a screen can be rebuilt after process death. (taught in [[22 When the process is gone]])

SavedStateHandle::A map a ViewModel can read and write that is kept in the saved state. (taught in [[22 When the process is gone]])
