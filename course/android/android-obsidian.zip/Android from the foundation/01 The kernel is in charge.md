---
course: "Android from the foundation"
puzzle: 1
source: https://pachulski.dev/course/android/01-the-kernel-is-in-charge
tags: [course/android]
---

# The kernel is in charge

> [!summary] The idea to keep
> Processes never deal with the CPU or memory directly. They ask the kernel, which shares them out and keeps every process in its place.

**Builds on:** [[00 A running app is a process]]

## The problem

In puzzle 0, every running app was its own process with its own memory. But the phone has one CPU (the chip that runs a program's instructions, one after another; real phones have a few, but picture one) and one pool of memory for all of them. Who decides which process runs right now, and who hands out the memory?

## See it

![The kernel is in charge](https://pachulski.dev/course/android/gifs/kernel.gif)

Step through it: https://pachulski.dev/course/android/01-the-kernel-is-in-charge

## The building block

The phone runs its own software underneath the apps: the **operating system**. Android is an operating system, built on **Linux**: a free operating system first made for computers shared by many people.

At its core is the **kernel**. It shares the CPU between processes, switching between them many times a second, so they all seem to run at once. It hands out memory, and it opens files. Because the kernel hands out every process's memory, it can reach into any process. A process can only reach the memory it was given.

## The analogy

The processes are houses on a street. The kernel is the street's management: it decides who gets electricity right now, hands out building space, and is the only one who can enter every house.

## Check yourself

#flashcards/android

One CPU, two apps both busy. How do both get work done?::The kernel switches the CPU between them many times a second. The kernel shares the CPU by switching between processes very often.

An app needs more memory. Who gives it?::The kernel. Memory is handed out by the kernel; processes ask for it.

What's the difference between the kernel and the operating system?::The kernel is the core part of the operating system. Android is the operating system; the kernel is its core.

## Sources

- [Android Developers: Platform architecture (Linux kernel)](https://developer.android.com/guide/platform)
- [Android Developers: Processes and threads overview](https://developer.android.com/guide/components/processes-and-threads)
