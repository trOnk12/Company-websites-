---
course: "Android from the foundation"
puzzle: 10
source: https://pachulski.dev/course/android/10-faster-code-now-and-later
tags: [course/android]
---

# Faster code, now and later

> [!summary] The idea to keep
> JIT = translate busy code now, while the app runs. AOT = translate it ahead of time, later, from ART's notes. A Baseline Profile sends those notes with the APK.

**Builds on:** [[01 The kernel is in charge]] · [[09 What's inside the APK]]

## The problem

In puzzle 9, ART ran your DEX by interpreting it, which is slow. But some of your code runs thousands of times: scrolling a list, drawing the screen. Translating that once into machine code would pay off every time it runs again. When should that happen?

## See it

![Faster code, now and later](https://pachulski.dev/course/android/gifs/jit.gif)

Step through it: https://pachulski.dev/course/android/10-faster-code-now-and-later

## The building block

ART watches which code runs often, "hot" code, and translates it to machine code right away, while the app runs: that's **JIT**, just-in-time. That machine code lives in the process's memory, so it's gone when the process ends. It also writes down which code was hot in a notebook, the **profile**.

Later, about once a day while the phone is idle and charging, `dex2oat`, a program that's part of Android, translates the code in the profile to machine code and keeps it in a file on the phone: that's **AOT**, ahead-of-time. Next start, that code is fast from the first moment. It doesn't translate everything: that would take a long time and use storage, and most code is rarely used.

A **Baseline Profile** is a profile the app's developers write and ship inside the APK, so `dex2oat` can translate the important code when the app is installed, before its first launch.

## The analogy

The translator reads new recipes word by word, but recipes asked for often get translated on the spot and noted in a notebook. Once a day, at night, a professional translates everything in the notebook for good.

## Check yourself

#flashcards/android

Your app gets faster a few days after install, without an update. Why?::ART noted the hot code, and `dex2oat` later translated it ahead of time. The profile survives; AOT translation from it is what makes the next starts faster.

Why not translate all the DEX ahead of time, right at install?::Because translating all of it costs time and space, so a profile picks. The profile focuses the work on code that's actually used.

What's the difference between JIT and AOT?::When: JIT translates now, as the app runs, and AOT translates ahead of time, later. Same goal, different moment.

## Sources

- [Android Open Source Project: Implement ART just-in-time compiler](https://source.android.com/docs/core/runtime/jit-compiler)
- [Android Open Source Project: ART Service configuration (background dexopt)](https://source.android.com/docs/core/runtime/configure/art-service)
- [Android Developers: Baseline Profiles overview](https://developer.android.com/topic/performance/baselineprofiles/overview)
