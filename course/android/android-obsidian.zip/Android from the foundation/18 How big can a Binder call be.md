---
course: "Android from the foundation"
puzzle: 18
source: https://pachulski.dev/course/android/18-how-big-can-a-binder-call-be
tags: [course/android]
---

# How big can a Binder call be?

> [!summary] The idea to keep
> Calls into a process wait in its Binder buffer: about 1 MB, shared by every call in progress. A call that doesn't fit fails with TransactionTooLargeException. Send where the data is, not the data.

**Builds on:** [[15 Inside a Binder call]]

## The problem

In puzzle 15, your call crossed into system_server packed into a Parcel. An Intent (puzzle 8) can carry data along with it, like a photo, and even an Intent that opens one of your own screens goes into system_server and comes back out. But the Parcel has to wait somewhere in system_server until one of its Binder threads is free. How much room is there?

## See it

![How big can a Binder call be?](https://pachulski.dev/course/android/gifs/buffer.gif)

Step through it: https://pachulski.dev/course/android/18-how-big-can-a-binder-call-be

## The building block

Calls into a process wait in its **Binder buffer**: an area of that process's memory, set up by the kernel when the process first uses Binder. Its size is fixed then, so it can't grow later: about 1 MB.

That 1 MB is shared by every call in progress into that process, from every app. So a call can fail even when it's well under 1 MB, if many other calls are waiting at the same moment.

A call that doesn't fit fails with `TransactionTooLargeException` (a transaction is one Binder call). The fix is never a bigger Parcel: save the data somewhere both sides can reach, like a file, and send its name, or a number that identifies it. Inside your own app this just works: all its screens run as the same UID, so the sandbox lets every one of them read the file. (Letting another app read your file needs system_server to grant it access: a later puzzle.)

Splitting the data into many smaller calls doesn't help either: they all go through the same shared 1 MB, and the receiver would have to glue the pieces back together.

## The analogy

The town hall's mailbox has one fixed size, shared by everyone's letters. A parcel that doesn't fit the slot comes back. So you leave the parcel at home and send a note that says where it is.

## Check yourself

#flashcards/android

You put a 3 MB photo into an Intent and start an Activity. What happens?::It fails with `TransactionTooLargeException`. Every Intent crosses Binder, through a buffer of about 1 MB.

Your app's call into system_server carries 400,000 bytes (0.4 MB). It works most of the time but fails now and then. Why?::The 1 MB is shared by every call in progress, so when others are waiting there's less room. A shared, fixed-size buffer: other calls take room too.

How do you show a big photo on another screen of your own app?::Save it to a file and send the file's name. Send a small reference; let the other side read the data itself.

## Sources

- [Android reference: TransactionTooLargeException](https://developer.android.com/reference/android/os/TransactionTooLargeException) ("The Binder transaction buffer has a limited fixed size, currently 1MB, which is shared by all transactions in progress for the process.")
- [Android reference: Parcel](https://developer.android.com/reference/android/os/Parcel)
