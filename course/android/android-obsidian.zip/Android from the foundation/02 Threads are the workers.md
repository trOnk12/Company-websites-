---
course: "Android from the foundation"
puzzle: 2
source: https://pachulski.dev/course/android/02-threads-are-the-workers
tags: [course/android]
---

# Threads are the workers

> [!summary] The idea to keep
> A process can have many threads, but only one, the main thread, draws your screen and handles taps. If it's busy, the screen waits.

**Builds on:** [[01 The kernel is in charge]]

## The problem

In puzzle 1, the kernel handed the CPU to a process. But a process often needs to do several things at once: download a song, play it, and keep the screen responsive. Who actually runs the code inside a process?

## See it

![Threads are the workers](https://pachulski.dev/course/android/gifs/threads.gif)

Step through it: https://pachulski.dev/course/android/02-threads-are-the-workers

## The building block

A **thread** is a worker inside a process. It runs code one step after another. A process can have several threads, and the kernel gives each of them turns on the CPU, just as it does with processes.

Every Android app has one special thread: the **main thread**. It's the one that draws the screen and handles taps. Other threads can download or calculate, but anything on the screen is the main thread's job. (Why only one thread? Puzzle 16.)

## The analogy

Inside the house work several people. One of them, the clerk at the front desk, deals with everything visitors see: that's the main thread. The others work in the back.

## Check yourself

#flashcards/android

The main thread is busy for 3 seconds sorting a huge list. The user taps a button. What happens?::The tap waits until the main thread is free. Only the main thread handles taps and drawing, so while it's busy, the screen waits.

Why put a download on another thread, not the main thread?::Because then the main thread stays free for the screen and taps. The main thread must stay free for the screen.

What's the difference between a process and a thread?::A process is a running app with its own memory, while threads are the workers inside it. Threads live inside a process and share its memory.

## Sources

- [Android Developers: Processes and threads overview](https://developer.android.com/guide/components/processes-and-threads)
