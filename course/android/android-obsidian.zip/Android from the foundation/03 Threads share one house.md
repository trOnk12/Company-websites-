---
course: "Android from the foundation"
puzzle: 3
source: https://pachulski.dev/course/android/03-threads-share-one-house
tags: [course/android]
---

# Threads share one house

> [!summary] The idea to keep
> Threads share an address space. To publish changes reliably, coordinate access using a common lock, an atomic operation or messages to one owner. Two unsynchronized increments can lose an update even if neither thread crashes.

**Builds on:** [[02 Threads are the workers]]

## The problem

In puzzle 2, a download thread and the main thread worked in the same process. The download finishes and has a result: how does the main thread get it? And if both threads can reach the same data, what happens when both change it at once?

## See it

![Threads share one house](https://pachulski.dev/course/android/gifs/shared.gif)

Step through it: https://pachulski.dev/course/android/03-threads-share-one-house

## The building block

A process has one block of memory (puzzle 0), and every thread inside it can read and write all of it. Sharing memory makes communication possible. Without a lock, an atomic operation or another synchronization rule, another thread has no guarantee about when it observes a write. That's how threads cooperate: one prepares data, another uses it.

The danger is changing the same value at the same moment. Even `count = count + 1` can be understood as three logical steps: read the value, add one, write it back. If two threads both read 5, both add one and both write 6, one update is lost: the count should be 7. This is a **race condition**: the result depends on the exact order the kernel happened to run their steps in, so it works most of the time and breaks once in a while.

Two common solutions follow. A **lock** lets only one thread at a time into a piece of code: the second one waits until the first is done. Or give the value **one owner**: only one thread ever touches it, and the others ask it to.

Code that stays correct when several threads use it at once is **thread-safe**. Android's screen code isn't, so it uses the second way. Buttons, text and everything drawn belong to the main thread, and no other thread may change them. Puzzle 16 shows how other threads ask the main thread to do it for them.

## The analogy

The house has one whiteboard everybody can write on. Two people each read "5 visitors", each add one, each write "6": one visitor vanished. Either they take turns with the marker (a lock), or only the clerk may write on it and the others hand her notes (one owner).

## Check yourself

#flashcards/android

Two threads each add 1 to the same counter, 1,000 times, with no lock. The counter starts at 0. What can it end at?::Sometimes 2,000, sometimes less: updates can be lost when their steps interleave. Read, add, write: two threads can read the same old value.

A download thread has a result for the screen. What's the safe way to show it?::Hand it to the main thread, which owns the screen, and let it update the text. One owner: only the main thread touches the screen.

What's the difference between a lock and one owner?::A lock lets every thread in, but one at a time; one owner lets only one thread ever touch it. Turns at the marker vs only the clerk writes.

## Sources

- [Android Developers: Processes and threads overview](https://developer.android.com/guide/components/processes-and-threads) ("the Android UI toolkit is not thread-safe. So, don't manipulate your UI from a worker thread. Do all manipulation to your user interface from the UI thread.")
- [Kotlin docs: Shared mutable state and concurrency](https://kotlinlang.org/docs/shared-mutable-state-and-concurrency.html) ("Coroutines can be executed parallelly using a multi-threaded dispatcher like the Dispatchers.Default. It presents all the usual parallelism problems. The main problem being synchronization of access to shared mutable state.")
