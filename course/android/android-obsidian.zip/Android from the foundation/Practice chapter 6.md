# Inside AOSP: follow a platform service

## Read a service declaration from boot to process

Android Open Source Project (AOSP) includes init, the first user-space process. Init reads configuration files ending in .rc. A service declaration names a program and its options. An action connects a trigger, such as a property changing value, to commands. To explain why a program appeared, find both its declaration and the action or class start that launched it.

### Worked example

Read this miniature configuration as two stanzas. The first starts with “service fieldlog /vendor/bin/fieldlog” and contains the option “disabled”. The second starts with “on property:vendor.fieldlog.enabled=1” and contains the command “start fieldlog”. The program can be installed throughout boot. The disabled option leaves it out of the ordinary class start, and the explicit start requests it when the action runs.

### Try it

On an Android emulator with adb connected, run adb shell getprop init.svc.zygote. Record the result and the emulator build. If it says running, can you conclude that the launcher has already drawn its first frame?

### Compare your answer

Running identifies init's observed service state. The launcher can still be starting. Frame presentation needs a separate observation on the launcher or display timeline. If the property is empty, list the available init.svc properties with adb shell getprop and locate a service declared by that build before drawing a conclusion.

[Source · AOSP · Android init language and service states](https://android.googlesource.com/platform/system/core/+/refs/heads/main/init/README.md)

## Locate a failing call across the hardware boundary

A hardware abstraction layer (HAL) gives platform code an interface to a device-specific implementation. For a binderized HAL, client and implementation live in separate processes. The service registers an instance so a client can find it. AIDL, the Android Interface Definition Language, specifies calls and data across that boundary. A service can start successfully and still return an error when it tries to use the hardware.

### Worked example

Consider a camera request on a build with a binderized camera provider. The app reaches the framework camera service. Its provider lookup succeeds. The provider receives an open request and reports that the device is unavailable. These observations locate the failure after lookup. The device might be occupied, disconnected or in another implementation-defined failure state. A registered instance alone cannot distinguish those explanations.

### Try it

Two traces show the same app error. Trace A ends with provider lookup unsuccessful. Trace B contains provider entry, then a failed device operation. For each trace, choose the first boundary to inspect and predict one observation that would move your investigation elsewhere.

### Compare your answer

For A, compare the requested interface and instance with the provider registered on this build. A successful lookup for that exact instance during the failing request moves the investigation past discovery. For B, correlate the provider operation with device state and the request timestamp. A successful device operation followed by a failed reply moves the investigation toward the return path.

[Source · AOSP · Hardware abstraction layer overview](https://source.android.com/docs/core/architecture/hal)

## Decide whether a framework update fits a vendor image

Android can update its framework and device-specific implementation on different schedules. The vendor interface (VINTF) records the contract between them. A manifest describes capabilities a side provides. A compatibility matrix lists what the other side requires. Check both directions when evaluating an image pair. Passing this comparison establishes compatibility of the declarations; live behavior still needs a device test.

### Worked example

Use a simplified contract with exact instance names. The device manifest provides temperature/default. The candidate framework requires temperature/default and fan/default. In the other direction the device requires a diagnostics service that the framework does provide. The first direction fails because fan/default is missing. A successful temperature reading on the old build tells us nothing about this new requirement.

### Try it

An engineer adds fan/default to the manifest without shipping its implementation. Predict what a static comparison using only these declarations could accept. Design a runtime check that would expose the remaining gap.

### Compare your answer

The names in the simplified comparison now match. Boot the intended framework and vendor pair on the target device, resolve the named instance and issue a representative supported operation. Record the returned value or failure and a timestamp. Real VINTF matching also considers properties such as interface versions and the applicable matrix level.

[Source · AOSP · VINTF manifests and compatibility matrices](https://source.android.com/docs/core/architecture/vintf)

[[Practice chapter 7|Read Linux resource evidence]]

[[Course map]]