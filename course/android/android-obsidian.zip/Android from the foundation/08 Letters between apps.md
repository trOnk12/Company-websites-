---
course: "Android from the foundation"
puzzle: 8
source: https://pachulski.dev/course/android/08-letters-between-apps
tags: [course/android]
---

# Letters between apps

> [!summary] The idea to keep
> An Intent is a letter to the town hall: "open this screen". system_server checks the sender's permissions, then delivers it, or doesn't.

**Builds on:** [[05 The post office carries letters]] · [[07 Each app gets its own account]]

## The problem

In puzzle 7, the sandbox kept every app inside its walls. But a link in a chat opens the browser, and a chat app can start a phone call. If apps can't reach each other, how do they work together?

## See it

![Letters between apps](https://pachulski.dev/course/android/gifs/intents.gif)

Step through it: https://pachulski.dev/course/android/08-letters-between-apps

## The building block

An app sends an **Intent**: a message to system_server asking it to open a screen, in another app or in your own. It travels by Binder, like every message to the town hall.

Opening another app's screen often needs nothing special: a link in a chat opens the browser for anyone. But some actions need a **permission**: a right the app has to be granted. Placing a call straight away needs the phone-call permission, because calls can cost money. Some permissions are granted at install; risky ones, like this one, the user grants by tapping Allow in a prompt. system_server checks them before it acts. It knows which app sent the Intent from the app's UID, which Binder tells it (puzzle 15 shows how).

## The analogy

You can't walk into the neighbour's house, but you can send the town hall a letter: "please put a call through for me". The town hall checks its list of who's allowed what, then passes it on, or sends it back.

## Check yourself

#flashcards/android

A game sends an Intent asking to start a phone call, but the user never granted it the phone-call permission. What happens?::system_server refuses the request. system_server checks the sender's permissions before acting.

Why does an Intent go to system_server instead of straight to the other app?::Because apps can't reach each other, so the town hall delivers and checks permissions. Only the town hall can deliver between sandboxes, and it checks the sender on the way.

What's the difference between the sandbox and a permission?::The sandbox closes each app off, while a permission allows one specific action. Walls by the kernel; rights by the town hall.

## Sources

- [Android Developers: Intents and intent filters](https://developer.android.com/guide/components/intents-filters)
- [Android Developers: Permissions on Android](https://developer.android.com/guide/topics/permissions/overview)
- [Android reference: Intent.ACTION_CALL](https://developer.android.com/reference/android/content/Intent#ACTION_CALL) and [Manifest.permission.CALL_PHONE](https://developer.android.com/reference/android/Manifest.permission#CALL_PHONE)
- [Android reference: Binder](https://developer.android.com/reference/android/os/Binder)
