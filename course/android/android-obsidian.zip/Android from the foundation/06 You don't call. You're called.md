---
course: "Android from the foundation"
puzzle: 6
source: https://pachulski.dev/course/android/06-you-dont-call-youre-called
tags: [course/android]
---

# You don't call. You're called.

> [!summary] The idea to keep
> system_server decides → Binder carries the message → your main thread receives it → your code runs. You write onCreate(); you never call it.

**Builds on:** [[05 The post office carries letters]]

## The problem

You've met the five characters: your app's process (puzzle 0), the kernel (1), the main thread (2), system_server (3) and Binder (4). Now: when the town hall's message arrives, what actually runs in your app?

## See it

![You don't call. You're called.](https://pachulski.dev/course/android/gifs/chain.gif)

Step through it: https://pachulski.dev/course/android/06-you-dont-call-youre-called

## The building block

A **callback** is a method you write so that someone else can call it when the time comes. Lifecycle code is all callbacks: `onCreate()` sets up an Activity, and there's one callback for each lifecycle stage.

You write them. You never call them yourself. system_server decides, Binder delivers, and your main thread runs your callback. If you did call `onCreate()` by hand, it would only run your method: system_server's register wouldn't change, and no screen would appear.

(This picture is simplified: puzzles 15 and 16 show how the message gets from Binder to the main thread.)

## The analogy

You leave instructions on the clerk's desk ("when the town hall says open, do this"). The clerk follows them when the letter arrives. You never knock on the town hall's door asking to be opened.

## Check yourself

#flashcards/android

Your app calls `onCreate()` on its own Activity, by hand. What have you done?::Run your setup code, before the screen is created or shown. A callback is run by your main thread when system_server says it's time. Calling it yourself doesn't change what system_server decided.

Which thread runs your `onCreate()`?::Your app's main thread. The message reaches your main thread, which runs your callback.

Why does Android use callbacks instead of letting apps decide?::Because system_server makes the decisions, while your code only says what to do when they happen. The town hall decides when; your callback says what.

## Sources

- [Android Developers: The activity lifecycle](https://developer.android.com/guide/components/activities/activity-lifecycle)
- [Android Developers: Processes and threads overview](https://developer.android.com/guide/components/processes-and-threads)
