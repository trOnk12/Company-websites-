---
course: "Android from the foundation"
puzzle: 0
source: https://pachulski.dev/course/android/00-a-running-app-is-a-process
tags: [course/android]
---

# A running app is a process

> [!summary] The idea to keep
> An installed app is just files. A running app is a process, with its own memory that no other process can touch.

## The problem

You've built an app. But what actually happens when someone taps its icon? And why can a crashing game not take your notes app down with it? Everything in this course starts here.

## See it

![A running app is a process](https://pachulski.dev/course/android/gifs/processes.gif)

Step through it: https://pachulski.dev/course/android/00-a-running-app-is-a-process

## The building block

A **process** is a running program. When you tap an app's icon, Android can reuse an existing app process or start one. Leaving a screen need not end the process. The app's files stay installed either way.

Each process has its own **memory**: the data the program keeps while it runs, like the text you're typing or the list on the screen. One process can't see or change another process's own data in memory.

## The analogy

Each running app is a house. Its memory is everything inside the house. Neighbours live in their own houses: they can't walk into yours, and if a house burns down, the street is still standing.

## Check yourself

#flashcards/android

The music app crashes while your notes app is open. What happens to the note you were typing?::Nothing: the notes app is a separate process with its own memory. A crash ends only that process. Other processes keep their own memory.

Is an app you installed but haven't opened a process?::No: it's only files until it's started. A process is a running program. Installed but not running means files only.

Why can't one app read the text another app is showing?::Because it lives in the other process's memory, which only that process can reach. Each process's memory is private to that process.

## Sources

- [Android Developers: Processes and threads overview](https://developer.android.com/guide/components/processes-and-threads)
- [Android Developers: Overview of memory management](https://developer.android.com/topic/performance/memory-overview)
