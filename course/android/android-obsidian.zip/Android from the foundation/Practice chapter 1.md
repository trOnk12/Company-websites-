# Screens, windows and ownership

## Send a value across a process boundary

An object reference identifies an object within its process. To call a remote component, Binder carries a marshalled representation of arguments. The receiver can reconstruct values in its own memory. A Binder interface handle is a special case that enables later calls across the boundary.

### Worked example

Process A sends a parcel containing a note title equal to River. Process B decodes the title and renames its local note to Lake. A still reads River unless B sends a result or both consult shared durable storage.

### Try it

A callback needs to notify A when the edit completes. Would sending the original Java object address establish that callback?

### Compare your answer

No. Pass a supported Binder interface or another explicit reply mechanism. The remote process cannot dereference A’s object address.

[Source · Android · AIDL](https://developer.android.com/guide/components/aidl)

## Pass an identity through an Intent

An Intent describes the work to perform and can carry named extras. A screen opened by another component needs an explicit contract for names, types and missing values. Passing a small stable record ID also lets the destination load the current record after recreation.

### Worked example

The list adds putExtra("note_id", 17L). Detail reads a long with a reserved fallback, checks that the ID is valid and loads note 17. If it no longer exists, detail shows a missing-note state.

### Try it

Why is passing a 12 MB photo in the same extra a poor replacement for passing the ID?

### Compare your answer

Interprocess transactions have bounded buffer space and the image adds copying and lifetime problems. Pass a content reference with appropriate access and load only the required image size.

[Source · Android · Intents and intent filters](https://developer.android.com/guide/components/intents-filters)

## Match a Context to its owner

A Context provides access to resources and system services. An Activity context also carries screen configuration and theme. Holding that context holds its Activity as long as the reference remains reachable. A process-wide object can outlive many successive Activity instances.

### Worked example

Rotate a themed editor twice. The screen instances are A, B and C. A singleton that stores A as its listener can keep A and its view tree reachable after C appears. Remove the listener when its owner stops observing. Use an application context for a process-wide dependency when it meets the API’s needs.

### Try it

Should a themed dialog use the application context just to avoid a leak?

### Compare your answer

Use the active screen’s context for the dialog and bound the dialog’s lifetime to that screen. Correct ownership solves the leak while preserving window and theme information.

[Source · Android · Context](https://developer.android.com/reference/android/content/Context)

## Distinguish a task from a process

A task is a navigation history of activities. With ordinary launch behavior, starting a new activity adds an entry and Back removes the top activity. The system can preserve task information while reclaiming the app process. The current object instances and the navigation history have different lifetimes.

### Worked example

Open List, Detail and Edit. Back from Edit normally exposes Detail. Reopening a previously backgrounded task may recreate Detail if its original process died. Persist the record and retain a small ID for restoration.

### Try it

If Back reveals Detail, does that prove the same Detail object survived?

### Compare your answer

No. Compare navigation identity with object lifetime. A recreated Detail can render the same stored note using restored arguments.

[Source · Android · Tasks and the back stack](https://developer.android.com/guide/components/activities/tasks-and-back-stack)

## Follow a touch from parent to child

A window hosts a hierarchy of views. Once a gesture reaches that hierarchy, a parent ViewGroup can examine it, delegate to a child or intercept later movement. A child that had the gesture must handle cancellation when a parent takes it over.

### Worked example

A button receives DOWN inside a scrolling list. Motion later crosses the parent’s scrolling threshold. The parent intercepts, the child receives CANCEL and the parent handles the scroll. A button that commits on DOWN would have fired during an intended scroll.

### Try it

How would you test a row that accidentally opens while the list moves?

### Compare your answer

Record DOWN, MOVE, CANCEL and UP at parent and child. Compare a short tap with a drag crossing the threshold and make activation follow a completed click.

[Source · Android · Manage touch events in a ViewGroup](https://developer.android.com/develop/ui/views/touch-and-input/gestures/viewgroup)

[[Practice chapter 2|Work without a screen]]

[[Course map]]