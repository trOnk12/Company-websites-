# Libraries under the hood

## Build a dependency graph with explicit lifetimes

Constructor injection exposes the objects a class needs. Dagger constructs a graph using generated code; Hilt supplies Android-aware components and scopes on top of Dagger. The scope determines which consumers reuse an instance within that component.

### Worked example

A repository needs a database and a network client. Keep those dependencies in a process-level graph when their lifetimes require it. Create an editor presenter per screen so it can release screen state on destruction.

### Try it

Can a singleton repository safely retain an Activity supplied by a screen component?

### Compare your answer

Its longer lifetime would retain a short-lived screen. Pass the needed data or an appropriate process-scoped dependency and leave screen-specific behavior with its owner.

[Source · Android · Dependency injection with Hilt](https://developer.android.com/training/dependency-injection/hilt-android)

## Read a Koin definition as a construction rule

Koin resolves definitions from a running container. A single definition reuses an instance within its container lifetime; a factory constructs a fresh value per resolution. A scope can tie an object to a shorter-lived context. Validate that required bindings exist for the production composition.

### Worked example

Two requests for a single database receive the same defined instance. Two requests for a factory editor receive distinct editors. Storing a factory-created editor in a singleton can still extend its actual lifetime.

### Try it

A unit test needs an in-memory repository while the app uses disk. Where should the choice live?

### Compare your answer

Bind the implementation at composition or test setup. Keep the consumer’s constructor dependent on the repository contract so its behavior can be exercised independently.

[Source · Koin · Definitions](https://insert-koin.io/docs/reference/koin-core/definitions/)

## Trace Retrofit down to OkHttp

Retrofit maps a declared service method and annotations to an HTTP request and uses converters for supported body types. With an OkHttp-backed client, connection selection, network exchange and interceptors belong to the HTTP layer. Parsing application data and deciding how the UI handles failure are separate boundaries.

### Worked example

A GET method requests notes/17. The server returns HTTP 200 with malformed JSON. The transport received a successful HTTP response, yet the converter can fail before the repository gets a Note. Record the status and the conversion failure separately.

### Try it

If the network times out after a reservation write, would automatically repeating every failed Retrofit call be safe?

### Compare your answer

Recover the operation using a stable request identity and a defined server contract. A timeout does not establish whether the server committed the first attempt.

[Source · Retrofit · Official project](https://github.com/lysine-dev/retrofit)

## Follow one logical call through OkHttp

An OkHttp client owns resources such as a connection pool. Reusing a client allows compatible connections to be reused rather than paying setup for each request. A call can include multiple exchanges, for example when following a redirect. Closing a response body releases its resources.

### Worked example

Two small requests target the same HTTPS origin. The first establishes a connection; the second may use that still-healthy connection. A server close or incompatible route can force a new connection. Measure connection events rather than assuming that an identical URL proves reuse.

### Try it

A chart counts two network exchanges for one app request after a redirect. Does that prove the user tapped twice?

### Compare your answer

No. Record the logical call identity and its individual exchanges. Compare original destination, redirect response and final destination before interpreting the count.

[Source · OkHttp · Official project](https://github.com/lysine-dev/okhttp)

## Observe a Room query over SQLite

Room validates supported annotated SQL and generates DAO plumbing. SQLite still executes the transaction. An observable query can rerun when a table it depends on is invalidated. Schema design, indexes and transaction boundaries still determine work and consistency.

### Worked example

A DAO updates a note title and inserts its pending sync row. Put both statements inside one transaction. A process stop after commit leaves both; a failure before commit leaves neither. The UI observes the resulting local note table.

### Try it

The note is visible after restart but no sync work exists. Which boundary should you inspect?

### Compare your answer

Look for separate commits or an independently enqueued in-memory action. Persisting the pending intention with the note makes reconstruction possible.

[Source · Android · Save data using Room](https://developer.android.com/training/data-storage/room)

## Measure release code after R8 optimization

R8 can shrink unreachable code, optimize bytecode and rename classes or members. Code reached indirectly by reflection may require narrow keep rules. Startup also depends on actual initialization work and compilation, so reducing package size alone cannot establish a faster first frame.

### Worked example

A release build fails to construct a class looked up by name although debug works. Reproduce with the optimized variant, identify the reflective entry point and apply the smallest rule or library-supported declaration that preserves the required contract.

### Try it

After the fix, how would you test the claim that startup improved?

### Compare your answer

Benchmark equivalent release variants on the same device and startup mode. Compare first-display measurements and a trace, while holding compilation state and initial data constant.

[Source · Android · Enable app optimization with R8](https://developer.android.com/topic/performance/app-optimization/enable-app-optimization)

[[Final project]]

[[Course map]]