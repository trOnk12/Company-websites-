---
course: "Android from the foundation"
puzzle: 5
source: https://pachulski.dev/course/android/05-the-post-office-carries-letters
tags: [course/android]
---

# The post office carries letters

> [!summary] The idea to keep
> Between processes, nothing is reached directly. Binder, a driver in the kernel, carries the message, like a post office.

**Builds on:** [[04 Who decides about your screens]]

## The problem

In puzzle 4, system_server decided to move your Activity to "resumed". But system_server is a process, and so is your app, and in puzzle 0 you saw that one process can't touch another's memory. So how does the town hall's decision get into your app?

## See it

![The post office carries letters](https://pachulski.dev/course/android/gifs/post-office.gif)

Step through it: https://pachulski.dev/course/android/05-the-post-office-carries-letters

## The building block

Only the kernel can reach into every process (puzzle 1). So the kernel carries the message.

The kernel is made of parts that each do one job; such a part is called a **driver**. The driver that carries messages between processes is called **Binder**. The lifecycle instructions in this example travel through Binder. Android also has other channels, including the input path in puzzle 17.

## The analogy

The post office. The town hall writes a letter; it can't walk into your house, but the post office can deliver to every house on the street.

## Check yourself

#flashcards/android

system_server wants your Activity to pause. Can it change your app's memory directly?::No: it sends a message, and Binder carries it into your app. Separate processes never touch each other's memory; Binder carries the message.

Why does the message go through the kernel?::Because only the kernel can reach into every process. The kernel is the only code that can reach any process, so it does the carrying.

What's the difference between Binder and system_server?::Binder carries messages, while system_server decides what they say. The post office delivers; the town hall decides.

## Sources

- [Android Developers: Platform architecture](https://developer.android.com/guide/platform)
- [Android reference: Binder](https://developer.android.com/reference/android/os/Binder)
