---
course: "Android from the foundation"
puzzle: 14
source: https://pachulski.dev/course/android/14-starting-an-app
tags: [course/android]
---

# Starting an app, cold, warm and hot

> [!summary] The idea to keep
> Cold start = fork Zygote, create your Application, then the first Activity. Warm = process alive, Activity created again. Hot = both alive, just brought to the front.

**Builds on:** [[11 Zygote, the process every app starts from]] · [[13 When memory runs out, who goes]]

## The problem

In puzzles 11 and 12, a new app process was forked from Zygote. But is a process forked every time you open an app? Sometimes the app opens instantly, sometimes it takes a second. What's the difference?

## See it

![Starting an app, cold, warm and hot](https://pachulski.dev/course/android/gifs/start.gif)

Step through it: https://pachulski.dev/course/android/14-starting-an-app

## The building block

A process isn't kept forever: when memory runs low, the low-memory killer ends cached processes first (puzzle 13), so coming back to an app can need a fresh one.

Your app has one instance of its `Application` class per process: a place for setup the whole app needs, like opening the file where the app keeps its saved data. It's created right after the fork, and its callback `Application.onCreate()` runs before any Activity exists.

- **Cold start**: no process yet. Fork from Zygote, create the Application, then create the first Activity.
- **Warm start**: the process is still alive, but the Activity was destroyed (puzzle 4), for example because the user left it with Back, so it's created again.
- **Hot start**: process and Activity are both alive, stopped in the background; system_server just brings the screen back to the front.

## The analogy

Cold: build the house from the show house, move in, set up the room. Warm: the house stands, set up the room again. Hot: everything's ready, just open the curtains.

## Check yourself

#flashcards/android

You put slow setup (opening a big saved-data file) in `Application.onCreate()`. Which starts get slower?::Cold starts only: that's when the Application is created. Application.onCreate() runs once per process, in a cold start, before any screen.

The user comes back to your app a minute later and it opens instantly. Which kind of start was that likely?::Hot: process and Activity were still alive. Hot starts reuse everything.

What's the difference between a warm and a cold start?::Warm reuses the living process, while cold has to fork a new one first. Warm: process alive, screen rebuilt. Cold: everything from scratch.

## Sources

- [Android Developers: App startup time](https://developer.android.com/topic/performance/vitals/launch-time)
- [Android Developers: The activity lifecycle](https://developer.android.com/guide/components/activities/activity-lifecycle)
