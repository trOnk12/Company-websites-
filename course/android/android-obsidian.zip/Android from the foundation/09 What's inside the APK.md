---
course: "Android from the foundation"
puzzle: 9
source: https://pachulski.dev/course/android/09-whats-inside-the-apk
tags: [course/android]
---

# What's inside the APK

> [!summary] The idea to keep
> Your Kotlin compiles to DEX, which no CPU runs directly. ART, inside your app's process, runs it: at first by reading it one instruction at a time.

**Builds on:** [[00 A running app is a process]]

## The problem

You upload one APK (the single file your app is packaged into) to the store, and it runs on phones with very different CPUs. But a CPU only runs instructions (the tiny steps a program is made of) written for that kind of CPU. So what's in the APK, and who makes it run?

## See it

![What's inside the APK](https://pachulski.dev/course/android/gifs/apk.gif)

Step through it: https://pachulski.dev/course/android/09-whats-inside-the-apk

## The building block

Each kind of CPU has its own language: **machine code**. Your APK doesn't contain it. Your Kotlin compiles to **DEX**, compact instructions written for Android, not for any one CPU.

On the phone, **ART**, the Android Runtime (the part that runs your code), works inside your app's process and makes the DEX run. The simplest way it does that is **interpreting**: reading one DEX instruction at a time and doing what it says. That always works, but it's slow.

## The analogy

You write your recipes in one common language, so any kitchen can use them. In every house lives a translator, ART, who reads them to the cook word by word.

## Check yourself

#flashcards/android

You ship the same APK to two phones with different CPUs. Why does it run on both?::It contains DEX, and ART on each phone runs it. DEX isn't tied to a CPU; ART on each phone runs it.

Is there one ART for all the apps on the phone?::No: each app's process runs its own ART. Each process has its own ART.

What's the difference between DEX and machine code?::Machine code is for one kind of CPU, while DEX is for any Android phone. DEX needs ART; machine code needs nothing.

## Sources

- [Android Open Source Project: Android runtime and Dalvik](https://source.android.com/docs/core/runtime)
- [Android Developers: Platform architecture](https://developer.android.com/guide/platform)
