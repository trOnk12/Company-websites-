---
source: https://pachulski.dev/course/android/
tags: [course/android]
---

# Android from the foundation

Lifecycle, process death, ANRs, frozen screens: most of Android's hard parts come from a handful of ideas. This course builds them from the ground up, one small puzzle at a time, with pictures that move, until the rules stop being rules and start making sense.

From [pachulski.dev](https://pachulski.dev/course/android/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: The ground floor

What a running app is, who's in charge of the phone, and the four characters every later puzzle uses: your app, the kernel, the town hall and the post office.

- [[00 A running app is a process]]: When you open an app, the phone starts it as a separate program with its own private data. That's why one app crashing doesn't take the others down.
- [[01 The kernel is in charge]]: Something has to share the phone between all those processes. That's the core of the phone's own software, and it's the only thing that can reach into every process.
- [[02 Threads are the workers]]: Inside every process, the work is done by workers that run code one step at a time. One of them, in every app, is in charge of the screen.
- [[03 Threads share one house]]: All the threads in a process see the same memory. That's what makes them useful together, and it's also how two of them can quietly break the same value. Here's the trap, and Android's way around it for the screen.
- [[04 Who decides about your screens]]: Your app doesn't decide when its own screens appear or go away. A separate Android process does, and tells your app.
- [[05 The post office carries letters]]: system_server and your app are separate processes, so the town hall can't just reach in. The kernel carries its messages.
- [[06 You don't call. You're called]]: Put the characters you've met together, and you get the one chain behind all of Android's lifecycle code.

## Module 2: Apps and their code

Why apps can't touch each other, how they still talk, what's inside an APK, and how an app starts so fast.

- [[07 Each app gets its own account]]: The kernel keeps processes apart while they run. Android also keeps each app's files apart, by giving every app its own identity.
- [[08 Letters between apps]]: Apps can't reach into each other, but they can ask the town hall to deliver a request. For some requests, the town hall first checks whether the app is allowed.
- [[09 What's inside the APK]]: Phones have different CPUs, but you ship one APK, one file for every phone. So the APK can't hold code for just one kind of CPU, and something on the phone has to run it.
- [[10 Faster code, now and later]]: Reading DEX one instruction at a time is slow. So ART translates busy code into machine code while the app runs, and the phone translates more of it later.
- [[11 Zygote, the process every app starts from]]: Starting ART and reading Android's own code into memory takes seconds. Android does it once, when the phone starts, and makes every app a copy of that.
- [[12 Sharing memory without sharing mistakes]]: If every app were a full copy of Zygote, memory would run out fast. The kernel makes the copies share, and copies only what changes.
- [[13 When memory runs out, who goes]]: A phone has a few gigabytes of memory and dozens of apps you've opened. It can't keep them all. Here's who decides which process ends, in what order, and why your app can be gone when the user comes back.
- [[14 Starting an app, cold, warm and hot]]: Opening an app can mean very different amounts of work, depending on whether its process and its screen still exist.

## Module 3: The machinery

Inside a Binder call, the main thread's queue, and why one slow line freezes the screen.

- [[15 Inside a Binder call]]: In puzzle 5, Binder carried messages between processes. Here's how a method call actually crosses: packed into bytes (raw data), marked with the sender's identity, and picked up by a waiting thread.
- [[16 The main thread's queue]]: Messages arrive on Binder threads, but screen code must run on the main thread. So everything for the screen waits in one line, and the main thread takes it one by one.
- [[17 Frames, jank and ANRs]]: Drawing the screen is just another message in the main thread's queue. So one slow message doesn't only delay a tap: it stops the screen from being drawn.
- [[18 Slow work off the main thread, and back]]: Puzzle 17 said slow work must leave the main thread. But only the main thread may touch the screen. Here's the trip every Android app makes: hand the work to another thread, then hand the result back.
- [[19 How big can a Binder call be]]: In puzzle 15, a call crossed Binder as bytes packed in a Parcel. The receiving process has only so much room for them.

## Module 4: Screens and their lives

What happens to your screen, and your data, when the phone turns, the user leaves, or the process ends.

- [[20 Turn the phone, lose your screen]]: In puzzle 4, system_server moved each Activity along its lifecycle. Turning the phone sends your Activity all the way to destroyed, and builds a new one.
- [[21 The ViewModel outlives the screen]]: In puzzle 20, turning the phone threw away the Activity and everything in its fields. Here's the object made to survive that, and where it waits while the new Activity is built.
- [[22 When the process is gone]]: In puzzle 21, the ViewModel survived turning the phone, but it still lives in your process. Here's what's left when the process itself is ended, and where it waits.

[[Final project]]

## Coming next

- Module 4, continued (coming): Context and why it leaks, tasks and the back stack.
- Module 5: Work without a screen (coming): Services, broadcasts, PendingIntent, process priority and the low-memory killer, Doze and standby buckets, WorkManager.
- Module 6: Threads, coroutines and Flow (coming): How a coroutine actually waits, dispatchers, cancellation, cold and hot streams, StateFlow.
- Module 7: Pixels and performance (coming): From Choreographer to the GPU, how Compose knows what to redraw, garbage collection, memory leaks.
- Module 8: Libraries under the hood (coming): Dependency injection (Dagger, Hilt, Koin), OkHttp and Retrofit, Room and SQLite, R8 and startup.

[[Glossary]]
