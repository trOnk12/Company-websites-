---
course: "Android from the foundation"
puzzle: 3
source: https://pachulski.dev/course/android/03-the-town-hall-decides
tags: [course/android]
---

# Who decides about your screens

> [!summary] The idea to keep
> system_server is the town hall. It keeps the register of every app's screens and moves each screen through its lifecycle. Your app follows.

**Builds on:** [[02 Threads are the workers]]

## The problem

In puzzle 2, the main thread drew your app's screen. But many apps are running, and only one can be on screen. Someone has to decide which screen is in front, which ones are covered or hidden, and which ones are closed. That can't be each app for itself.

## See it

![Who decides about your screens](https://pachulski.dev/course/android/gifs/lifecycle.gif)

Step through it: https://pachulski.dev/course/android/03-the-town-hall-decides

## The building block

In Android, each screen of an app is an **Activity**.

Android runs one long-lived process of its own, **system_server**. It keeps a register of every Activity of every app, and it decides what happens to each one.

system_server moves each Activity along a fixed path of stages, called the **lifecycle**, and your app is told about every move:

- created: the screen is set up, not yet visible;
- started: visible;
- resumed: in front, ready for taps;
- paused: still visible, but no longer in front (a dialog covers it);
- stopped: not visible anymore (another app is in front); if the user comes back, it goes stopped → started → resumed again;
- destroyed: the Activity object is thrown away, usually because the screen was closed (puzzle 17 shows another reason).

## The analogy

system_server is the town hall. It keeps the official register of every house and every room, and it decides which room is open. The houses don't decide for themselves; they get told.

## Check yourself

#flashcards/android

The user switches from your app to another app. Who moves your Activity to "stopped"?::system_server. system_server decides every lifecycle stage; your app is told.

Why can't each app decide on its own which screen is in front?::Because only one screen can be in front, so one place that sees all apps has to decide. Only something that sees every app can fairly decide which screen is in front.

What's the difference between an Activity and system_server?::An Activity is one screen, while system_server is the process that manages them all. Your app holds the screens; the town hall holds the register and the decisions.

## Sources

- [Android Developers: The activity lifecycle](https://developer.android.com/guide/components/activities/activity-lifecycle)
- [Android Developers: Processes and app lifecycle](https://developer.android.com/guide/components/activities/process-lifecycle)
