# Read Linux resource evidence

## Account for memory shared by two processes

Linux exposes a process's memory mappings under /proc. Resident set size (RSS) counts pages belonging to a mapping that are present in physical memory. Adding RSS across processes can count the same physical page several times. Proportional set size (PSS) apportions the cost of shared pages between their mappings. This matters on Android, where several processes may use the same code pages.

### Worked example

Suppose A and B each have 12 MiB of private resident pages and both map the same 8 MiB of resident code exactly once. Each reports 20 MiB RSS and 16 MiB PSS for those pages. The two together occupy 32 MiB. On Linux with smaps_rollup enabled, run grep -E '^(Rss|Pss):' /proc/self/smaps_rollup. The reported process is grep itself because grep opens the file.

### Try it

B exits while A keeps its mappings, with no eviction or allocation. Predict A's RSS and PSS. Would the PSS change by itself justify filing an app memory leak?

### Compare your answer

A's RSS stays at 20 MiB. Its PSS rises to 20 MiB because the eight shared MiB are now entirely attributed to A. To investigate a leak, repeat a bounded operation and look for growth in retained allocations or private memory under comparable conditions. Record other processes that join or leave during the measurement.

[Source · Linux kernel · Process memory mappings and proportional set size](https://docs.kernel.org/filesystems/proc.html)

## Recognize a CPU budget in a trace

A Linux control group groups processes for accounting and resource control. With the cgroup v2 CPU controller, cpu.max gives a CPU-time allowance and its replenishment period, in microseconds. Threads share that allowance. On several cores, two runnable threads can use it twice as fast in elapsed time. Exhaustion can leave ready work waiting while the host has spare CPU.

### Worked example

For a group with cpu.max set to 50000 100000, the allowance is 50 ms each 100 ms. Assume a fresh period, two continuously running threads on separate cores, no burst allowance and no tighter ancestor limit. They can consume the group's 50 ms in about 25 ms of wall time. Read cpu.stat before and after a slow interval to compare nr_periods and nr_throttled.

### Try it

In one second the host averaged 35% CPU. The group's nr_periods advanced by 10 and nr_throttled by 9. A request took 220 ms. Which explanation is supported? Which measurement would test the specific request?

### Compare your answer

The group hit its CPU limit in nine periods. A host average hides that local constraint. The counters cover the whole group, so attributing all 220 ms to throttling is unwarranted. Correlate the request interval with scheduling evidence for its worker. In a controlled repeat, keep work constant and change the CPU allowance, then compare throttling and request latency.

[Source · Linux kernel · Control group v2 CPU interface](https://docs.kernel.org/admin-guide/cgroup-v2.html)

## Measure time lost to memory pressure

Capacity and delay answer different questions. Linux pressure stall information (PSI) measures time when work stalls on a resource. For memory, some counts time with at least one task stalled, and full counts time when every non-idle task in the measured group is stalled together. The total field accumulates microseconds. Taking two readings gives a measurement for the exact interval you studied.

### Worked example

On a Linux host with PSI enabled, read cat /proc/pressure/memory before and after a timed action. In this example the interval is 5.00 seconds. The some total rises from 8,000,000 to 8,750,000 and full rises by 100,000. Some pressure occupied 15% of the interval. Full pressure occupied 2%. Full is already included in some.

### Try it

A UI pause lasted 300 ms inside that interval. What can the two percentages establish about the pause? How could you distinguish pressure in the app's workload from an unrelated batch job?

### Compare your answer

They establish that memory stalls occurred somewhere within the measured host and window. The individual pause still needs attribution. If the app runs in an identifiable cgroup v2 group with PSI, sample its memory.pressure and the host counters over the same action. Correlate an app thread trace with the stalls, then repeat with the batch workload absent. A pressure total can increase even if the UI thread was runnable throughout.

[Source · Linux kernel · Pressure stall information](https://docs.kernel.org/accounting/psi.html)

## Why did deleting the log fail to free its space?

A pathname is a directory entry that leads to a file. An open file descriptor is a process-owned handle to an open file description. Removing the pathname does not invalidate a descriptor that already refers to the file. On Linux the file's storage can remain allocated until the last open descriptor is closed. The process's /proc/<pid>/fd directory exposes symbolic links for its open descriptors, so a deleted target can still be found from the process that holds it.

### Worked example

A service opens incident.log, writes four MiB and keeps descriptor 3 open. An operator removes incident.log. A directory listing no longer shows the name, while /proc/<service-pid>/fd/3 points to a target ending in (deleted). The descriptor's stat data reports a link count of zero and the original size. Closing the last descriptor releases the remaining reference. Creating a new incident.log would make a different file and would not close descriptor 3.

### Try it

Before running it, predict which observations remain after the unlink. Save the [open-file experiment](https://pachulski.dev/labs/linux-open-file/open_deleted.py) and run `python3 open_deleted.py`. Explain why checking only the directory can misdiagnose the incident. Then name the evidence you would capture before restarting a production process and the durable fix you would test.

### Compare your answer

The pathname is missing, but the descriptor target contains (deleted), fstat still reports the bytes and the link count is zero. After close, that /proc descriptor entry disappears. In an incident, record the process ID, descriptor target and size, confirm that the process owns the unexpected reference and check whether the data must be preserved. A controlled close or process restart releases it. The durable fix is a tested log-rotation or reopen policy that closes the old descriptor. Deleting the name repeatedly or creating a replacement file does not release the old handle.

[Source · Linux kernel · Open file descriptors in procfs](https://docs.kernel.org/filesystems/proc.html#proc-pid-fd-list-of-symlinks-to-open-files)

[[Final project]]

[[Course map]]