---
course: "Android from the foundation"
puzzle: 7
source: https://pachulski.dev/course/android/07-each-app-is-its-own-user
tags: [course/android]
---

# Each app gets its own account

> [!summary] The idea to keep
> An ordinary installed app receives its own UID. File access rules, process isolation and additional mandatory access controls protect app-private data.

**Builds on:** [[03 Threads share one house]]

## The problem

In puzzle 0, two running apps couldn't touch each other's memory. But apps also keep files on the phone, like a bank app's saved login and balance. When the bank app isn't even running, what stops a game from opening its files?

## See it

![Each app gets its own account](https://pachulski.dev/course/android/gifs/sandbox.gif)

Step through it: https://pachulski.dev/course/android/07-each-app-is-its-own-user

## The building block

Linux was built for computers shared by many people, so it keeps accounts apart. A Linux account isn't necessarily a person: it's an identity the kernel uses to decide who owns which files. Android reuses that: by default, an installed app gets its own account, with its own user ID, or **UID**. The UID stays the same for as long as the app is installed. Files the app creates belong to its UID. And for every process, the kernel keeps a record of which UID it runs as: when that process opens a file, the kernel checks the process credentials, file access rules and additional access policy. An ordinary app cannot open another app’s private files just by learning their names.

The kernel checks the UID on every file and every process. The result is the **sandbox**: walls around each app's files and memory that no app can switch off, because the kernel enforces them.

## The analogy

Every house has its own key. The kernel is the lock on every door: it opens only for the right key.

## Check yourself

#flashcards/android

The bank app isn't running. Can the game open the bank's saved files now?::No: the files still belong to the bank's UID, and the kernel checks it. The kernel checks the UID whether or not the owner is running.

Who enforces the sandbox?::The kernel. The kernel enforces it, so no app can switch it off.

What's the difference between a UID and a process?::A UID lasts as long as the app is installed, while a process lasts only while it runs. One app, one UID; its process comes and goes.

## Sources

- [Android Open Source Project: Application sandbox](https://source.android.com/docs/security/app-sandbox)
