---
course: "Android from the foundation"
puzzle: 17
source: https://pachulski.dev/course/android/17-frames-jank-and-anrs
tags: [course/android]
---

# Frames, jank and ANRs

> [!summary] The idea to keep
> A frame is due about every 16 ms. A message that takes longer makes frames late: jank. A touch that waits 5 seconds gets the "App isn't responding" dialog: an ANR.

**Builds on:** [[14 Starting an app, cold, warm and hot]]

## The problem

In puzzle 16, the main thread ran messages one at a time. Now suppose one message takes a long time, like reading a big file, or a `Thread.sleep(6000)` in a button's click code, which pauses the thread for 6 seconds. What does the user see?

## See it

![Frames, jank and ANRs](https://pachulski.dev/course/android/gifs/frames.gif)

Step through it: https://pachulski.dev/course/android/17-frames-jank-and-anrs

## The building block

The screen is redrawn about 60 times a second. Each redraw is a **frame**, and each one must be ready within about 16 milliseconds (1000 ms ÷ 60). Drawing a frame is a message in the main thread's queue too.

If a message takes longer than that, the frames behind it come late, and the app visibly stutters: **jank**.

Touches don't travel by Binder. Each screen your app shows is drawn in a **window**, its rectangle of the display, and for each window system_server opens a direct line into your app, an **input channel**. It sends each touch down that line, where it lands in the main thread's queue, and waits for your app to answer "done" on that same line, which it does once the main thread has handled the touch. If a touch waits in the queue for 5 seconds with no answer, system_server shows the "App isn't responding" dialog: an **ANR** (Application Not Responding). That's why slow work (files, network, big calculations) belongs on another thread, never on the main thread.

## The analogy

The clerk also has to repaint the shop window 60 times a second. One long phone call, and the window freezes; keep a customer waiting long enough, and the town hall puts up a sign: "not responding".

## Check yourself

#flashcards/android

A button's click code calls `Thread.sleep(6000)`, and the user taps the screen again right away. What happens?::The tap waits, and after 5 seconds system_server shows an ANR. One message at a time: the touch waits behind the sleep, and after 5 seconds comes the ANR.

A message takes 100 ms (about six frames' worth: 100 ÷ 16), and there are no touches. Is that an ANR?::No, but about six frames come late: the app stutters (jank). 100 ms ÷ 16 ms ≈ 6 frames late: jank. A touch waiting 5 s means an ANR.

Why should file reading go on another thread?::Because then the main thread stays free to draw frames and handle touches. Keep every main-thread message short.

## Sources

- [Android Developers: Slow rendering (jank)](https://developer.android.com/topic/performance/vitals/render)
- [AOSP: InputChannel.java](https://github.com/aosp-mirror/platform_frameworks_base/blob/1cdfff555f4a21f71ccc978290e2e212e2f8b168/core/java/android/view/InputChannel.java#L29) ("An input channel specifies the file descriptors used to send input events to a window in another process") and [InputEventReceiver.java](https://github.com/aosp-mirror/platform_frameworks_base/blob/1cdfff555f4a21f71ccc978290e2e212e2f8b168/core/java/android/view/InputEventReceiver.java#L213) (`finishInputEvent(event, handled)`)
- [Android Developers: ANRs](https://developer.android.com/topic/performance/vitals/anr)
