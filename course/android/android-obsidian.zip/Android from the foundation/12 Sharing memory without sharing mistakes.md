---
course: "Android from the foundation"
puzzle: 12
source: https://pachulski.dev/course/android/12-sharing-memory
tags: [course/android]
---

# Sharing memory without sharing mistakes

> [!summary] The idea to keep
> Memory comes in pages. After a fork, parent and child share every page; a page is copied only when one of them writes to it: copy-on-write.

**Builds on:** [[11 Zygote, the process every app starts from]]

## The problem

In puzzle 11, every app process started as a copy of Zygote. But Zygote holds a lot: ART and the whole framework. Twenty apps, twenty full copies? The phone would run out of memory. And yet each app must be able to change its own data without changing anyone else's.

## See it

![Sharing memory without sharing mistakes](https://pachulski.dev/course/android/gifs/pages.gif)

Step through it: https://pachulski.dev/course/android/12-sharing-memory

## The building block

The kernel hands out memory in small fixed-size blocks called **pages**.

When a process forks, the kernel doesn't copy the pages. The original (Zygote) and the new process share them. Only when one of them writes to a page, that is, changes it, does the kernel make a private copy of that one page for the writer: that's **copy-on-write**. Everything nobody changes stays shared, so twenty apps cost little more than one framework.

That doesn't break puzzle 0's rule. The shared pages hold only what came from Zygote, the same ART and framework every app has: never one app's own data. Nobody writes to a shared page itself: a write goes to a private copy. So no process can see or change another's own data.

## The analogy

Every new house uses the show house's furniture. Repaint a chair, and only then do you get your own copy of that chair. The other houses keep the original.

## Check yourself

#flashcards/android

Twenty apps are running. How many copies of the framework's pages are in memory?::Mostly one, shared by all of them. Untouched pages stay shared after a fork.

Your app changes one shared page. What happens in the other apps?::Nothing: your app gets its own copy of that page first. Only the writer gets a copy; everyone else keeps the original.

Why doesn't the kernel copy every page at fork?::Because copying everything wastes memory, and most pages are never changed. Copy only what changes.

## Sources

- [Android Developers: Overview of memory management (sharing memory)](https://developer.android.com/topic/performance/memory-overview)
- [Linux man page: fork(2), copy-on-write](https://man7.org/linux/man-pages/man2/fork.2.html)
