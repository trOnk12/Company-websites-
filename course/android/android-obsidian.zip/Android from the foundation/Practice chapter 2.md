# Work without a screen

## Choose a service by its execution contract

A Service is an Android component with a lifecycle. By default its callbacks run on the app’s main thread. A started service receives commands; a bound service exposes an interface to clients. A foreground service represents ongoing user-visible work and is subject to launch and type restrictions.

### Worked example

A playback service receives a play command. Its notification makes playback visible; decoding must still run on appropriate execution resources. An expensive synchronous decode in onStartCommand delays other main-thread callbacks.

### Try it

Which component would you choose for an eventual upload that may resume tomorrow?

### Compare your answer

A persistent scheduler such as WorkManager suits deferrable work. A foreground playback service meets a different user-visible requirement.

[Source · Android · Services overview](https://developer.android.com/develop/background-work/services)

## Finish a broadcast before its execution window closes

A broadcast delivers a short-lived event to a receiver. Once onReceive returns, an app with no other active component may lose its execution priority. An unmanaged thread started from the callback therefore has no durable lifetime guarantee.

### Worked example

A receiver learns that a local export needs indexing. It records or enqueues uniquely identifiable work and returns. The worker reads the stored input later. goAsync provides only a bounded extension for finishing a broadcast.

### Try it

The same hint arrives twice. What should the indexing worker read?

### Compare your answer

Use a durable export identity or current index version and make repeat execution converge to the same result. A broadcast count is a poor substitute for the actual work record.

[Source · Android · Broadcasts overview](https://developer.android.com/develop/background-work/background-tasks/broadcasts)

## Give another component a bounded PendingIntent

A PendingIntent is a system-maintained token for a specified operation under its creator’s identity. Construct it with an explicit destination and use immutability when the recipient has no need to fill in fields. Equality for matching tokens does not use Intent extras alone.

### Worked example

Two notification actions open note 17 and note 29. If both use the same request code and equal matching Intent fields, different extras alone can select the same token. Give the actions distinct request codes or distinct data URIs.

### Try it

Notification 17 opens note 29 after the second notification arrives. What do you inspect first?

### Compare your answer

Compare the operation type, creator, request code, matching Intent fields and update flags. Verify the target checks current authorization when opened.

[Source · Android · PendingIntent](https://developer.android.com/reference/android/app/PendingIntent)

## Persist before process priority changes

Android ranks processes partly by their most important active component. A process hosting the visible interaction is typically more important than a cached process. Memory pressure can reclaim cached processes without delivering a final callback in which to save data.

### Worked example

A user saves a draft and backgrounds the app. If the only copy lives in a singleton, reclaiming the cached process removes it. Commit the draft when the edit is accepted; rebuild the screen from an ID after process recreation.

### Try it

Does restoring a navigation screen prove that cached bytes or an unfinished thread survived?

### Compare your answer

No. Read the persisted draft and a durable work record. Test with process recreation separately from ordinary rotation.

[Source · Android · Processes and app lifecycle](https://developer.android.com/guide/components/activities/process-lifecycle)

## Separate device idle from app usage restrictions

Doze changes the device’s treatment of background network and scheduled work during idle periods. App Standby Buckets classify an individual app by usage and affect its resource opportunities. A delayed job can reflect either policy as well as its own constraints.

### Worked example

An unused news app requests a refresh while an unplugged phone rests with its screen off. Its job can wait even though the stored job record is correct. Inspect device idle state, the app’s bucket, job constraints and actual execution times.

### Try it

Can a periodically requested refresh promise that data is exactly fifteen minutes old at every screen open?

### Compare your answer

No. Persist the last successful fetch time, display its age, and define what opening the screen should do if the refresh is overdue.

[Source · Android · App Standby Buckets](https://developer.android.com/topic/performance/appstandby)

## Schedule around Doze maintenance windows

During device idle, Android defers categories of background CPU and network work. Maintenance windows temporarily allow deferred work. A pending operation can be correctly recorded on disk while its first opportunity to contact the server is still in the future.

### Worked example

At 23:00 a device enters idle with a deferred notes upload. The service receives nothing at 23:05. When an allowed window opens, the worker can attempt the upload if its own constraints are also satisfied. Inspect both scheduling and network outcomes before diagnosing a lost edit.

### Try it

A user opens the app before the worker has run. What should their notes screen show?

### Compare your answer

Render the local saved edit and its pending state. A background scheduling delay should not erase a draft or falsely mark it synchronized.

[Source · Android · Optimize for Doze and App Standby](https://developer.android.com/training/monitoring-device-state/doze-standby)

## Resume persistent work without repeating its effect

WorkManager persists a request and waits for its constraints. The worker may be stopped or run again. A stable work name can coordinate local scheduling; the remote write still needs an identity or a repeat-safe operation.

### Worked example

Persist upload 81. The worker sends it, the server accepts it and the phone stops before recording success. On a later run, the worker resends upload 81. A server that records that identity can return the original result.

### Try it

Would a brand-new server-side upload ID on every worker attempt be safe?

### Compare your answer

It could create duplicates. Keep the operation identity with the input, retry transient failure with backoff and mark completion after recovering the outcome.

[Source · Android · Task scheduling](https://developer.android.com/develop/background-work/background-tasks/persistent)

[[Practice chapter 3|Threads, coroutines and Flow]]

[[Course map]]