---
course: "Encryption, from the ground up"
puzzle: 2
source: https://pachulski.dev/course/security/02-one-key-for-both
tags: [course/security]
---

# One key for both

> [!summary] The idea to keep
> In symmetric encryption, the same key locks and unlocks. AES, the standard, encrypts in blocks of 128 bits with a key of 128, 192 or 256 bits; it's fast enough for everything you send. Its open problem: both sides need the same key, and you can't just send it.

**Builds on:** [[01 Bits, XOR and a toy cipher]]

## The problem

In puzzle 0, encryption turned the password into ciphertext with a key. Your app and your server will send thousands of messages: every request, every response, every image. Whatever does the encrypting has to be fast, and both sides have to be able to undo it. What does that look like?

## See it

![One key for both](https://pachulski.dev/course/security/gifs/aes.gif)

Step through it: https://pachulski.dev/course/security/02-one-key-for-both

## The building block

The simplest arrangement: one key, and it works both ways. Encrypt with it, decrypt with the same key. That's **symmetric encryption**.

The standard one is **AES**. It takes the data in **blocks of 128 bits** (16 bytes) and scrambles each with the key, in rounds of mixing and substituting, in a way that can only be undone with that same key. Keys come in three sizes: 128, 192 or 256 bits. A 128-bit key has 2 to the power 128 possible values, a 39-digit number: far more than any computer could ever try, which is why guessing it isn't a way in.

AES is fast, and phone chips have circuits built for it, so it can encrypt everything you send. (In a counter-based mode, AES doesn't scramble your data blocks directly, which would make two identical blocks look identical. It makes a keystream, as in puzzle 1: it scrambles a counter, a number that goes up by one for every block, and XORs the result with your data. The starting settings must keep the counter sequences distinct across messages encrypted with the same key. And puzzle 8 adds a check against changes.) That's why, as puzzle 8 shows, HTTPS can use AES for application data. Other supported ciphers can also protect HTTPS traffic.

But it leaves one problem. Your app and your server both need the same key. You can't send it over the line from puzzle 0: the listener would copy it, and then decrypt everything. And you can't build one key into every copy of your app: anyone could pull it out of the app file. How do two sides get the same key, when everything they say can be heard? That's puzzle 3.

## The analogy

A box with one lock and one key, cut twice. Lock it with your copy, your friend opens it with theirs. The box is fast and strong. The hard part is getting the second copy of the key to your friend without anyone on the way copying it.

## Check yourself

#flashcards/security

Your app encrypts a 1 MB photo with AES. Roughly how does AES handle it?::Block by block, 128 bits at a time, all with the same key. Fixed-size blocks, one key.

Why can't your app just send the AES key to the server first?::Because the listener would copy the key, then decrypt everything after it. Anything sent openly, the listener gets too.

What's the difference between a 128-bit block and a 128-bit key?::The block is the data handled at a time, while the key does the scrambling. Data piece vs secret.

## Sources

- [NIST FIPS 197: Advanced Encryption Standard (AES)](https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.197-upd1.pdf) ("The AES algorithm is a symmetric block cipher that can encrypt (encipher) and decrypt (decipher) digital information. The AES algorithm is capable of using cryptographic keys of 128, 192, and 256 bits to encrypt and decrypt data in blocks of 128 bits.")
