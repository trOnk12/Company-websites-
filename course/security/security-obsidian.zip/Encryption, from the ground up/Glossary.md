# Glossary: Encryption, from the ground up

Every word the course teaches, in the order it does. #flashcards/security/words

ciphertext::Encrypted data: what a listener sees. (taught in [[00 Anyone on the line]])

encryption::Turning data into gibberish that only someone with the right key can turn back. (taught in [[00 Anyone on the line]])

key::The secret number that locks and unlocks data. (taught in [[00 Anyone on the line]])

128-bit block::The fixed-size piece AES encrypts at a time: 128 bits. (taught in [[01 One key for both]])

AES::The standard symmetric cipher: blocks of 128 bits, keys of 128, 192 or 256 bits. (taught in [[01 One key for both]])

symmetric encryption::Encryption where the same key locks and unlocks. (taught in [[01 One key for both]])

key exchange::Two sides agreeing on a shared secret over a line anyone can hear. (taught in [[02 A secret agreed in public]])

private value::The number each side keeps to itself during a key exchange. (taught in [[02 A secret agreed in public]])

public value::The number each side sends openly during a key exchange. (taught in [[02 A secret agreed in public]])

shared secret::The number both sides compute and a listener can't. (taught in [[02 A secret agreed in public]])

digest::The fingerprint a hash function produces, like SHA-256's 256 bits. (taught in [[03 A fingerprint for data]])

hash function::A function that turns any data into a short, fixed-size fingerprint. (taught in [[03 A fingerprint for data]])

keyed check::A short value computed from data and a shared secret key; without the key, nobody can make one that matches. (taught in [[03 A fingerprint for data]])

SHA-256::A standard hash function with a 256-bit digest. (taught in [[03 A fingerprint for data]])

certificate::A server's name and public key, signed by an authority the phone trusts. (taught in [[04 Proof of who you are]])

certificate authority::An organization phones trust to sign certificates. (taught in [[04 Proof of who you are]])

key pair::Two keys made together: a private one kept secret and a public one anyone may have. (taught in [[04 Proof of who you are]])

private key::The half of a key pair its owner keeps secret, used to sign. (taught in [[04 Proof of who you are]])

public key::The half of a key pair anyone may have, used to check signatures. (taught in [[04 Proof of who you are]])

signature::A digest locked with a private key; anyone with the public key can check it. (taught in [[04 Proof of who you are]])

handshake::The first messages of a TLS connection, where keys are agreed and the server proves who it is. (taught in [[05 TLS, the blocks together]])

TLS::The protocol behind HTTPS: key exchange, certificate check, then symmetric encryption. (taught in [[05 TLS, the blocks together]])
