---
source: https://pachulski.dev/course/security/
tags: [course/security]
---

# Encryption, from the ground up

What actually happens in the S of HTTPS. From "anyone on the café Wi-Fi can read your packets" to keys, key exchange, hashes, signatures and certificates, one small block at a time, until TLS stops being magic.

From [pachulski.dev](https://pachulski.dev/course/security/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: The blocks of HTTPS

Six blocks, each stopping one attack, that together make TLS.

- [[00 Anyone on the line]]: Your app sends a password to a server. Between the two sit a café's Wi-Fi, a phone operator and a dozen machines you don't control. Here's what any of them can do, and the first defence that stops it.
- [[01 One key for both]]: In puzzle 0, encryption turned the password into gibberish. Here's how the standard way does it, why it's fast, and the one problem it leaves open.
- [[02 A secret agreed in public]]: In puzzle 1, AES needed the same key on both sides, and sending it would hand it to the listener. Here's how two sides agree on a secret while every word they say is overheard.
- [[03 A fingerprint for data]]: In puzzle 0, a machine in the middle could change data on its way, and encryption alone wouldn't notice. Here's the block that makes any change visible.
- [[04 Proof of who you are]]: In puzzle 2, the key exchange worked with whoever answered, and in puzzle 3 an attacker could swap a digest. Both gaps close the same way: a mark on the data that only the real server can make.
- [[05 TLS, the blocks together]]: Puzzles 0 to 4 each stopped one thing a machine in the middle could do. The S in HTTPS is those blocks put together in one short conversation before your first request.

## Coming next

- Module 2: Secrets on the phone (coming): Where an app keeps keys and tokens: the Android Keystore and hardware-backed keys, encrypted storage, certificate pinning and when it backfires.
- Module 3: Accounts and tokens (coming): Passwords and why servers hash them, OAuth and access tokens, refresh tokens, and what to do when a token leaks.

[[Glossary]]
