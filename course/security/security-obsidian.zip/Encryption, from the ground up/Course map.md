---
source: https://pachulski.dev/course/security/
tags: [course/security]
---

# Encryption, from the ground up

What actually happens in the S of HTTPS. From "anyone on the café Wi-Fi can read your packets" to keys, key exchange, hashes, signatures and certificates, one small block at a time, until TLS stops being magic.

From [pachulski.dev](https://pachulski.dev/course/security/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: The blocks of HTTPS

Six blocks, each stopping one attack, that together make TLS.

- [[00 Anyone on the line]]: Your app sends a password to a server. Between the two sit a café's Wi-Fi, a phone operator and a dozen machines you don't control. Here's what any of them can do, and the first defence that stops it.
- [[01 Bits, XOR and a toy cipher]]: Puzzle 0 said encryption turns data into gibberish with a key. Before any real cipher, here's the one operation every cipher you'll meet ends with, and a complete cipher you can do by hand.
- [[02 One key for both]]: In puzzle 0, encryption turned the password into gibberish. Here's how the standard way does it, why it's fast, and the one problem it leaves open.
- [[03 A secret agreed in public]]: In puzzle 2, AES needed the same key on both sides, and sending it would hand it to the listener. Here's how two sides agree on a secret while every word they say is overheard.
- [[04 The man in the middle]]: Puzzle 3 ended with a gap: a key exchange gives you a secret shared with whoever answered. Here's the attack that fills that gap, step by step, and the one thing that would stop it.
- [[05 A fingerprint for data]]: In puzzle 0, a machine in the middle could change data on its way, and encryption alone wouldn't notice. Here's the block that makes any change visible.
- [[06 A hash with a secret]]: Puzzle 5 showed a fingerprint anyone can recompute, so an attacker who changes the data just sends a new fingerprint. Add a key that only the two sides have, and the fingerprint becomes something only they can make.
- [[07 Proof of who you are]]: In puzzle 3, the key exchange worked with whoever answered, and in puzzle 5 an attacker could swap a digest. Both gaps close the same way: a mark on the data that only the real server can make.
- [[08 TLS, the blocks together]]: Puzzles 0 to 7 each stopped one thing a machine in the middle could do. The S in HTTPS is those blocks put together in one short conversation before your first request.

## Practice chapters

- [[Practice chapter 1|Keys and protected data on a phone]]
- [[Practice chapter 2|Accounts, delegated authority and recovery]]

[[Final project]]


[[Glossary]]
