---
course: "Encryption, from the ground up"
puzzle: 8
source: https://pachulski.dev/course/security/08-tls-the-blocks-together
tags: [course/security]
---

# TLS, the blocks together

> [!summary] The idea to keep
> In a full certificate-authenticated TLS 1.3 connection, the client verifies the server and handshake transcript. Traffic keys protect application records for confidentiality and integrity. Endpoints, timing and lengths can still reveal information.

**Builds on:** [[06 A hash with a secret]] · [[07 Proof of who you are]]

## The problem

Puzzle 0 named three things a machine in the middle can do: read, change, pretend. Puzzles 1 to 7 each built one block: symmetric encryption, key exchange, hashes, signatures and certificates. Your app opens an https address and sends a request a moment later. How do all those blocks fit into that moment?

## See it

![TLS, the blocks together](https://pachulski.dev/course/security/gifs/tls.gif)

Step through it: https://pachulski.dev/course/security/08-tls-the-blocks-together

## The building block

**TLS** is the protocol behind HTTPS: a set of agreed messages and rules. Before any of your data is sent, the app and the server have a short exchange: the **handshake**. For this full certificate-authenticated TLS 1.3 handshake over an established transport, with a supported initial key share and no retry, the server flight returns after one round trip:

1. Your app says hello and sends its public value for a key exchange (puzzle 3).
2. The server answers with its own public value. Now both sides compute the shared secret, and from it they derive several keys (computed from it by a fixed recipe both sides follow): one set for the rest of the handshake, another for your data. The subsequent authentication messages are protected. Record lengths, timing and network addresses remain observable.
3. Still in the handshake, but now encrypted, the server sends its certificate (puzzle 7) and a signature over the whole conversation so far, made with its private key.
4. Your app checks the certificate against the authorities it trusts, checks the name against the address, and checks the signature. A listener with a copied certificate fails here: it can't make that signature.
5. Both sides end the handshake with a MAC (puzzle 6) over everything said so far, called Finished. Only now does each know that nobody changed the handshake on the way.

Then your data flows in records: chunks of data, each sent and checked on its own. Each record goes through one combined step, called authenticated encryption, for example AES in a mode built for it: it encrypts the record and attaches a MAC (puzzle 6), called a tag, both computed with keys derived from the shared secret. A listener who changes a byte can't make a matching tag, because it doesn't have the keys, so the change is detected and the record rejected. Reading: stopped by encryption. Changing: stopped by the tag on every record. Pretending: stopped by the certificate and the signature.

TLS doesn't hide everything: someone in the middle still sees which server you talk to and how much data goes back and forth. It hides what is said, and makes sure it's said to the right server.

## The analogy

A courier and a bank: first the bank shows its registered seal and you both agree on a code, in plain sight but in a way no one listening can copy. Then every envelope goes out in that code, sealed so any tampering shows.

## Check yourself

#flashcards/security

Your app connects to your server over HTTPS on the café Wi-Fi. A machine in the middle replaces one byte of the response. What happens?::The MAC on that record fails, so your app rejects it. Every record is checked as well as encrypted.

Why does the server sign the handshake, not only send its certificate?::Because certificates are public and copyable, but only the private key can sign. A certificate can be copied; a signature can't.

What's the difference between the handshake and everything after it?::The handshake sets up keys and proves identity; then data uses those keys. Setting up vs using.

## Sources

- [RFC 8446: TLS 1.3](https://www.rfc-editor.org/rfc/rfc8446) (the handshake "can be thought of as having three phases": Key Exchange, "Everything after this phase is encrypted", then Server Parameters and Authentication with Certificate and CertificateVerify; "all ciphers are modeled as Authenticated Encryption with Associated Data (AEAD)… a unified encryption and authentication operation"; "TLS does not hide the length of the data it transmits")
