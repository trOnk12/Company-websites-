# Accounts, delegated authority and recovery

## Verify a password without storing the original

A verifier stores a salt, a cost setting and a password hash produced with a dedicated password hashing scheme. A unique random salt prevents equal passwords from sharing the same stored verifier. A tunable work factor increases the cost of each guess. A fast general-purpose checksum does not supply this property.

### Worked example

Two accounts choose the same password. Generate distinct salts and their stored verifiers differ. At login, load that account’s parameters and verify the submitted password using the chosen library. After a valid login, the service can upgrade old parameters under its migration policy.

### Try it

Does encrypting a recoverable copy of every password provide the same design?

### Compare your answer

No. Routine verification needs a match decision, not recovery of the original. Use a supported password hashing library, protect transport and rate-limit failed authentication attempts.

[Source · NIST SP 800-63B · Password verifiers](https://pages.nist.gov/800-63-4/sp800-63b.html)

## Limit what an access token authorizes

OAuth separates the user, client app, authorization server and resource server. A native public client can use authorization code with PKCE: create a verifier, bind its challenge to the authorization request, then present the verifier when exchanging the returned code. The resulting access token is constrained by the server’s audience, scope and lifetime policies.

### Worked example

A calendar app requests read-only access. The user signs in through the authorization service. The app exchanges the code and uses the token at the calendar API. The API checks whether this token is meant for it and permits the requested read. Successful sign-in alone confers no right to edit an event.

### Try it

A token issued for the calendar API arrives at a photo API using the same identity provider. Should the signature alone authorize a read?

### Compare your answer

Reject it when the intended audience does not match. Validate the token according to its format and issuer contract and enforce the requested action and resource ownership.

[Source · RFC 9700 · OAuth security best current practice](https://www.rfc-editor.org/rfc/rfc9700.html)

## Handle refresh and loss as separate incidents

An access token authorizes resource requests for its permitted lifetime. A refresh token obtains replacement access tokens from the authorization server and may outlive them. Protect it accordingly. Rotation can replace the refresh credential on use and help detect reuse. Serialize concurrent refresh in the client so its own parallel requests do not accidentally reuse the old credential.

### Worked example

Two API calls receive an expiry response together. One refreshes while the other waits; both retry eligible operations with the replacement access token. If a refresh token was exposed, revoke the affected grant or token family under provider policy, clear local credentials and require reauthorization. Avoid placing secrets in diagnostic logs.

### Try it

Does deleting a token on one lost device immediately disable every issued access token at every service?

### Compare your answer

No. Coordinate revocation with the authorization server and the resource servers’ token-validation model. Some already issued access tokens remain valid until expiry or until revocation information reaches the verifier. Test the actual containment window.

[Source · RFC 7009 · OAuth token revocation](https://www.rfc-editor.org/rfc/rfc7009.html)

[[Final project]]

[[Course map]]