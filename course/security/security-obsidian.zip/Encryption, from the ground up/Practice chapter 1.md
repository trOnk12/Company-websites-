# Keys and protected data on a phone

## Give the app permission to use a key

Android Keystore can hold a key identified by an alias and perform allowed cryptographic operations without exposing its key material to the app. Some keys are protected by secure hardware. Check the security level for the particular key and device. Choose permitted operations and authentication conditions according to the feature’s threat model.

### Worked example

A notes app uses an alias to encrypt and decrypt a private journal. The saved record holds ciphertext plus the information needed to decrypt it. Copying the file alone does not copy the non-exportable key. A process already allowed to request decryption can still obtain plaintext while authorized.

### Try it

A device lacks the required hardware protection. Should you silently claim the feature has the same guarantee?

### Compare your answer

Define a product policy: require the capability for this feature or explicitly support a documented lower assurance level. Inspect the generated key’s security level rather than guessing from the phone model.

[Source · Android Developers · Keystore system](https://developer.android.com/privacy-and-security/keystore)

## Design the record format and its recovery path

For encrypted app storage, use established authenticated encryption so modified ciphertext fails verification. Keep keys separate from encrypted files. Store the key version and the nonce needed for decryption, and obey the algorithm’s nonce requirements. Decide what happens when a backup restores bytes onto a device without the original key.

### Worked example

A journal record holds format version 2, key alias generation 3, a fresh encryption nonce and authenticated ciphertext. A user restores the file after replacing their handset. The old alias is unavailable. Local encryption protected those bytes, but the restore feature still needs a separate authorized recovery design if promised.

### Try it

The new app version rotates its key. When can the old generation be removed?

### Compare your answer

After a verified migration of all records that must remain readable, including the intended backup policy. Test an interrupted migration and old records; on authentication failure never substitute unverified plaintext.

[Source · Android Developers · Cryptography](https://developer.android.com/privacy-and-security/cryptography)

## Evaluate certificate pinning through a rotation

A normal TLS client verifies the server name and certificate chain against its trusted authorities. Pinning adds a restriction to particular public keys or chains. It can reduce accepted credentials, but also makes the client depend on future certificate deployment choices. Android cautions against routine pinning because certificate changes can strand installed clients.

### Worked example

A mobile version pins only key A. The service changes to an otherwise valid certificate with key B. Browsers connect while that app rejects the service. A backup pin helps only if the deployed replacement can actually satisfy it and clients already know it.

### Try it

Before adding a pin to an app whose users rarely update, what release rehearsal matters?

### Compare your answer

Test rotation and emergency recovery on the oldest supported client with the future chain. Weigh that operational risk against the concrete threat the pin addresses. Keep standard hostname and chain checks enabled.

[Source · Android Developers · Network security configuration](https://developer.android.com/privacy-and-security/security-config)

[[Practice chapter 2|Accounts, delegated authority and recovery]]

[[Course map]]