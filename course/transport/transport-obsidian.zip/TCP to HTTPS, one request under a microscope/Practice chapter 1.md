# Debug a connection from observable evidence

## Which limit stopped the stream?

QUIC receivers advertise limits both for individual streams and for the whole connection. These limits protect receiver memory and use byte offsets. Congestion control separately limits sending according to network conditions. An idle link does not establish that a sender has permission to send more application data.

### Worked example

In a fresh fixture the peer grants 12 KiB of connection credit and 8 KiB on each of two streams. A sends 8 KiB. B can send only 4 KiB before the connection limit binds. Increasing B's stream limit alone cannot change that result. The receiver must also extend the connection limit for more new bytes to flow.

### Try it

The connection limit increases to 20 KiB and neither stream limit changes. How much more can A and B send immediately, ignoring congestion?

### Compare your answer

A has exhausted its 8 KiB allowance. B can send 4 KiB more before it also hits 8 KiB. Remaining connection credit is usable only by a stream with credit. Inspect the limiting layer before changing a buffer.

[Source · RFC 9000 · Flow control](https://www.rfc-editor.org/rfc/rfc9000.html#section-4)

## Why can two independent HTTP requests both stall?

HTTP/2 multiplexes frames from multiple streams into one ordered TCP byte stream. The application can interleave work from different requests. Delivery still depends on TCP filling gaps in the shared byte sequence. Separately, HTTP/2 DATA frames are constrained by per-stream and connection-level flow-control windows.

### Worked example

An image frame occupies an early range of TCP bytes. Later bytes contain a small JSON response. The later segment reaches the receiver first, but an earlier TCP segment is missing. The application must wait for ordered delivery even if the JSON request has its own HTTP/2 stream and enough flow-control credit.

### Try it

A trace shows no loss, the receiver advertises connection-level HTTP/2 window zero, and both streams have stream credit. Would retransmission solve the stall?

### Compare your answer

No new DATA fits the connection window. Inspect whether the application is consuming data and whether WINDOW_UPDATE extends the applicable window. Distinguish a missing TCP byte from exhausted receiver credit in your trace.

[Source · RFC 9113 · Flow control](https://www.rfc-editor.org/rfc/rfc9113.html#section-5.2)

## Which operations may be repeated during connection resumption?

TLS 1.3 can allow early application data when resuming a previous session. Early data has different replay properties from regular application data, and the server can reject it. Decide which application operations are eligible before counting the latency saved by starting early.

### Worked example

Consider a read of a public timetable and a request to charge a card. A replay of the first can consume extra read capacity. A replay of the second can change money owed. The payment protocol needs an operation identity and durable reconciliation even outside early data, since the client can also lose an ordinary response.

### Try it

A resuming connection rejects early data. What does that tell the client about whether it may repeat an application operation?

### Compare your answer

Follow the TLS and application protocol's handling of rejected early data and check whether repeating that operation is safe. Keep non-repeatable operations out of early data. Connection resumption is a latency choice and application-level duplicate handling has its own contract.

[Source · RFC 8446 · Early data and replay](https://www.rfc-editor.org/rfc/rfc8446.html#section-8)

[[Final project]]

[[Course map]]