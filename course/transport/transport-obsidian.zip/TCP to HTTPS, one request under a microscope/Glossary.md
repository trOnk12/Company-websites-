# Glossary: TCP to HTTPS, one request under a microscope

Every word the course teaches, in the order it does. #flashcards/transport/words

sequence number::The position of a byte in one direction of a TCP connection. (taught in [[00 Why TCP starts with three messages]])

cumulative acknowledgment::The next byte needed to extend the contiguous prefix. (taught in [[01 Where do the missing bytes go]])

handshake transcript::The ordered record of messages used in the handshake checks. (taught in [[02 Who proves the server’s identity]])

time to first byte::The delay until a response begins. (taught in [[03 Where did the extra round trips go]])

QUIC::A secure transport over UDP with independent byte streams. (taught in [[04 Can a lost image slow a text response]])
