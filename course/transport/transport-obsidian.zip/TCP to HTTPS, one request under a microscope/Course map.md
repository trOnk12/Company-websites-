---
source: https://pachulski.dev/course/transport/
tags: [course/transport]
---

# TCP to HTTPS, one request under a microscope

Trace a mobile request from opening the connection to authenticating the server, counting the first byte and understanding what packet loss changes.

From [pachulski.dev](https://pachulski.dev/course/transport/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: Open, secure and reuse a connection

Follow sequence numbers, missing bytes, TLS proof and a first-byte budget.

- [[00 Why TCP starts with three messages]]: Follow the first exchange between a phone and a server. What has each side learned at every step?
- [[01 Where do the missing bytes go]]: Drop one range of bytes while a later range arrives. Predict what the receiver reports and what the application can read.
- [[02 Who proves the server’s identity]]: The phone can already exchange bytes. Work out what it must verify before trusting the peer with an application request.
- [[03 Where did the extra round trips go]]: Time one small request over a new connection, then reuse the connection and account for the difference.

## Module 2: Share a connection under loss

Compare delivery on HTTP/2 and HTTP/3 with the same two requests.

- [[04 Can a lost image slow a text response]]: Two responses share a connection. Change the transport and predict which response can keep moving after loss.

[[Final project]]


[[Glossary]]
