---
course: "TCP to HTTPS, one request under a microscope"
puzzle: 4
source: https://pachulski.dev/course/transport/04-when-one-stream-loses-data
tags: [course/transport]
---

# Can a lost image slow a text response?

> [!summary] The idea to keep
> HTTP/2 streams share one ordered TCP byte stream. HTTP/3 maps traffic onto independently ordered QUIC streams, so loss on one stream need not stop delivery on another.

**Builds on:** [[01 Where do the missing bytes go]]

## The problem

The reading app requests a large cover and a small text card together. Part of the cover response is lost, but the bytes for the text card arrive. Can the card still be shown?

## See it

![Can a lost image slow a text response?](https://pachulski.dev/course/transport/gifs/when-one-stream-loses-data.gif)

Step through it: https://pachulski.dev/course/transport/04-when-one-stream-loses-data

## The building block

**Multiplexing** lets multiple exchanges share a connection. Both HTTP/2 and HTTP/3 allow this, but the transport beneath them changes what happens during loss.

**QUIC** is a secure transport over UDP. UDP carries separate datagrams. QUIC adds its own recovery and provides independently ordered streams.

| Protocol | Where bytes have to be delivered in order | Consequence after the cover bytes are lost |
|---|---|---|
| HTTP/2 over TCP | One shared transport byte stream with a cumulative acknowledgment | Later text-card bytes can sit behind the gap if they occur after it in that stream. |
| HTTP/3 over QUIC | Within each stream | The text card can advance if its own bytes and any compression or control information it depends on are available. |

Even on QUIC, losing one packet can affect multiple streams if that packet contained their data. Congestion control also remains shared across the connection, so traffic may slow together even where delivery can progress independently.

The practical distinction is delivery waiting behind one missing range versus a shared reduction in sending rate. The first is an ordering dependency; the second is feedback about the network path.

## Go deeper: Trace the dependency before blaming the protocol

- A lost QUIC packet carried data for both the cover and the card. Does their independent ordering ensure the card can finish immediately?::No. If the card needs bytes that were in that packet, its own stream has a gap. Stream independence helps when the other stream has what it needs.

## Check yourself

#flashcards/transport

The text bytes arrive after a missing cover range in the same TCP stream. Why can HTTP/2 wait?::TCP delivers the shared stream in byte order. Separate HTTP streams share the TCP delivery order.

In HTTP/3, the lost packet held only cover bytes. Card bytes and its dependencies are present. What is possible?::The text card can finish before the cover retries arrive. Each stream has its own ordering.

Both streams slow after network loss despite the card having no ordering gap. What could explain it?::The connection reduces its sending rate. Independent delivery can coexist with shared congestion feedback.

## Sources

- [IETF RFC 9113: HTTP/2 streams and multiplexing](https://www.rfc-editor.org/rfc/rfc9113.html#section-5)
- [IETF RFC 9000: QUIC streams and loss](https://www.rfc-editor.org/rfc/rfc9000.html#section-13)
- [IETF RFC 9114: HTTP/3 connection and streams](https://www.rfc-editor.org/rfc/rfc9114.html#section-6)
- [IETF RFC 9002: congestion control](https://www.rfc-editor.org/rfc/rfc9002.html#section-7)
