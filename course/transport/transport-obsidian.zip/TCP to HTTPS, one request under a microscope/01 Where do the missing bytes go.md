---
course: "TCP to HTTPS, one request under a microscope"
puzzle: 1
source: https://pachulski.dev/course/transport/01-a-hole-in-the-byte-stream
tags: [course/transport]
---

# Where do the missing bytes go?

> [!summary] The idea to keep
> A cumulative acknowledgment advances only across a contiguous prefix. Later bytes may wait while the receiver is missing earlier bytes.

**Builds on:** [[00 Why TCP starts with three messages]]

## The problem

The phone sends three blocks of four bytes. They arrive as first, third, then second. Can the receiving app read the third block as soon as it arrives?

## See it

![Where do the missing bytes go?](https://pachulski.dev/course/transport/gifs/a-hole-in-the-byte-stream.gif)

Step through it: https://pachulski.dev/course/transport/01-a-hole-in-the-byte-stream

## The building block

A **cumulative acknowledgment** reports the next byte needed to extend the contiguous prefix. Suppose the first byte has sequence number 101 and all three blocks are four bytes long.

| Received byte positions | Next number expected | What TCP can make available in order |
|---|---|---|
| 101–104 | 105 | 101–104 |
| 109–112 arrives early | 105 | Still only 101–104 |
| Missing 105–108 finally arrives | 113 | Now 101–112, if the later bytes were kept |

The receiver may buffer bytes that arrived ahead of a gap. It can still report 105, even though it has seen later bytes. The sender can send missing bytes again. When the gap closes, the acknowledgment can jump over the already buffered bytes.

TCP presents a continuous byte stream to the application. The app may read twelve bytes through one read or several, depending on when data is available and how much it asks for. The application has to understand its own message boundaries. It can't assume that one network segment equals one read or one complete message.

## Go deeper: Later data is useful without advancing the main acknowledgment

- If the receiver tells the sender separately that it kept bytes 109–112, does the cumulative acknowledgment change?::It still reports 105. TCP selective acknowledgments can describe received ranges without claiming that the earlier gap is filled.

## Check yourself

#flashcards/transport

The receiver has bytes 101–104 and 109–112. What cumulative acknowledgment can it send?::105, the first missing byte. Find the first hole after the contiguous prefix.

Why can the app be waiting even while TCP has received new bytes?::The new bytes sit after a gap in the ordered stream. Ordered application delivery and network arrival order can differ.

One application message covers bytes 101–112. The app first gets four bytes. What should it do?::Read further until its message framing says it is complete. Message boundaries belong to the next layer.

## Sources

- [IETF RFC 9293: sequence numbers and processing incoming data](https://www.rfc-editor.org/rfc/rfc9293.html#section-3.4)
- [IETF RFC 2018: TCP selective acknowledgment](https://www.rfc-editor.org/rfc/rfc2018.html)
