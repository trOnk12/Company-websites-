---
source: https://pachulski.dev/course/compose/
tags: [course/compose]
---

# Compose Multiplatform, one screen from state to pixels

What Compose really does underneath your @Composable functions, and how Compose Multiplatform takes that machinery to an iPhone. Then one shared bookmark screen, followed from state reads to pixels, across the iOS hosting boundary and through a VoiceOver check. For Android engineers who write Jetpack Compose and want to ship it to iOS.

From [pachulski.dev](https://pachulski.dev/course/compose/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: Compose underneath

What the compiler plugin does to a composable, the tree Compose remembers, which code runs again when state changes and what gets skipped, one frame from tree to pixels, and the layers that let Compose leave Android.

- [[00 What @Composable really does]]: The KMP course said a compiler plugin adds "hidden bookkeeping" to every composable. Here's what it really adds: a hidden parameter that every composable hands on to the next, and a start and an end around every call.
- [[01 The tree Compose remembers]]: Every composable call records a group through the Composer, and then returns. Here's where those records go, so that a counter's value survives the call that made it, and the same call finds it again next time.
- [[02 Who read that state]]: The composition remembers every call. When a counter changes, Compose doesn't run your whole screen again; it runs only the calls that read the counter. Here's how it knows who read it, and when it runs them.
- [[03 What gets skipped]]: When a marked composable runs again, it calls its children again too. Most of them got the same arguments as last time. Here's how Compose decides that a child call doesn't need to run, and why a list built in the wrong place makes it run every time.
- [[04 One frame, from tree to pixels]]: Puzzles 0 to 3 ended with an up-to-date tree of UI elements. A tree isn't pixels yet. Here's what Compose does with it in every frame, in three steps, and why a parent sizes each child only once.
- [[05 Four layers, one edge per platform]]: Puzzles 0 to 4 followed one screen from a composable to pixels. Those steps live in different libraries, stacked on top of each other. Here's the stack, the one plug that keeps the runtime away from pixels, and why only one edge of it had to be written again for iOS.

## Module 2: One screen, two platforms

Trace state reads, placement, native UI and accessibility through the same shared bookmark screen.

- [[06 Who read the bookmark count]]: Module 1 took Compose apart. Now a real shared screen. Tap a bookmark, find where the count is read, and move that read so only the header runs again.
- [[07 Which work does a moving card need]]: Move the shared card as the user scrolls. Defer the read once more, this time to a later phase, and predict which work a frame can reuse.
- [[08 Which side hosts the other]]: Place a shared bookmarks screen in an iOS app, then put an Apple text field inside the shared screen.
- [[09 Can VoiceOver understand the bookmark]]: A custom bookmark icon looks right. Make its action understandable without seeing the screen.

## Practice chapters

- [[Practice chapter 1|Trace identity, effects and accessible output]]

[[Final project]]

## Coming next

- Module 3: Compose Multiplatform on iOS (coming): Skia through Skiko, inside ComposeUIViewController, one Metal-backed view, how frames are scheduled with CADisplayLink at up to 120 Hz, how touches arrive, and where a frame's time goes on an iPhone.
- Module 4: Living with UIKit (coming): Interop in both directions done properly, text input and the keyboard, accessibility in depth, and looking at home on iOS.
- Module 5: Shared app plumbing (coming): Resources, navigation, lifecycle and ViewModel in common code, performance on iOS, testing, and Compose Multiplatform or SwiftUI, screen by screen.
- Module 6: Expert floor (coming): Effects and their lifetimes, snapshots in depth, CompositionLocal, custom layouts and Modifier.Node, lazy layouts, and the compiler's stability reports.

[[Glossary]]
