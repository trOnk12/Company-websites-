---
source: https://pachulski.dev/course/compose/
tags: [course/compose]
---

# Compose Multiplatform, one screen from state to pixels

Follow a shared bookmark screen from state reads to rendering, across the iOS hosting boundary and through a VoiceOver check.

From [pachulski.dev](https://pachulski.dev/course/compose/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: One screen, two platforms

Trace state, placement, native UI and accessibility through the same screen.

- [[00 Who read the bookmark count]]: Tap a bookmark. Work out which part of a shared screen has to run again.
- [[01 Which work does a moving card need]]: Move the shared card as the user scrolls. Predict which parts of a screen update can be reused.
- [[02 Which side hosts the other]]: Place a shared bookmarks screen in an iOS app, then put an Apple text field inside the shared screen.
- [[03 Can VoiceOver understand the bookmark]]: A custom bookmark icon looks right. Make its action understandable without seeing the screen.


[[Glossary]]
