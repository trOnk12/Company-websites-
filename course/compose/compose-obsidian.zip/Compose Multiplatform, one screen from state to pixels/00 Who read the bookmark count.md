---
course: "Compose Multiplatform, one screen from state to pixels"
puzzle: 0
source: https://pachulski.dev/course/compose/00-state-reads-and-ui
tags: [course/compose]
---

# Who read the bookmark count?

> [!summary] The idea to keep
> A read of observable state gives Compose a dependency to track. When the value changes, Compose can revisit the parts that read it.

## The problem

A reading app has a header that shows the number of bookmarks and a card with a static title. Tapping a bookmark changes the count from 2 to 3. How does Compose know which code needs to run again?

## See it

![Who read the bookmark count?](https://pachulski.dev/course/compose/gifs/state-reads-and-ui.gif)

Step through it: https://pachulski.dev/course/compose/00-state-reads-and-ui

## The building block

A **tracked state read** is a dependency that Compose records when your code reads an observable value. Here the header reads the bookmark count inside a composable function, a function that describes UI.

```kotlin
@Composable
fun BookmarkCount(count: State<Int>) {
    Text("Bookmarks: ${count.value}")
}
```

The button event changes the observable count held elsewhere. Compose schedules **recomposition**, running again the parts of the composition that need to update their UI description. The header reads 3 and describes new text. A sibling with a static title has no dependency on this count. Compose can skip unrelated work when it can reuse the result.

That dependency comes from the read. Holding a reference to the state object and reading its value are different operations. If you read the value at the screen's top and hand an integer down, the read happened at the top, even though the header displays it.

## Go deeper: Move one read

- If the header receives a state object and only reads its value inside the header, where is the observable read?::It takes place in the header. Passing the object from the parent does not by itself read the count.

## Check yourself

#flashcards/compose

Only the count changes. Which UI code depends directly on the count?::The header that read the count. Locate the observable read.

The parent now reads the integer and passes it to the header. Where does Compose observe that read?::In the parent code. The location of the actual read determines the dependency.

The count is stored only in an ordinary mutable field. What change would let Compose observe edits?::Store the value in observable state and read it in the UI. Use an observable value and actually read it.

## Sources

- [Android Developers: Lifecycle of composables](https://developer.android.com/develop/ui/compose/lifecycle)
- [Android Developers: State and Jetpack Compose](https://developer.android.com/develop/ui/compose/state)
