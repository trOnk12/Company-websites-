---
course: "Compose Multiplatform, one screen from state to pixels"
puzzle: 1
source: https://pachulski.dev/course/compose/01-the-tree-compose-remembers
tags: [course/compose]
---

# The tree Compose remembers

> [!summary] The idea to keep
> The first run of your composables builds the composition, a tree of groups, one per call, nested the way the calls nest, and kept after they return. Composables such as Text and Button also leave a node, a real UI element. Groups keep values in slots (last time's arguments, what you remember), and the runtime stores all of it in call order in the slot table. On the next run, a call finds its own group and slots again by its call site, the place in the code it's called from.

**Builds on:** [[00 What @Composable really does]]

## The problem

Puzzle 0 showed every composable call recording a group through the Composer, and then returning. When a function returns, its local variables are gone. So where does `remember { mutableStateOf(0) }` keep that 0 between runs? And when `Counter` runs again, how does it find its own 0, and not the one from another `Counter` on the same screen?

## See it

![The tree Compose remembers](https://pachulski.dev/course/compose/gifs/slots.gif)

Step through it: https://pachulski.dev/course/compose/01-the-tree-compose-remembers

## The building block

The first time your composables run, the Composer builds the **composition**: a tree of groups, one per call, nested the way the calls nest. Android's docs put it in one line: "A Composition is a tree-structure of the composables that describe your UI." Unlike the calls, it stays: from then on it's only updated, by recomposition.

Some calls leave more than a group. `Text`, `Button`, `Column`: the composables that end up on screen also leave a **node**, a real UI element with a size and a place on screen. In Compose's UI library the node class is `LayoutNode` ("an element in the layout hierarchy"). Your own `Greeting` and `Counter` leave only groups: they arrange calls, they aren't elements. So the nodes, taken out of the groups, form a smaller tree of their own: the UI tree, which puzzle 4 turns into pixels.

Groups also keep values, in **slots**. A slot holds an argument the call got last time (puzzle 3 compares against it) or a value it asked to keep. That's all `remember` is: in the runtime's own code, `remember { … }` is a call that asks the current Composer to store the value in the composition, at this group. It doesn't become a global: two `Counter`s are two groups, with two slots and two counts.

The runtime keeps the whole composition in one structure, the **slot table**: groups and their slots, laid out in the order the calls ran, each group's children right after it. Reading it from start to end is fast; jumping around in it is not, which is why the next run walks it in the same order as the calls.

So how does a call find its slots again? By where it's called from. Each **call site**, the place in your source where a composable is called, gets its own key from the compiler plugin (puzzle 0). On the next run, the calls come in the same order from the same call sites, so `Counter` reaches the same group and finds its 0. If an if-statement adds a call above it, `Counter` still keeps its count: its call site didn't move.

## Go deeper: What does the slot table look like in memory?

- Why does the runtime store groups in call order in arrays, instead of as a tree of objects that point at each other?::The next run reads the groups in the same order the calls happen, and a front-to-back scan of an array is fast. The default table is two arrays (one for groups, one for slots) with a gap kept where the next insert goes, so adding a group there doesn't shift everything after it. A linked-list version, faster for moving and deleting content, is being tried behind a flag that's off by default.

## In practice

The one place call sites aren't enough is a loop: every item comes from the same call site, so the runtime tells them apart by their order. Insert an item at the top and every item below gets the slots of the one that used to be in its position. The **`key()`** composable fixes it by giving each item an identity of its own: `key(movie.id) { MovieRow(movie) }`. `LazyColumn` takes the same idea as a `key` parameter on its items.

## The analogy

The stage manager's prompt book from puzzle 0. The first performance fills it in, scene after scene, with each scene's notes inside it (its group). On some pages there's a set piece that goes on stage (a node). Margins hold what to keep: which hat the hero wore (slots). The next night, the scenes come in the same order, so the stage manager turns to the same page and finds the same hat. A new scene added before it gets a new page; the old pages don't move.

## Check yourself

#flashcards/compose

Above `Counter()`, whose count is 3, you add a call to ErrorBanner() that runs only if showError is true. showError becomes true and the screen runs again. What's Counter's count now?::Still 3: Counter's call site didn't change, so it finds its own slots. Same call site, same slots.

Why does a remembered value survive, when the composable's local variables are gone after it returns?::It sits in a slot of the call's group, which outlives the call. It lives in the slot table, not on the call.

A list shows rows for Ana, Ben and Cleo in a plain for-loop, and you type a draft into Ben's row (kept with `remember`). An item is inserted at the top. Without `key()`, where does the draft end up?::In Ana's row, now second, which inherits the slots of position 2. Same call site, so order decides, until key() gives each row its own identity.

## Sources

- [Android Developers: Lifecycle of composables](https://developer.android.com/develop/ui/compose/lifecycle) ("A Composition is a tree-structure of the composables that describe your UI."; "A Composition can only be produced by an initial composition and updated by recomposition."; "The instance of a composable in Composition is identified by its call site."; "Even though LoginInput went from being called first to being called second, the LoginInput instance will be preserved across recompositions."; "Compose uses the execution order in addition to the call site to keep the instance distinct in the Composition."; "By wrapping a block of code with a call to the key composable with one or more values passed in, those values will be combined to be used to identify that instance in the composition.")
- [Android Developers: State and Jetpack Compose](https://developer.android.com/develop/ui/compose/state) ("A value computed by remember is stored in the Composition during initial composition, and the stored value is returned during recomposition.")
- [Compose runtime source: Composables.kt](https://github.com/androidx/androidx/blob/c13c6d0da6b9d595f72caad9fa1759c6a8aece83/compose/runtime/runtime/src/commonMain/kotlin/androidx/compose/runtime/Composables.kt#L24) (`remember` is "currentComposer.cache(false, calculation)"; and in Composer.kt, cache's comment: "Cache, that is remember, a value in the composition data of a composition.")
- [Compose runtime source: SlotTable.kt](https://github.com/androidx/androidx/blob/c13c6d0da6b9d595f72caad9fa1759c6a8aece83/compose/runtime/runtime/src/commonMain/kotlin/androidx/compose/runtime/composer/gapbuffer/SlotTable.kt#L95) ("Groups form a tree where the child groups are immediately after the group fields for the group. This data structure favors a linear scan of the children. Random access is expensive unless it is through a group anchor."; "Slots are allocated in the slots array and are stored in order of their respective groups."; a node is "where the LayoutNode is stored by the slot table")
- [Compose runtime source: ComposeRuntimeFlags.kt](https://github.com/androidx/androidx/blob/ebe7964173e100eb8833f6d4d5e59cba3656db0d/compose/runtime/runtime/src/commonMain/kotlin/androidx/compose/runtime/ComposeRuntimeFlags.kt#L31) ("A feature flag than can be used to enable the link-list based slot table implementation instead of the gap buffer based slot table."; "This flag is **disabled** by default.")
- [Compose UI source: LayoutNode.kt](https://github.com/androidx/androidx/blob/c13c6d0da6b9d595f72caad9fa1759c6a8aece83/compose/ui/ui/src/commonMain/kotlin/androidx/compose/ui/node/LayoutNode.kt#L77) ("An element in the layout hierarchy, built with compose UI.")
