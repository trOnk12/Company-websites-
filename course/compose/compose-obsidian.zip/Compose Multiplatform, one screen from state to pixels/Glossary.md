# Glossary: Compose Multiplatform, one screen from state to pixels

Every word the course teaches, in the order it does. #flashcards/compose/words

$changed::A hidden Int the caller fills with what it already knows about each argument, such as "same as last time". (taught in [[00 What @Composable really does]])

Composer::The runtime's recorder: the compiler plugin passes it into every composable call, and the call records what it did through it. (taught in [[00 What @Composable really does]])

endRestartGroup::The Composer call the plugin puts at the end of a composable's body: it closes the call's group. (taught in [[00 What @Composable really does]])

group::Everything one composable call records between its start and its end, labelled with a key from its place in the source. (taught in [[00 What @Composable really does]])

startRestartGroup::The Composer call the plugin puts at the start of a composable's body: it opens the call's group. (taught in [[00 What @Composable really does]])

call site::The place in your source code where a composable is called; it decides which group a call finds again. (taught in [[01 The tree Compose remembers]])

composition::The tree of groups your composables recorded on their first run, with their nodes and slots, kept and updated between runs. (taught in [[01 The tree Compose remembers]])

key()::A composable that gives the calls inside it an identity from a value you pass, such as an item's id. (taught in [[01 The tree Compose remembers]])

LayoutNode::Compose UI's node class: one element of the UI tree, with a size, a position and a way to draw itself. (taught in [[01 The tree Compose remembers]])

node::A real UI element that a composable such as Text leaves in the composition; in Compose UI it's a LayoutNode. (taught in [[01 The tree Compose remembers]])

slot::A cell where a group keeps a value: an argument it got last time, or something it asked to remember. (taught in [[01 The tree Compose remembers]])

slot table::The runtime's storage for the composition: every group and its slots, in the order the calls ran. (taught in [[01 The tree Compose remembers]])

Recomposer::The part of the runtime that decides when marked groups run: it waits for the next frame, then runs every marked restart group again. (taught in [[02 Who read that state]])

restart group::The group of a composable that Compose can run again on its own, from its start. (taught in [[02 Who read that state]])

snapshot state::A value holder made by mutableStateOf; Compose watches every read and every write of its value. (taught in [[02 Who read that state]])

state read::Code reading a snapshot state's value while Compose runs it; Compose notes which group was running. (taught in [[02 Who read that state]])

@Stable::An annotation that promises Compose a type is stable when it can't prove it. (taught in [[03 What gets skipped]])

skipping::A call not running its body, and keeping last time's record, because its arguments equal the ones it got last time. (taught in [[03 What gets skipped]])

skipToGroupEnd()::The Composer call a skipped composable makes: jump past its group and keep what it recorded last time. (taught in [[03 What gets skipped]])

stable::A type that can't change without Compose seeing it: it never changes, or changes only through snapshot state. Compared with equals. (taught in [[03 What gets skipped]])

strong skipping::The compiler mode, on by default since Kotlin 2.0.20, that lets a call with unstable arguments be skipped when the same instances (===) come back. (taught in [[03 What gets skipped]])

unstable::A type that could change without Compose seeing it, such as a class with a var or a List. (taught in [[03 What gets skipped]])

canvas::The drawing surface a node draws itself onto, with commands like drawRect; Compose's Canvas is an interface. (taught in [[04 One frame, from tree to pixels]])

constraints::The smallest and largest width and height a parent allows a child. (taught in [[04 One frame, from tree to pixels]])

drawRect::A canvas command that fills a rectangle with a colour. (taught in [[04 One frame, from tree to pixels]])

measure::Ask a child to choose its size within the constraints; in Compose, each child is measured at most once per layout. (taught in [[04 One frame, from tree to pixels]])

phase::One of the three stages Compose runs to make a frame, in order: composition, layout, drawing. (taught in [[04 One frame, from tree to pixels]])

placement::A parent setting each measured child's x, y position, relative to itself. (taught in [[04 One frame, from tree to pixels]])

Applier::The plug between the runtime and a tree: it inserts, moves and removes nodes; the runtime knows nodes only through it. (taught in [[05 Four layers, one edge per platform]])

Compose UI::The layer that turns nodes into a screen: LayoutNode, Modifier, input, layout and drawing. (taught in [[05 Four layers, one edge per platform]])

design system::A set of rules and ready-made components for how an app looks: colours, type, shapes. Material Design is Google's. (taught in [[05 Four layers, one edge per platform]])

foundation::The layer of building blocks with no look of their own: Row, Column, LazyColumn, gestures. (taught in [[05 Four layers, one edge per platform]])

UiApplier::Compose UI's Applier on Android: it inserts, moves and removes LayoutNodes. (taught in [[05 Four layers, one edge per platform]])

deferring a read::Moving a state read out of a parent and into the child, or the later phase, that needs the value, so less code runs again when it changes. (taught in [[06 Who read the bookmark count]])

drawBehind::A modifier whose lambda runs during drawing, so a state read inside it reruns drawing alone. (taught in [[07 Which work does a moving card need]])

hosting boundary::The region where one UI system embeds another. (taught in [[08 Which side hosts the other]])

accessibility semantics::Labels, roles, states and actions exposed to assistive technology. (taught in [[09 Can VoiceOver understand the bookmark]])
