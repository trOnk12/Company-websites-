# Glossary: Compose Multiplatform, one screen from state to pixels

Every word the course teaches, in the order it does. #flashcards/compose/words

tracked state read::A dependency Compose records when code reads an observable value. (taught in [[00 Who read the bookmark count]])

rendering phases::The composition, layout and drawing work used to produce the UI. (taught in [[01 Which work does a moving card need]])

hosting boundary::The region where one UI system embeds another. (taught in [[02 Which side hosts the other]])

accessibility semantics::Labels, roles, states and actions exposed to assistive technology. (taught in [[03 Can VoiceOver understand the bookmark]])
