# Glossary: Compose Multiplatform, one screen from state to pixels

Every word the course teaches, in the order it does. #flashcards/compose/words

$changed::A hidden Int the caller fills with what it already knows about each argument, such as "same as last time". (taught in [[00 What @Composable really does]])

Composer::The runtime's recorder: the compiler plugin passes it into every composable call, and the call records what it did through it. (taught in [[00 What @Composable really does]])

endRestartGroup::The Composer call the plugin puts at the end of a composable's body: it closes the call's group. (taught in [[00 What @Composable really does]])

group::Everything one composable call records between its start and its end, labelled with a key: from the function's name and parameters for a function's own group, from its position for groups inside a body. (taught in [[00 What @Composable really does]])

org.jetbrains.kotlin.plugin.compose::The id of the Gradle plugin that turns the Compose compiler plugin on in a build. (taught in [[00 What @Composable really does]])

startRestartGroup::The Composer call the plugin puts at the start of a composable's body: it opens the call's group. (taught in [[00 What @Composable really does]])

composition::The tree of groups your composables recorded on their first run, with their nodes and slots, kept and updated between runs. (taught in [[01 The tree Compose remembers]])

LayoutNode::Compose UI's node class: one element of the UI tree, with a size, a position and a way to draw itself. (taught in [[01 The tree Compose remembers]])

node::A real UI element that a composable such as Text leaves in the composition; in Compose UI it's a LayoutNode. (taught in [[01 The tree Compose remembers]])

slot::A cell where a group keeps a value: an argument it got last time, or something it asked to remember. (taught in [[01 The tree Compose remembers]])

slot table::The runtime's storage for the composition: every group and its slots, in the order the calls ran. (taught in [[01 The tree Compose remembers]])

call site::The place in your source where a composable is called; calls from one call site, such as a loop, are told apart only by their order. (taught in [[02 Which row is which]])

key()::A composable that wraps calls in a movable group whose identity comes from a value you pass, such as an item's id, so the group moves with its item. (taught in [[02 Which row is which]])

Recomposer::The part of the runtime that decides when marked groups run: it waits for the next frame, then runs every marked restart group again. (taught in [[03 Who read that state]])

restart group::The group of a composable that Compose can run again on its own, from its start; Android's docs call it a restart scope. (taught in [[03 Who read that state]])

snapshot state::A value holder made by mutableStateOf; Compose watches every read and every write of its value. (taught in [[03 Who read that state]])

state read::Code reading a snapshot state's value while Compose runs it; Compose notes which group was running. (taught in [[03 Who read that state]])

@Immutable::An annotation that promises Compose a type never changes once an instance is made. (taught in [[04 What gets skipped]])

@Stable::An annotation that promises Compose a type is stable when it can't prove it. (taught in [[04 What gets skipped]])

skipping::A call not running its body, and keeping last time's record, because its arguments equal the ones it got last time. (taught in [[04 What gets skipped]])

skipToGroupEnd()::The Composer call a skipped composable makes: jump past its group and keep what it recorded last time. (taught in [[04 What gets skipped]])

stable::A type that can't change without Compose seeing it: it never changes, or changes only through snapshot state. Compared with equals. (taught in [[04 What gets skipped]])

strong skipping::The compiler mode, on by default since Kotlin 2.0.20, that lets a call with unstable arguments be skipped when the same instances (===) come back. (taught in [[04 What gets skipped]])

unstable::A type that could change without Compose seeing it, such as a class with a var or a List. (taught in [[04 What gets skipped]])

canvas::The drawing surface a node draws itself onto, with commands like drawRect; Compose's Canvas is an interface. (taught in [[05 One frame, from tree to pixels]])

constraints::The smallest and largest width and height a parent allows a child. (taught in [[05 One frame, from tree to pixels]])

drawRect::A canvas command that fills a rectangle with a colour. (taught in [[05 One frame, from tree to pixels]])

measure::Ask a child to choose its size within the constraints; in Compose, each child is measured at most once per layout. (taught in [[05 One frame, from tree to pixels]])

phase::One of the three stages Compose runs to make a frame, in order: composition, layout, drawing. (taught in [[05 One frame, from tree to pixels]])

placement::A parent setting each measured child's x, y position, relative to itself. (taught in [[05 One frame, from tree to pixels]])

androidMain::The source set for code that only Android builds compile. (taught in [[06 Four layers, one edge per platform]])

Applier::The plug between the runtime and a tree: it inserts, moves and removes nodes; the runtime knows nodes only through it. (taught in [[06 Four layers, one edge per platform]])

Compose UI::The layer that turns nodes into a screen: LayoutNode, Modifier, input, layout and drawing. (taught in [[06 Four layers, one edge per platform]])

darwinMain::The source set shared by every Apple target. (taught in [[06 Four layers, one edge per platform]])

DefaultUiApplier::Compose UI's Applier on iOS, desktop and web, in skikoMain: it inserts, moves and removes LayoutNodes. (taught in [[06 Four layers, one edge per platform]])

design system::A set of rules and ready-made components for how an app looks: colours, type, shapes. Material Design is Google's. (taught in [[06 Four layers, one edge per platform]])

foundation::The layer of building blocks with no look of their own: Row, Column, LazyColumn, gestures. (taught in [[06 Four layers, one edge per platform]])

iosMain::The source set for code that only iOS builds compile. (taught in [[06 Four layers, one edge per platform]])

nativeMain::The source set shared by every Kotlin/Native target. (taught in [[06 Four layers, one edge per platform]])

skikoMain::The source set shared by every Compose target that draws with Skia through Skiko: iOS, desktop and web. (taught in [[06 Four layers, one edge per platform]])

UiApplier::Compose UI's Applier on Android: it inserts, moves and removes LayoutNodes. (taught in [[06 Four layers, one edge per platform]])

deferring a read::Moving a state read out of a parent and into the child, or the later phase, that needs the value, so less code runs again when it changes. (taught in [[07 Who read the bookmark count]])

drawBehind::A modifier whose lambda runs during drawing, so a state read inside it reruns drawing alone. (taught in [[08 Which work does a moving card need]])

@ObjCAction::A Kotlin/Native annotation that makes a Kotlin function callable as an Objective-C action method. (taught in [[09 Which side hosts the other]])

addTarget::UIKit's call that tells a control to call a method by name when an event happens. (taught in [[09 Which side hosts the other]])

editingChanged::Our Kotlin method on the text field, called by UIKit on every edit. (taught in [[09 Which side hosts the other]])

factory::UIKitView's parameter that creates the native view, once, when the call enters the composition. (taught in [[09 Which side hosts the other]])

hosting boundary::The region where one UI system embeds another. (taught in [[09 Which side hosts the other]])

Main_iosKt::The name Swift sees for the top-level functions of the Kotlin file main.ios.kt. (taught in [[09 Which side hosts the other]])

MainViewController::Our Kotlin function in iosMain that returns ComposeUIViewController { BookmarksScreen() } for Swift to use. (taught in [[09 Which side hosts the other]])

makeUIViewController::The method of a UIViewControllerRepresentable that creates the wrapped controller. (taught in [[09 Which side hosts the other]])

onRelease::UIKitView's parameter that runs when the native view leaves the composition for good, to clean up. (taught in [[09 Which side hosts the other]])

onReset::UIKitView's parameter that, when set, lets Compose reuse the same native view instead of creating a new one. (taught in [[09 Which side hosts the other]])

UIControlEventEditingChanged::The UIKit event a text field sends whenever its text changes. (taught in [[09 Which side hosts the other]])

UINavigationController::UIKit's controller for a stack of screens, with a title bar, a back button and the back swipe. (taught in [[09 Which side hosts the other]])

UIViewController::UIKit's base class for a controller that manages one screen's views. (taught in [[09 Which side hosts the other]])

UIViewControllerRepresentable::A SwiftUI protocol that wraps a UIKit view controller so SwiftUI can show it. (taught in [[09 Which side hosts the other]])

accessibility semantics::Labels, roles, states and actions exposed to assistive technology. (taught in [[10 Can VoiceOver understand the bookmark]])

detectTapGestures::A helper inside pointerInput that calls you back on a tap. (taught in [[10 Can VoiceOver understand the bookmark]])

IconToggleButton::Material's on/off icon button; it is toggleable with a checkbox role and merges its children's semantics. (taught in [[10 Can VoiceOver understand the bookmark]])

Modifier.toggleable::A foundation modifier that makes an element on or off, reacts to taps and accessibility actions, and adds the matching semantics. (taught in [[10 Can VoiceOver understand the bookmark]])

onValueChange::toggleable's callback: asked to flip the value, after a tap or an accessibility action. (taught in [[10 Can VoiceOver understand the bookmark]])

pointerInput::A modifier that hands raw touch events to your code; it adds no semantics. (taught in [[10 Can VoiceOver understand the bookmark]])

Role.Switch::The semantics role that tells accessibility services an element is a switch. (taught in [[10 Can VoiceOver understand the bookmark]])
