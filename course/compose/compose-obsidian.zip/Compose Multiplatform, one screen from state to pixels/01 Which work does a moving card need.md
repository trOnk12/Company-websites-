---
course: "Compose Multiplatform, one screen from state to pixels"
puzzle: 1
source: https://pachulski.dev/course/compose/01-read-in-the-right-phase
tags: [course/compose]
---

# Which work does a moving card need?

> [!summary] The idea to keep
> Where a value is read determines which work that value can invalidate. A read only during placement can move a card without changing its UI description.

**Builds on:** [[00 Who read the bookmark count]]

## The problem

The card slides vertically as you scroll. Its content and size stay the same. Which work needs to run in response to the scrolling value?

## See it

![Which work does a moving card need?](https://pachulski.dev/course/compose/gifs/read-in-the-right-phase.gif)

Step through it: https://pachulski.dev/course/compose/01-read-in-the-right-phase

## The building block

There are three useful **rendering phases**. Composition decides which UI to describe. Layout measures sizes and places each item. Drawing paints the result. A tracked state read records the phase that actually reads the value.

In this version the observable value is read inside the placement lambda, which is code that runs later when Compose places the card. The position value is already an integer number of pixels:

```kotlin
Box(
    modifier = Modifier.offset {
        IntOffset(x = 0, y = position.value)
    }
) {
    Text("Saved item")
}
```

Now a change in position can update placement without recomposing this box for that change. Related drawing can still run. If you first evaluate the same value up in composition, you have already created a composition dependency by the time the modifier receives it.

Suppose the position only controls a painted color. If the color is read exclusively while drawing, Compose can redraw it without recomposing or relaying out the UI for that change. Choose the phase by the work your value actually drives.

## Go deeper: Move versus measure

- Why might a card changing its height require more work than a card moving vertically?::A different height can require new measurements and can move neighboring items. Moving an item of the same size can reuse its measurement.

## Check yourself

#flashcards/compose

The position is read only during placement. What can Compose reuse for that change?::The card description and its measured size. Moving an already measured card is placement work.

Moving the read into a local variable at the top of the composable has what effect?::The changed value can now invalidate composition. Follow where evaluation happens.

A value affects only paint and is read only during drawing. What follows when it changes?::Drawing can run without relaying out the screen. A drawing dependency can invalidate drawing directly.

## Sources

- [Android Developers: Jetpack Compose phases](https://developer.android.com/develop/ui/compose/phases)
