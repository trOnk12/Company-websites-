---
course: "Kotlin Multiplatform, from the compiler up"
puzzle: 2
source: https://pachulski.dev/course/kmp/02-how-kotlin-calls-apple
tags: [course/kmp]
---

# How Kotlin calls Apple

> [!summary] The idea to keep
> Kotlin/Native ships platform libraries: prebuilt Kotlin bindings for each target's native libraries. On Apple targets they cover Apple's frameworks, such as Foundation and UIKit, so code in iosMain can import platform.UIKit.UIDevice and call it like Kotlin. They exist only on Apple targets, which is why such calls live in iosMain, never in commonMain.

**Builds on:** [[01 What every target has]]

## The problem

Puzzle 1 said iosMain can use what only iOS has. On iOS, the operating system's name and version come from an Apple class called `UIDevice`. Apple wrote it for its own languages, not for Kotlin. So how can a Kotlin file in iosMain call it?

## See it

![How Kotlin calls Apple](https://pachulski.dev/course/kmp/gifs/platform.gif)

Step through it: https://pachulski.dev/course/kmp/02-how-kotlin-calls-apple

## The building block

Apple's code is grouped into **frameworks**: bundles of ready-made code for one area. Foundation has basics like dates, text and unique IDs; **UIKit** has everything about screens, including `UIDevice`.

Kotlin can't read those frameworks directly. So Kotlin/Native ships **platform libraries**: prebuilt Kotlin descriptions, called bindings, of each target's native libraries. For Apple targets they cover Apple's frameworks. The packages are there by default, under `platform.`:

```kotlin
// iosMain
import platform.UIKit.UIDevice

fun systemName(): String = UIDevice.currentDevice.systemName()
```

The binding tells Kotlin what the call is named, what it accepts, and what it returns. The implementation belongs to UIKit. When you build, Kotlin/Native records the connection to UIKit so the call can reach Apple's code when the app runs.

Two consequences:

- These bindings exist only for Apple targets. That's why `import platform.UIKit` works in iosMain and fails in commonMain (puzzle 1's rule: common code may use only what every target has).
- The names and shapes are Apple's, not Kotlin's: `UIDevice.currentDevice` reads a little foreign. That's normal.

## The analogy

A phrasebook for a country whose language you don't speak. You don't learn the language; you look up the phrase and say it, and you're understood. Each target comes with its own phrasebook, and the Apple one only works in Apple's countries.

## Check yourself

#flashcards/kmp

Why does `import platform.UIKit.UIDevice` fail in commonMain?::The binding exists only for Apple targets. Apple bindings, Apple targets only.

Who wrote the Kotlin binding for `UIDevice`?::Kotlin/Native ships it, prebuilt, as part of its platform libraries. Prebuilt, shipped with Kotlin/Native.

What's the difference between a framework and a platform library?::A framework is Apple's own code, while a platform library is Kotlin's binding to it. The real code vs Kotlin's way in.

## Sources

- [Kotlin docs: Platform libraries](https://kotlinlang.org/docs/native-platform-libs.html) ("To provide access to native services of operating systems, the Kotlin/Native distribution includes a set of prebuilt libraries specific to each target. These are called platform libraries. The packages from platform libraries are available by default"; "The Kotlin/Native compiler automatically detects which platform libraries are accessed and links the necessary ones")
- [Kotlin docs: Use platform-specific APIs](https://kotlinlang.org/docs/multiplatform/multiplatform-connect-to-apis.html) (the iOS example calls `UIDevice.currentDevice.systemName()`)
- [Kotlin docs: The basics of a Multiplatform project](https://kotlinlang.org/docs/multiplatform/multiplatform-discover-project.html) (an Apple source set using `import platform.Foundation.NSUUID`)
