---
course: "Kotlin Multiplatform, from the compiler up"
puzzle: 9
source: https://pachulski.dev/course/kmp/09-two-ways-to-free-memory
tags: [course/kmp]
---

# Two ways to free memory

> [!summary] The idea to keep
> Cross-language ownership can delay deinitialization beyond the point where Kotlin stops using an object. Strong references spanning Kotlin and Swift can form a cycle. Break an ownership link according to the intended lifetime.

**Builds on:** [[03 A promise and its keepers]] · [[08 Weak references and closures]]

## The problem

Puzzle 7 showed the two ways to free memory: Kotlin/Native traces from the roots, Swift counts. Now they meet. A Swift view controller holds your Kotlin view model, and the view model keeps a callback, a Swift closure, that points back at the screen. Who frees what, and when?

## See it

![Two ways to free memory](https://pachulski.dev/course/kmp/gifs/gcarc.gif)

Step through it: https://pachulski.dev/course/kmp/09-two-ways-to-free-memory

## The building block

Kotlin/Native keeps its objects in a **shared heap**, one pool any thread can use, and frees them with the tracing GC from puzzle 7. Swift objects are freed by reference counting (ARC), also from puzzle 7.

Where the two meet, each side follows its own rules:

- A Kotlin object that Swift holds stays alive while Swift holds it: to the GC, Swift's hold counts as a root.
- A Swift object that Kotlin holds isn't freed the moment Kotlin lets go. Releasing the cross-language hold can require a collection and subsequent deinitialization work. Other strong owners can extend the lifetime further. So Swift's `deinit` can run later than a Swift developer expects.
- A cycle that runs through both sides, Kotlin to Swift and back, can leak. The GC can't see through Swift's counts, and ARC can't see through Kotlin's references, so neither sees the whole loop, and the cross-language ownership remains live.

The fix is puzzle 8's: make one link weak. Usually the Swift side holds the Kotlin object normally and the callback refers back to the Swift object weakly: in Swift, capture it with `[weak self]` in the closure you hand to Kotlin.

## The analogy

Two cities that clean their streets differently: one sends a sweeper round every few days (the GC), the other picks up each item the moment its owner lets go (ARC). An item two neighbours from different cities each keep "for the other one" is never picked up by either.

## Check yourself

#flashcards/kmp

Kotlin holds a Swift object, then lets go. When does Swift's `deinit` run?::After the cross-language hold and any other strong references are released. Release follows Kotlin's GC, not the moment of letting go.

Why can a cycle through both Kotlin and Swift leak?::Because each side keeps the other alive, and neither sees the loop. Two tools, each seeing half the loop.

What's the difference between a tracing GC and ARC?::A tracing GC frees what it can't reach, while ARC frees at a count of zero. Search in passes vs count as you go.

## Sources

- [Kotlin docs: Kotlin/Native memory management](https://kotlinlang.org/docs/native-memory-manager.html) ("Objects are stored in a shared heap and can be accessed from any thread. Tracing garbage collection is performed periodically to collect objects that are not reachable from the 'roots', like local and global variables.")
- [Kotlin docs: Integration with Swift/Objective-C ARC](https://kotlinlang.org/docs/native-arc-integration.html) ("An object is reclaimed only during the garbage collection. This applies to Swift/Objective-C objects that cross interop boundaries into Kotlin/Native"; "To avoid retain cycles, use weak or unowned references")
