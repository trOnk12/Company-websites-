---
course: "Kotlin Multiplatform, from the compiler up"
puzzle: 5
source: https://pachulski.dev/course/kmp/05-how-swift-sees-your-kotlin
tags: [course/kmp]
---

# How Swift sees your Kotlin

> [!summary] The idea to keep
> In the Objective-C framework export path, Swift imports the Objective-C declarations and calls the Kotlin/Native implementation. Swift export is a separate integration option.

**Builds on:** [[04 An iOS app in one puzzle]]

## The problem

In puzzle 0, Kotlin/Native compiled your shared code to native code for the iPhone. But the iOS app is written in Swift, by a team that may never open a Kotlin file. Native code is just instructions for a CPU: it has no names, no types, no "here's a class called LoginRules". How does Swift know what's in there, and how to call it?

## See it

![How Swift sees your Kotlin](https://pachulski.dev/course/kmp/gifs/swift.gif)

Step through it: https://pachulski.dev/course/kmp/05-how-swift-sees-your-kotlin

## The building block

For iOS, Kotlin/Native packs your shared code into a **framework**: Apple's format for a library. A framework holds two things: the compiled code, and a description of what's inside, so other code knows what it can call.

That description is a **header**: a file that lists every class, function and type, without their code. Kotlin writes it in **Objective-C**, the older language of Apple's platforms, because Swift can call Objective-C directly. This lesson uses Objective-C framework export. Kotlin also offers a separate Swift export path with its own supported features.

A Gradle task builds the framework (it takes its name from your shared module, often called shared), and the iOS app's project in Xcode, Apple's counterpart of Android Studio, links it in. So the iOS team imports the framework, and in Swift your `LoginRules` class looks like any other Objective-C class: Swift reads the header and calls the native code behind it.

That middle step has a price. Objective-C is older and simpler than both Kotlin and Swift, so some things don't survive the trip. The next puzzle shows which.

## The analogy

A book translated into a third language before it reaches its readers. The readers never see the original; they read the translation. Whatever that third language has no words for gets flattened on the way.

## Check yourself

#flashcards/kmp

The iOS team opens this Objective-C-exported framework in Xcode. What do they read to learn your API?::The Objective-C header Kotlin/Native wrote for it. Swift learns your API from the Objective-C header.

Why does this export path describe your code in Objective-C?::Because Swift can call Objective-C directly, so it's the bridge both sides understand. Objective-C is the language Swift already knows how to call.

What's the difference between a framework and a header?::The framework is the package; the header describes its API. Package vs its description.

## Sources

- [Kotlin docs: Interoperability with Swift/Objective-C](https://kotlinlang.org/docs/native-objc-interop.html) ("Kotlin/Native provides indirect interoperability with Swift through Objective-C. This document covers how you can use Kotlin declarations in Swift/Objective-C code")
- [Kotlin docs: The basics of Kotlin Multiplatform project structure](https://kotlinlang.org/docs/multiplatform/multiplatform-discover-project.html) ("When it's built into an iOS framework, common Kotlin is treated as Kotlin/Native")
