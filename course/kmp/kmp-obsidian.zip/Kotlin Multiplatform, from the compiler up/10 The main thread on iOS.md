---
course: "Kotlin Multiplatform, from the compiler up"
puzzle: 10
source: https://pachulski.dev/course/kmp/10-the-main-thread-on-ios
tags: [course/kmp]
---

# The main thread on iOS

> [!summary] The idea to keep
> iOS's main thread runs a run loop, the role of Android's Looper: it waits for work, handles it, and waits again. Work for it waits in the main queue, the role of the MessageQueue, and DispatchQueue.main.async plays handler.post. As on Android, UIKit may be touched only from the main thread, and slow work there freezes the screen.

**Builds on:** [[06 Lost in translation]]

## The problem

Your shared code updates data that the iOS screen shows. On Android you'd make sure that happens on the main thread, which you know as a Looper with a MessageQueue. What does iOS have instead, and does the same "UI only on the main thread" rule apply?

## See it

![The main thread on iOS](https://pachulski.dev/course/kmp/gifs/mainthread.gif)

Step through it: https://pachulski.dev/course/kmp/10-the-main-thread-on-ios

## The building block

Same shape, different names:

| Android | iOS | Its job |
|---|---|---|
| Looper | **run loop** | keeps the main thread alive: wait for work, handle it, wait again |
| MessageQueue | **main queue** | the line of tasks waiting for the main thread |
| `handler.post { }` | `DispatchQueue.main.async { }` | add a task to that line |

The main thread's **run loop** handles touches, timers and the tasks in the main queue, one at a time. Apple describes it as an event-processing loop that keeps the thread busy when there's work and lets it sleep when there isn't.

The rule you know holds: UIKit, like Android's UI toolkit, may be touched only from the main thread. And the same consequence follows: a slow task on the main thread holds up every touch and frame behind it.

```swift
DispatchQueue.global().async {        // slow work off the main thread
    let image = loadImage()
    DispatchQueue.main.async {        // back to the main queue
        imageView.image = image       // UI: main thread only
    }
}
```

## The analogy

The same shop under a new owner: the counter clerk (the main thread) still serves one customer at a time from one line (the main queue), and only the clerk may touch the shop window (the UI). Only the signs changed.

## Check yourself

#flashcards/kmp

Which iOS piece plays the role of Android's MessageQueue?::The main queue, where tasks wait for the main thread. The waiting line is the main queue.

A background thread sets `imageView.image` directly. What's wrong?::UIKit may be touched only from the main thread, as on Android. UI: main thread only.

What's the difference between the run loop and the main queue?::The run loop keeps the main thread working, while the main queue is the line of tasks it takes from. The worker's loop vs its in-tray.

## Sources

- [Apple: Threading Programming Guide, Run Loops](https://developer.apple.com/library/archive/documentation/Cocoa/Conceptual/Multithreading/RunLoopManagement/RunLoopManagement.html) ("A run loop is an event processing loop that you use to schedule work and coordinate the receipt of incoming events. The purpose of a run loop is to keep your thread busy when there is work to do and put your thread to sleep when there is none.")
- [Apple: DispatchQueue](https://developer.apple.com/documentation/dispatch/dispatchqueue) ("An object that manages the execution of tasks serially or concurrently on your app's main thread or on a background thread")
