# Design and verify a shared library boundary

## Which source set can own this dependency?

A source set defines code compiled for a set of targets. A dependent source set sees declarations in the source sets it depends on. Shared code must be compilable for every participating target. Put platform-specific implementations at the narrowest appropriate boundary and keep the common contract free of platform types.

### Worked example

Android and two iOS targets need bookmark validation. Both iOS targets also need a Foundation-backed adapter. Put validation in commonMain and the adapter in iosMain when the default hierarchy supplies that shared Apple source set. Compile for both simulator and device targets. A green Android build says nothing about a missing iOS declaration.

### Try it

A method signature in commonMain returns an iOS framework object. Would moving only its body to iosMain make the shared API portable?

### Compare your answer

The signature itself still requires the Apple type. Define a common value or interface and convert at the Apple boundary. Verify the target graph as well as the source files; matching folder names alone do not establish dependency edges.

[Source · Kotlin · Source set hierarchy](https://kotlinlang.org/docs/multiplatform/multiplatform-hierarchy.html)

## Who owns the callback after the screen closes?

Kotlin/Native's garbage collector and Swift/Objective-C reference counting cooperate at the interop boundary. Releasing the last Swift reference to a Kotlin object does not promise immediate collection of everything it held. Explicitly model callback registration, cancellation and the ownership of long-lived subscriptions.

### Worked example

A Swift screen stores a shared presenter. The presenter retains a callback which strongly captures that screen. On dismissal, record whether the registration is still active and whether further updates reach the old screen. Break the ownership cycle where appropriate and have the lifecycle owner cancel the registration.

### Try it

After unregistering, the object survives one observation. Does that prove cancellation failed?

### Compare your answer

Check separately whether callbacks stop, whether known strong references were removed and whether allocation growth stays bounded after repeated openings. Collection timing alone cannot establish which owner retained the object. A weak capture also does not stop an unnecessary subscription by itself.

[Source · Kotlin · Integration with Swift/Objective-C ARC](https://kotlinlang.org/docs/native-arc-integration.html)

## What does a common test actually cover?

Common tests express behavior once but run through target-specific test tasks. Host support, enabled targets and adapters determine which platforms actually execute the test. Record which target produced each result, especially where behavior crosses a native boundary.

### Worked example

Run the same bookmark validation cases on JVM and an iOS simulator. Then add separate adapter tests exercising platform storage. A memory fake returning the correct row proves the shared sorting rule under that fixture. It provides no evidence that a suspended write survives process restart on either platform.

### Try it

CI reports a passing JVM test task while the simulator task was skipped. What evidence belongs in a release review?

### Compare your answer

Report the JVM result and the missing Apple execution separately. Run the applicable Apple target in a compatible environment, capture its result and exercise the Swift-facing API from a consumer. Treat a missing test task differently from a passing test with zero failures.

[Source · Kotlin · Run multiplatform tests](https://kotlinlang.org/docs/multiplatform/multiplatform-run-tests.html)

[[Final project]]

[[Course map]]