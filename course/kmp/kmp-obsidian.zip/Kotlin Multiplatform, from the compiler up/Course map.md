---
source: https://pachulski.dev/course/kmp/
tags: [course/kmp]
---

# Kotlin Multiplatform, from the compiler up

Follow one Kotlin function through the Android and iOS builds. Then see what Swift can call, how memory and threads behave on iOS, and how Compose Multiplatform draws the UI.

From [pachulski.dev](https://pachulski.dev/course/kmp/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: One codebase, two worlds

From one source file to two kinds of machine code, how Kotlin reaches Apple's code, what an iOS app is, and how Swift sees what you built.

- [[00 One Kotlin function, two ways to run it]]: Follow the same addition from Kotlin source to Android and iOS. At each step, find out what is produced and what can run it.
- [[01 What every target has]]: In puzzle 0, one Kotlin file became bytecode and native code. But some code only makes sense on one platform. Here's how a project says which code goes where.
- [[02 How Kotlin calls Apple]]: In iosMain, your Kotlin can call Apple's own code, like the class that knows the operating system's name. But Apple's code isn't Kotlin. Here's how Kotlin/Native makes it callable.
- [[03 A promise and its keepers]]: In puzzle 1, common code couldn't call a platform's own APIs. But shared logic sometimes needs a small platform fact, like which phone it's running on. Here's how it asks without knowing.
- [[04 An iOS app in one puzzle]]: The next puzzles put your Kotlin inside an iOS app. If you've never opened one, here's the minimum: the language, the tool, and the iOS piece that plays the role of an Activity, with Android names next to each.
- [[05 How Swift sees your Kotlin]]: In puzzle 0, Kotlin/Native turned your code into native code for the iPhone. But the iOS app is written in Swift. Here's how Swift finds and calls what you built.
- [[06 Lost in translation]]: In puzzle 5, Swift saw your Kotlin through an Objective-C header. Objective-C is simpler than both languages, so some things don't make it across. Here are the three that bite.

## Module 2: Living on iOS

How memory is freed on each side and where that breaks, the main thread on iOS, coroutines there, and shipping one framework.

- [[07 Counting or tracing]]: Kotlin on iOS and Swift free unused objects in two completely different ways. Before they meet in your app, here's each one on its own, and the one shape of objects that only one of them can free.
- [[08 Weak references and closures]]: Puzzle 7 left Swift with a leak it can't see: two objects holding each other. Swift's fix is a reference that doesn't count. Here's how it works, and the most common way the cycle sneaks in: a lambda.
- [[09 Two ways to free memory]]: Your shared Kotlin runs inside an iOS app. Kotlin's objects are freed one way, Swift's another. Here's what happens where they hold on to each other.
- [[10 The main thread on iOS]]: On Android you know the main thread: a Looper takes messages from a queue, one at a time, and only that thread may touch the UI. iOS has the same shape under other names. Here they are, before your coroutines run on it.
- [[11 Whose thread is it]]: Your shared code uses coroutines and Dispatchers.Main. On Android, that's the main Looper. On iOS there's no Looper. Here's where your coroutines run, and the one thing Swift can't do to them.
- [[12 One framework, not two]]: In puzzle 5, Kotlin/Native packed your shared code into a framework. Your project has several shared modules. Here's why they should reach Swift as one framework, and what each exported line costs.

## Module 3: Sharing the UI

Compose from its one core idea, what Compose Multiplatform shares, and how it draws on iOS.

- [[13 Compose in one puzzle]]: The last module shares the UI itself, with Compose. If you've built screens with Activities and XML, here's the one idea Compose is built on, and the compiler step that makes it work, before we look at what can be shared.
- [[14 What Compose actually shares]]: One set of Compose UI code runs on Android and on iOS. "Same code" hides three layers. Here's which ones are shared, and the one that's written again for every platform.
- [[15 One canvas on iOS]]: On iOS, your Compose screen doesn't become UIKit buttons and labels. It's drawn. Here's what UIKit sees, and why VoiceOver and native controls need a bridge.

## Coming next

- Module 4: Compose Multiplatform in practice (coming): Touch, scrolling and text input on iOS; accessibility through VoiceOver; interop with SwiftUI and UIKit in both directions; resources and navigation.

[[Glossary]]
