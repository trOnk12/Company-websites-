---
source: https://pachulski.dev/course/kmp/
tags: [course/kmp]
---

# Kotlin Multiplatform, from the compiler up

Follow one Kotlin function through the Android and iOS builds. Then see what Swift can call, how memory and threads behave on iOS, and how Compose Multiplatform draws the UI.

From [pachulski.dev](https://pachulski.dev/course/kmp/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: One codebase, two worlds

From one source file to two kinds of machine code, how Kotlin reaches Apple's code, what an iOS app is, and how Swift sees what you built.

- [[00 One Kotlin function, two ways to run it]]: Follow the same addition from Kotlin source to Android and iOS. At each step, find out what is produced and what can run it.
- [[01 What every target has]]: In puzzle 0, one Kotlin file became bytecode and native code. But some code only makes sense on one platform. Here's how a project says which code goes where.
- [[02 How Kotlin calls Apple]]: In iosMain, your Kotlin can call Apple's own code, like the class that knows the operating system's name. But Apple's code isn't Kotlin. Here's how Kotlin/Native makes it callable.
- [[03 A promise and its keepers]]: In puzzle 1, common code couldn't call a platform's own APIs. But shared logic sometimes needs a small platform fact, like which phone it's running on. Here's how it asks without knowing.
- [[04 An iOS app in one puzzle]]: The next puzzles put your Kotlin inside an iOS app. If you've never opened one, here's the minimum: the language, the tool, and the iOS piece that plays the role of an Activity, with Android names next to each.
- [[05 How Swift sees your Kotlin]]: In puzzle 0, Kotlin/Native turned your code into native code for the iPhone. But the iOS app is written in Swift. Here's how Swift finds and calls what you built.
- [[06 Lost in translation]]: In puzzle 5, Swift saw your Kotlin through an Objective-C header. Objective-C is simpler than both languages, so some things don't make it across. Here are the three that bite.

## Module 2: Living on iOS

How memory is freed on each side and where that breaks, the main thread on iOS, coroutines there, and shipping one framework.

- [[07 Counting or tracing]]: Kotlin on iOS and Swift free unused objects in two completely different ways. Before they meet in your app, here's each one on its own, and the one shape of objects that only one of them can free.
- [[08 Weak references and closures]]: Puzzle 7 left Swift with a leak it can't see: two objects holding each other. Swift's fix is a reference that doesn't count. Here's how it works, and the most common way the cycle sneaks in: a lambda.
- [[09 Two ways to free memory]]: Your shared Kotlin runs inside an iOS app. Kotlin's objects are freed one way, Swift's another. Here's what happens where they hold on to each other.
- [[10 The main thread on iOS]]: On Android you know the main thread: a Looper takes messages from a queue, one at a time, and only that thread may touch the UI. iOS has the same shape under other names. Here they are, before your coroutines run on it.
- [[11 Whose thread is it]]: Your shared code uses coroutines and Dispatchers.Main. On Android, that's the main Looper. On iOS there's no Looper. Here's where your coroutines run, and the one thing Swift can't do to them.
- [[12 One framework, not two]]: In puzzle 5, Kotlin/Native packed your shared code into a framework. Your project has several shared modules. Here's why they should reach Swift as one framework, and what each exported line costs.

## Module 3: Sharing the UI

Compose from its one core idea, what Compose Multiplatform shares, and how it draws on iOS.

- [[13 Compose in one puzzle]]: The last module shares the UI itself, with Compose. If you've built screens with Activities and XML, here's the one idea Compose is built on, and the compiler step that makes it work, before we look at what can be shared.
- [[14 What Compose actually shares]]: One set of Compose UI code runs on Android and on iOS. "Same code" hides three layers. Here's which ones are shared, and the one that's written again for every platform.
- [[15 One canvas on iOS]]: On iOS, your Compose screen doesn't become UIKit buttons and labels. It's drawn. Here's what UIKit sees, and why VoiceOver and native controls need a bridge.

## Module 4: The build

What the kotlin { } block declares, the tree of source sets between commonMain and each target, who can see what, where each library goes, what a klib holds, how one dependency line finds every target's file, and how platform code is handed in.

- [[16 The kotlin { } block]]: Puzzle 1 said, in passing, that you list the targets in the build file. You use Gradle every day, but a shared module's build file has a block you've never written. Here's what it declares, and why "Android and iOS" means three targets.
- [[17 Source sets in between]]: In puzzle 16, every target got a source set of its own, and none of them was iosMain. Your iOS code is the same for a real iPhone and the simulator, and it shouldn't be written twice. Here's where iosMain really comes from.
- [[18 Who can see what]]: Puzzle 17 built a tree of source sets. Code in iosMain calls functions in commonMain all the time. Can commonMain call one in iosMain? And which of Apple's APIs may appleMain use? Here's the rule behind both answers.
- [[19 Dependencies per source set]]: In an Android module, every library goes into one dependencies block for the whole module. In a shared module, the source set you add a library to decides which code can use it. Here's where each kind of library goes.
- [[20 What a klib is]]: In puzzle 19, one line in commonMain brought Ktor's core into every iOS source set. But something has to arrive on disk for the iOS build to use. Open that file, see what's inside, and why it isn't machine code yet.
- [[21 One line, every target]]: Puzzle 20 showed that a klib is built for one target, yet in puzzle 19 you wrote one line for Ktor's core and every target's build got its own file. Here's the published file that makes that work, and how each compilation finds its part.
- [[22 expectactual or an interface]]: Puzzle 3 kept a small promise with expect and actual, and said bigger platform services usually go behind an interface instead. Here's what that means in a real module, how the right implementation is handed in on each platform, and how to choose.

## Module 5: Kotlin/Native under the hood

What happens after the klibs: the link stage and LLVM, the linker, static or dynamic frameworks, frameworks and XCFrameworks, reading a crash with a dSYM, and where build time and binary size go.

- [[23 From IR to machine code]]: Puzzle 20 left your code and every library as IR inside klibs, with machine code promised for later. Here's the later step, the program that writes the instructions for the iPhone's processor, and why Kotlin didn't write that program itself.
- [[24 One binary the linker]]: Puzzle 23's LLVM wrote instructions for your code, Ktor's, the standard library's and Kotlin's runtime, but your code calls Ktor, and Ktor calls Apple. Here's the step that joins them into one framework, connects every call, and leaves out what nothing uses.
- [[25 Static or dynamic]]: Puzzle 24's linker made one binary for your Kotlin. The iOS app has a binary of its own, built by Xcode from Swift. Here are the two moments the two can be joined, what each costs, and the one line that picks between them.
- [[26 Framework or XCFramework]]: Every framework from puzzle 23's link stage is built for one target. The iOS team builds for a real iPhone in the morning and for the simulator in the afternoon. Here's why one merged file can't serve both, and how an XCFramework does.
- [[27 Reading a crash from the field]]: A user's iPhone crashed inside your Kotlin code, and the report Apple collected is a list of numbers. Here's what those numbers are, the file that turns them back into function names and lines, and why that file must be kept for every build you ship.
- [[28 Build time and binary size]]: Your iOS colleagues wait minutes after every Kotlin change, and the app grew after you exported one more module. With the compile and link stages, LLVM, the linker and XCFrameworks from this module, you can now tell where the time and the bytes go, and which work to skip.

## Practice chapters

- [[Practice chapter 1|Design and verify a shared library boundary]]

[[Final project]]

## Coming next

- Module 6: Across the boundary (coming): Reading the generated header; generics, sealed classes and enums in Swift; default arguments, overloads and names (@ObjCName, @HiddenFromObjC); exceptions as an error contract and Kotlin crashes in crash reports; suspend and Flow from Swift, threads and cancellation; SKIE and Swift export.
- Module 7: Shipping it to iOS (coming): How Xcode gets your framework (embedAndSignAppleFrameworkForXcode, signing); Swift Package Manager with a binary XCFramework; CocoaPods; the local and the released loop; versioning a shared module and its dSYMs; CI for Apple targets.
- Module 8: The common stack (coming): Ktor's HttpClient and engines; kotlinx.serialization without reflection; SQLDelight; key-value settings; dependency injection with Koin across platforms; a ViewModel in commonMain; dates, files and bytes with kotlinx-datetime and kotlinx-io.
- Module 9: Testing shared code (coming): commonTest and kotlin.test on every target; running tests on the iOS simulator; fakes instead of mocks; testing coroutines with runTest; testing the API Swift really sees.
- Module 10: Architecture and migrating an existing app (coming): Where to draw the shared line; modules and one export module; migrating an Android app step by step; designing the API with the Swift team; memory and performance in production; crashes and logs from the field.
- Module 11: The expert's toolbox (coming): cinterop for C and Objective-C libraries; compiler plugins and KSP in multiplatform; upgrading Kotlin safely; publishing your own multiplatform library; a capstone that ships one feature end to end.

[[Glossary]]
