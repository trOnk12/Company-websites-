---
source: https://pachulski.dev/course/kmp/
tags: [course/kmp]
---

# Kotlin Multiplatform, from the compiler up

How one Kotlin codebase runs on Android and on an iPhone that has no JVM, what Swift actually sees of your code, how memory and threads behave on iOS, and how Compose Multiplatform draws your UI there. Built from the compiler up, one small puzzle at a time.

From [pachulski.dev](https://pachulski.dev/course/kmp/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: One codebase, two worlds

From one source file to two kinds of machine code, and how Swift sees what you built.

- [[00 One Kotlin, many machines]]: Your app's rules are written twice, once in Kotlin for Android and once in Swift for iOS. Here's how one Kotlin file ends up running on both, even though an iPhone has no JVM.
- [[01 What every target has]]: In puzzle 0, one Kotlin file became bytecode and native code. But some code only makes sense on one platform. Here's how a project says which code goes where.
- [[02 A promise and its keepers]]: In puzzle 1, common code couldn't call a platform's own APIs. But shared logic sometimes needs a small platform fact, like which phone it's running on. Here's how it asks without knowing.
- [[03 How Swift sees your Kotlin]]: In puzzle 0, Kotlin/Native turned your code into native code for the iPhone. But the iOS app is written in Swift. Here's how Swift finds and calls what you built.
- [[04 Lost in translation]]: In puzzle 3, Swift saw your Kotlin through an Objective-C header. Objective-C is simpler than both languages, so some things don't make it across. Here are the three that bite.

## Module 2: Living on iOS, and sharing the UI

Memory, threads and shipping on iOS; then what Compose Multiplatform shares and how it draws there.

- [[05 Two ways to free memory]]: Your shared Kotlin runs inside an iOS app. Kotlin's objects are freed one way, Swift's another. Here's what happens where they hold on to each other.
- [[06 Whose thread is it]]: Your shared code uses coroutines and Dispatchers.Main. On Android, that's the main Looper. On iOS there's no Looper. Here's where your coroutines run, and the one thing Swift can't do to them.
- [[07 One framework, not two]]: In puzzle 3, Kotlin/Native packed your shared code into a framework. Your project has several shared modules. Here's why they should reach Swift as one framework, and what each exported line costs.
- [[08 What Compose actually shares]]: One set of Compose UI code runs on Android and on iOS. "Same code" hides three layers. Here's which ones are shared, and the one that's written again for every platform.
- [[09 One canvas on iOS]]: On iOS, your Compose screen doesn't become UIKit buttons and labels. It's drawn. Here's what UIKit sees, and why VoiceOver and native controls need a bridge.

## Coming next

- Module 3: Compose Multiplatform in practice (coming): Touch, scrolling and text input on iOS; accessibility through VoiceOver; interop with SwiftUI and UIKit in both directions; resources and navigation.

[[Glossary]]
