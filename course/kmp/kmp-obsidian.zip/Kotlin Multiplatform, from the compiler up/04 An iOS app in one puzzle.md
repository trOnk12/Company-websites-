---
course: "Kotlin Multiplatform, from the compiler up"
puzzle: 4
source: https://pachulski.dev/course/kmp/04-an-ios-app-in-one-puzzle
tags: [course/kmp]
---

# An iOS app in one puzzle

> [!summary] The idea to keep
> iOS apps are written in Swift, in Xcode, Apple's IDE. Screens are built with UIKit, Apple's screen framework (or the newer SwiftUI). A view controller manages one screen's UI elements and reacts to the user, much like an Activity or Fragment. Swift looks like Kotlin: let is val, var is var, and a class can subclass UIViewController the way yours subclasses Activity.

**Builds on:** [[02 How Kotlin calls Apple]]

## The problem

From the next puzzle on, Swift code calls your Kotlin. You've never read **Swift**, iOS's language, never opened **Xcode**, Apple's IDE, and you don't know what an iOS screen is made of. What's the smallest picture you need?

## See it

![An iOS app in one puzzle](https://pachulski.dev/course/kmp/gifs/iosapp.gif)

Step through it: https://pachulski.dev/course/kmp/04-an-ios-app-in-one-puzzle

## The building block

Four names, each with its Android twin:

| iOS | What it is | On Android |
|---|---|---|
| **Swift** | The language of iOS apps | Kotlin |
| **Xcode** | Apple's IDE, which builds and runs the app | Android Studio |
| **UIKit** | Apple's framework for screens: buttons, lists, text | the View system |
| **view controller** | Manages one screen's UI elements and reacts to the user | an Activity or Fragment |

A minimal screen in Swift:

```swift
import UIKit

class GreetingViewController: UIViewController {
    let label = UILabel()           // let is Kotlin's val

    override func viewDidLoad() {   // like onCreate
        super.viewDidLoad()
        label.text = "Hello"
        label.frame = view.bounds
        label.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(label)
    }
}
```

Swift will feel close to Kotlin: classes, `override`, optional types written with `?`, and lambdas (Swift has its own name for them, coming in puzzle 8). Newer iOS apps often use **SwiftUI**, Apple's declarative UI, the way newer Android apps use Compose; KMP works with both.

Where does your Kotlin fit? It becomes a library this app imports (puzzle 5), and Swift code, often inside a view controller, calls it.

## The analogy

Moving to a city where the streets have different names but the same layout. "Main Street" is "Hauptstraße"; once you have the map of names, you find your way.

## Check yourself

#flashcards/kmp

Which iOS piece plays the role of an Activity?::A view controller: it runs one screen and reacts to the user. One screen, one view controller.

In Swift, `let label = UILabel()`. What's the Kotlin equivalent of `let`?::`val`: set once, never reassigned. let is val.

What's the difference between UIKit and SwiftUI?::UIKit builds screens from UI objects you change, while SwiftUI describes them declaratively, like Compose. Objects vs descriptions.

## Sources

- [Apple: UIViewController](https://developer.apple.com/documentation/uikit/uiviewcontroller) ("A view controller's main responsibilities include the following: Updating the contents of the views, usually in response to changes to the underlying data; Responding to user interactions with views")
- [The Swift Programming Language: The Basics](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/) (constants are declared with `let`, variables with `var`)
