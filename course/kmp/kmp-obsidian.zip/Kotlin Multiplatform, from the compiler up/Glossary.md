# Glossary: Kotlin Multiplatform, from the compiler up

Every word the course teaches, in the order it does. #flashcards/kmp/words

back end::The part of the compiler that produces output for one kind of machine. (taught in [[00 One Kotlin, many machines]])

bytecode::Instructions for a virtual machine, like the JVM, not for a CPU. (taught in [[00 One Kotlin, many machines]])

compiler::The program that turns source code into something a machine can run. (taught in [[00 One Kotlin, many machines]])

front end::The part of the compiler that reads and checks your code, the same for every target. (taught in [[00 One Kotlin, many machines]])

Kotlin/Native::Kotlin's back end that produces native code, built on LLVM. (taught in [[00 One Kotlin, many machines]])

native code::Machine code that runs directly on the CPU, with no virtual machine. (taught in [[00 One Kotlin, many machines]])

target::A platform Kotlin can compile for: the JVM, Android, iOS, the web, desktop. (taught in [[00 One Kotlin, many machines]])

androidMain::The source set compiled only for Android. (taught in [[01 What every target has]])

common code::Code in commonMain: shared by every target. (taught in [[01 What every target has]])

commonMain::The source set compiled for every target. (taught in [[01 What every target has]])

iosMain::The source set compiled only for iOS. (taught in [[01 What every target has]])

source set::A folder of code compiled for a chosen set of targets. (taught in [[01 What every target has]])

actual::A platform's implementation of an expect declaration. (taught in [[02 A promise and its keepers]])

expect::A declaration in common code that promises each platform will provide it. (taught in [[02 A promise and its keepers]])

framework::Apple's package for a library: the compiled code plus a description of its API. (taught in [[03 How Swift sees your Kotlin]])

header::The file that describes a library's API, without its code. (taught in [[03 How Swift sees your Kotlin]])

Objective-C::The older language of Apple's platforms, which Swift can call directly. (taught in [[03 How Swift sees your Kotlin]])

@Throws::Lists which Kotlin exceptions may cross into Swift as errors. (taught in [[04 Lost in translation]])

completion handler::A function you pass in, called later with the result: Objective-C's way of saying "later". (taught in [[04 Lost in translation]])

shared heap::Kotlin/Native's one pool of objects, reachable from any thread. (taught in [[05 Two ways to free memory]])

tracing GC::A collector that, from time to time, frees every object it can't reach from the roots. (taught in [[05 Two ways to free memory]])

cancellation::Stopping a coroutine or task before it finishes. (taught in [[06 Whose thread is it]])

main queue::iOS's queue of tasks for the main thread; Dispatchers.Main on iOS is backed by it. (taught in [[06 Whose thread is it]])

dead code elimination::Leaving out compiled code nothing uses, to keep the app small. (taught in [[07 One framework, not two]])

umbrella framework::One framework that carries every Kotlin module Swift needs, with one runtime. (taught in [[07 One framework, not two]])

Compose Multiplatform::JetBrains' version of Jetpack Compose that runs on Android, iOS, desktop and web. (taught in [[08 What Compose actually shares]])

Compose runtime::The part of Compose that tracks state and decides what to recompose; it knows nothing about pixels. (taught in [[08 What Compose actually shares]])

platform layer::The part written per target: the window, touches, the drawing surface, text input and accessibility. (taught in [[08 What Compose actually shares]])

accessibility tree::The list of on-screen elements, with labels and roles, that VoiceOver reads. (taught in [[09 One canvas on iOS]])

ComposeUIViewController::Hosts Compose UI inside an iOS app as one UIKit view controller. (taught in [[09 One canvas on iOS]])

Skia::A graphics library that draws shapes and text; on iOS, Compose draws with it through Skiko. (taught in [[09 One canvas on iOS]])

UIKitView::Places a real UIKit view, such as a map, inside a Compose screen. (taught in [[09 One canvas on iOS]])
