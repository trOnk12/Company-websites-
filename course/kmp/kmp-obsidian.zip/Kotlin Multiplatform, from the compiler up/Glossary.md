# Glossary: Kotlin Multiplatform, from the compiler up

Every word the course teaches, in the order it does. #flashcards/kmp/words

add w1, w0, w1::Arm addition with w1 as the destination. (taught in [[00 One Kotlin function, two ways to run it]])

back end::The part of the compiler that produces output for one kind of machine. (taught in [[00 One Kotlin function, two ways to run it]])

bytecode::Encoded instructions read by a program such as the JVM or ART. (taught in [[00 One Kotlin function, two ways to run it]])

compiler::The program that turns source code into something a machine can run. (taught in [[00 One Kotlin function, two ways to run it]])

front end::The part of the compiler that reads and checks your code, the same for every target. (taught in [[00 One Kotlin function, two ways to run it]])

JVM::The Java Virtual Machine: a program that runs compiled Kotlin and Java on any computer. (taught in [[00 One Kotlin function, two ways to run it]])

Kotlin/Native::Kotlin's back end that produces native code, built on LLVM. (taught in [[00 One Kotlin function, two ways to run it]])

native code::Machine code that runs directly on the CPU, with no virtual machine. (taught in [[00 One Kotlin function, two ways to run it]])

target::A platform Kotlin can compile for: the JVM, Android, iOS, the web, desktop. (taught in [[00 One Kotlin function, two ways to run it]])

w0::An Arm register in the addition example. (taught in [[00 One Kotlin function, two ways to run it]])

w1::A second Arm register in the addition example. (taught in [[00 One Kotlin function, two ways to run it]])

androidMain::The source set compiled only for Android. (taught in [[01 What every target has]])

common code::Code in commonMain: shared by every target. (taught in [[01 What every target has]])

commonMain::The source set compiled for every target. (taught in [[01 What every target has]])

iosMain::The source set compiled only for iOS. (taught in [[01 What every target has]])

source set::A folder of code compiled for a chosen set of targets. (taught in [[01 What every target has]])

framework::Apple's package for a library: the compiled code plus a description of its API. (taught in [[02 How Kotlin calls Apple]])

platform library::A prebuilt Kotlin binding to a target's native libraries, shipped with Kotlin/Native; on Apple targets, to Apple's frameworks. (taught in [[02 How Kotlin calls Apple]])

UIKit::Apple's framework for screens: buttons, lists, text. (taught in [[02 How Kotlin calls Apple]])

actual::A platform's implementation of an expect declaration. (taught in [[03 A promise and its keepers]])

expect::A declaration in common code that promises each platform will provide it. (taught in [[03 A promise and its keepers]])

Swift::The language of iOS apps, close to Kotlin. (taught in [[04 An iOS app in one puzzle]])

SwiftUI::Apple's declarative UI framework, the iOS counterpart of Compose. (taught in [[04 An iOS app in one puzzle]])

view controller::Manages one iOS screen's views and reacts to the user, like an Activity. (taught in [[04 An iOS app in one puzzle]])

Xcode::Apple's IDE: builds and runs iOS apps, like Android Studio. (taught in [[04 An iOS app in one puzzle]])

header::The file that describes a library's API, without its code. (taught in [[05 How Swift sees your Kotlin]])

Objective-C::The older language of Apple's platforms, which Swift can call directly. (taught in [[05 How Swift sees your Kotlin]])

@Throws::Lists which Kotlin exceptions may cross into Swift as errors. (taught in [[06 Lost in translation]])

async function::Swift's version of a suspend function, called with await. (taught in [[06 Lost in translation]])

completion handler::A function you pass in, called later with the result: Objective-C's way of saying "later". (taught in [[06 Lost in translation]])

cycle::Objects that hold each other with strong references, so none of their counts reaches zero. (taught in [[07 Counting or tracing]])

heap::The memory area where objects are created and kept. (taught in [[07 Counting or tracing]])

reference counting::Freeing each object the moment its count of strong references reaches zero; Swift calls it ARC. (taught in [[07 Counting or tracing]])

root::A reference the program certainly still has, like a local or global variable; tracing starts from the roots. (taught in [[07 Counting or tracing]])

strong reference::A reference that keeps its object alive by adding to its count. (taught in [[07 Counting or tracing]])

tracing GC::A garbage collector that starts from the roots, follows every reference, and frees what it didn't reach. (taught in [[07 Counting or tracing]])

[weak self]::A capture list that makes a closure hold self weakly. (taught in [[08 Weak references and closures]])

closure::Swift's lambda: a block of code that holds strong references to what it uses. (taught in [[08 Weak references and closures]])

deinit::Code in a Swift class that runs when an instance is freed. (taught in [[08 Weak references and closures]])

weak reference::A reference that doesn't add to the count, so it can't keep its object alive; it becomes nil when the object is freed. (taught in [[08 Weak references and closures]])

shared heap::Kotlin/Native's one pool of objects, reachable from any thread. (taught in [[09 Two ways to free memory]])

main queue::The line of tasks waiting for iOS's main thread: the MessageQueue's role. (taught in [[10 The main thread on iOS]])

run loop::iOS's version of the Looper: keeps the main thread waiting for work and handling it. (taught in [[10 The main thread on iOS]])

cancellation::Stopping a coroutine or task before it finishes. (taught in [[11 Whose thread is it]])

scope::A CoroutineScope: the owner of a group of coroutines; cancelling it cancels them all. (taught in [[11 Whose thread is it]])

Task::Swift's version of a launched coroutine. (taught in [[11 Whose thread is it]])

dead code elimination::Leaving out compiled code nothing uses, to keep the app small. (taught in [[12 One framework, not two]])

umbrella framework::One framework that carries every Kotlin module Swift needs, with one runtime. (taught in [[12 One framework, not two]])

XCFramework::One bundle holding a framework built for every Apple device and simulator. (taught in [[12 One framework, not two]])

composable::A Kotlin function marked @Composable that describes UI for its data. (taught in [[13 Compose in one puzzle]])

Compose compiler plugin::Part of the Kotlin compiler that rewrites composables so the runtime can track what each one showed. (taught in [[13 Compose in one puzzle]])

recomposition::Compose calling composables again because their data changed. (taught in [[13 Compose in one puzzle]])

remember::Keeps a value across recompositions. (taught in [[13 Compose in one puzzle]])

state::Data whose change makes Compose recompose what uses it. (taught in [[13 Compose in one puzzle]])

Compose Multiplatform::JetBrains' version of Jetpack Compose that runs on Android, iOS, desktop and web. (taught in [[14 What Compose actually shares]])

Compose runtime::The part of Compose that tracks state and decides what to recompose; it knows nothing about pixels. (taught in [[14 What Compose actually shares]])

platform layer::The part written per target: the window, touches, the drawing surface, text input and accessibility. (taught in [[14 What Compose actually shares]])

VoiceOver::iOS's screen reader. (taught in [[14 What Compose actually shares]])

accessibility tree::The list of on-screen elements, with labels and roles, that VoiceOver reads. (taught in [[15 One canvas on iOS]])

ComposeUIViewController::Hosts Compose UI inside an iOS app as one UIKit view controller. (taught in [[15 One canvas on iOS]])

semantics::What each UI element is and says (role, label), which Compose passes to accessibility tools. (taught in [[15 One canvas on iOS]])

Skia::A graphics library that draws shapes and text; on iOS, Compose draws with it through Skiko. (taught in [[15 One canvas on iOS]])

UIKitView::Places a real UIKit view, such as a map, inside a Compose screen. (taught in [[15 One canvas on iOS]])
