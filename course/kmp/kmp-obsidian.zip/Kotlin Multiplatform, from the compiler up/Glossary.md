# Glossary: Kotlin Multiplatform, from the compiler up

Every word the course teaches, in the order it does. #flashcards/kmp/words

add w1, w0, w1::Arm addition with w1 as the destination. (taught in [[00 One Kotlin function, two ways to run it]])

back end::The part of the compiler that produces output for one kind of machine. (taught in [[00 One Kotlin function, two ways to run it]])

bytecode::Encoded instructions read by a program such as the JVM or ART. (taught in [[00 One Kotlin function, two ways to run it]])

compiler::The program that turns source code into something a machine can run. (taught in [[00 One Kotlin function, two ways to run it]])

front end::The part of the compiler that reads and checks your code, the same for every target. (taught in [[00 One Kotlin function, two ways to run it]])

JVM::The Java Virtual Machine: a program that runs compiled Kotlin and Java on any computer. (taught in [[00 One Kotlin function, two ways to run it]])

Kotlin/Native::Kotlin's back end that produces native code, built on LLVM. (taught in [[00 One Kotlin function, two ways to run it]])

native code::Machine code that runs directly on the CPU, with no virtual machine. (taught in [[00 One Kotlin function, two ways to run it]])

target::A platform Kotlin can compile for: the JVM, Android, iOS, the web, desktop. (taught in [[00 One Kotlin function, two ways to run it]])

w0::An Arm register in the addition example. (taught in [[00 One Kotlin function, two ways to run it]])

w1::A second Arm register in the addition example. (taught in [[00 One Kotlin function, two ways to run it]])

androidMain::The source set compiled only for Android. (taught in [[01 What every target has]])

common code::Code in commonMain: shared by every target. (taught in [[01 What every target has]])

commonMain::The source set compiled for every target. (taught in [[01 What every target has]])

iosMain::The source set compiled only for iOS. (taught in [[01 What every target has]])

source set::A folder of code compiled for a chosen set of targets. (taught in [[01 What every target has]])

framework::Apple's package for a library: the compiled code plus a description of its API. (taught in [[02 How Kotlin calls Apple]])

platform library::A prebuilt Kotlin binding to a target's native libraries, shipped with Kotlin/Native; on Apple targets, to Apple's frameworks. (taught in [[02 How Kotlin calls Apple]])

UIKit::Apple's framework for screens: buttons, lists, text. (taught in [[02 How Kotlin calls Apple]])

actual::A platform's implementation of an expect declaration. (taught in [[03 A promise and its keepers]])

expect::A declaration in common code that promises each platform will provide it. (taught in [[03 A promise and its keepers]])

Swift::The language of iOS apps, close to Kotlin. (taught in [[04 An iOS app in one puzzle]])

SwiftUI::Apple's declarative UI framework, the iOS counterpart of Compose. (taught in [[04 An iOS app in one puzzle]])

view controller::Manages one iOS screen's views and reacts to the user, like an Activity. (taught in [[04 An iOS app in one puzzle]])

Xcode::Apple's IDE: builds and runs iOS apps, like Android Studio. (taught in [[04 An iOS app in one puzzle]])

header::The file that describes a library's API, without its code. (taught in [[05 How Swift sees your Kotlin]])

Objective-C::The older language of Apple's platforms, which Swift can call directly. (taught in [[05 How Swift sees your Kotlin]])

@Throws::Lists which Kotlin exceptions may cross into Swift as errors. (taught in [[06 Lost in translation]])

async function::Swift's version of a suspend function, called with await. (taught in [[06 Lost in translation]])

completion handler::A function you pass in, called later with the result: Objective-C's way of saying "later". (taught in [[06 Lost in translation]])

cycle::Objects that hold each other with strong references, so none of their counts reaches zero. (taught in [[07 Counting or tracing]])

heap::The memory area where objects are created and kept. (taught in [[07 Counting or tracing]])

reference counting::Freeing each object the moment its count of strong references reaches zero; Swift calls it ARC. (taught in [[07 Counting or tracing]])

root::A reference the program certainly still has, like a local or global variable; tracing starts from the roots. (taught in [[07 Counting or tracing]])

strong reference::A reference that keeps its object alive by adding to its count. (taught in [[07 Counting or tracing]])

tracing GC::A garbage collector that starts from the roots, follows every reference, and frees what it didn't reach. (taught in [[07 Counting or tracing]])

[weak self]::A capture list that makes a closure hold self weakly. (taught in [[08 Weak references and closures]])

closure::Swift's lambda: a block of code that holds strong references to what it uses. (taught in [[08 Weak references and closures]])

deinit::Code in a Swift class that runs when an instance is freed. (taught in [[08 Weak references and closures]])

weak reference::A reference that doesn't add to the count, so it can't keep its object alive; it becomes nil when the object is freed. (taught in [[08 Weak references and closures]])

shared heap::Kotlin/Native's one pool of objects, reachable from any thread. (taught in [[09 Two ways to free memory]])

main queue::The line of tasks waiting for iOS's main thread: the MessageQueue's role. (taught in [[10 The main thread on iOS]])

run loop::iOS's version of the Looper: keeps the main thread waiting for work and handling it. (taught in [[10 The main thread on iOS]])

cancellation::Stopping a coroutine or task before it finishes. (taught in [[11 Whose thread is it]])

scope::A CoroutineScope: the owner of a group of coroutines; cancelling it cancels them all. (taught in [[11 Whose thread is it]])

Task::Swift's version of a launched coroutine. (taught in [[11 Whose thread is it]])

:network::The example network module of puzzle 12. (taught in [[12 One framework, not two]])

binaries.framework::The block that declares a framework for a target. (taught in [[12 One framework, not two]])

dead code elimination::Leaving out compiled code nothing uses, to keep the app small. (taught in [[12 One framework, not two]])

export(project(":network"))::Exports the :network module to Swift through the framework. (taught in [[12 One framework, not two]])

umbrella framework::One framework that carries every Kotlin module Swift needs, with one runtime. (taught in [[12 One framework, not two]])

XCFramework::One bundle holding framework or library variants for selected Apple platforms and architectures. (taught in [[12 One framework, not two]])

composable::A Kotlin function marked @Composable that describes UI for its data. (taught in [[13 Compose in one puzzle]])

Compose compiler plugin::Part of the Kotlin compiler that rewrites composables so the runtime can track what each one showed. (taught in [[13 Compose in one puzzle]])

recomposition::Compose calling composables again because their data changed. (taught in [[13 Compose in one puzzle]])

remember::Keeps a value across recompositions. (taught in [[13 Compose in one puzzle]])

state::Data whose change makes Compose recompose what uses it. (taught in [[13 Compose in one puzzle]])

Compose Multiplatform::JetBrains' version of Jetpack Compose that runs on Android, iOS, desktop and web. (taught in [[14 What Compose actually shares]])

Compose runtime::The part of Compose that tracks state and decides what to recompose; it knows nothing about pixels. (taught in [[14 What Compose actually shares]])

platform layer::The part written per target: the window, touches, the drawing surface, text input and accessibility. (taught in [[14 What Compose actually shares]])

VoiceOver::iOS's screen reader. (taught in [[14 What Compose actually shares]])

accessibility tree::The list of on-screen elements, with labels and roles, that VoiceOver reads. (taught in [[15 One canvas on iOS]])

ComposeUIViewController::Hosts Compose UI inside an iOS app as one UIKit view controller. (taught in [[15 One canvas on iOS]])

semantics::What each UI element is and says (role, label), which Compose passes to accessibility tools. (taught in [[15 One canvas on iOS]])

Skia::A graphics library that draws shapes and text; on iOS, Compose draws with it through Skiko. (taught in [[15 One canvas on iOS]])

UIKitView::Places a real UIKit view, such as a map, inside a Compose screen. (taught in [[15 One canvas on iOS]])

androidLibrary::The older name of the Android target block, before version 8.12 of Android's plugin. (taught in [[16 The kotlin { } block]])

androidTarget::The older name of the Android target line, used with com.android.library. (taught in [[16 The kotlin { } block]])

com.android.library::Android's ordinary library plugin. (taught in [[16 The kotlin { } block]])

commonTest::The test source set compiled for every target, beside commonMain. (taught in [[16 The kotlin { } block]])

compilation::One compiler run for one target, over every source set that target uses: main for your code, test for your tests. (taught in [[16 The kotlin { } block]])

iosArm64::The iOS target for real iPhones. (taught in [[16 The kotlin { } block]])

iosArm64Main::The platform source set of the iosArm64 target. (taught in [[16 The kotlin { } block]])

iosSimulatorArm64::The iOS target for the simulator on an Apple-silicon Mac. (taught in [[16 The kotlin { } block]])

iosX64::The iOS target for the simulator on a Mac with an Intel chip. (taught in [[16 The kotlin { } block]])

kotlin { }::The block in a shared module's build.gradle.kts that declares its targets and source sets. (taught in [[16 The kotlin { } block]])

multiplatform plugin::The Gradle plugin, kotlin("multiplatform"), that reads the kotlin { } block and sets up targets, source sets and compilations. (taught in [[16 The kotlin { } block]])

platform source set::The source set made for exactly one target and named after it, such as androidMain or iosArm64Main. (taught in [[16 The kotlin { } block]])

appleMain::The intermediate source set compiled for every Apple target in the project. (taught in [[17 Source sets in between]])

default hierarchy template::The multiplatform plugin's built-in tree of intermediate source sets; it creates the ones that fit the targets you declare. (taught in [[17 Source sets in between]])

intermediate source set::A source set compiled for some, but not all, of the project's targets, such as iosMain. (taught in [[17 Source sets in between]])

nativeMain::The intermediate source set compiled for every Kotlin/Native target in the project. (taught in [[17 Source sets in between]])

dependsOn::The arrow from a source set to the one above it: it sees that one's code, can keep its expect promises, and gets its libraries. (taught in [[18 Who can see what]])

commonMain.dependencies::The dependencies block of one source set; iosMain.dependencies and the others work the same way. (taught in [[19 Dependencies per source set]])

multiplatform library::A library published for many targets with one common API, so commonMain can use it. (taught in [[19 Dependencies per source set]])

HttpClient::Ktor's HTTP client class. (taught in [[20 What a klib is]])

ios_arm64::How Kotlin/Native writes the iosArm64 target's name inside a klib and in published metadata. (taught in [[20 What a klib is]])

IR::Intermediate representation: the compiler's own checked form of the code, after the front end and before any machine code. (taught in [[20 What a klib is]])

klib::A Kotlin/Native library file: a zip, for one target, holding the code as IR, a description of its declarations and a manifest. (taught in [[20 What a klib is]])

:shared::How Gradle writes the name of a module called shared. (taught in [[21 One line, every target]])

Gradle module metadata::A file format published next to a library (the .module file) that lists the library's variants for Gradle. (taught in [[21 One line, every target]])

ios_simulator_arm64::How Kotlin/Native writes the iosSimulatorArm64 target's name in published metadata. (taught in [[21 One line, every target]])

publication::A separately named package of a library's files in a repository; a multiplatform library has one per target plus a root. (taught in [[21 One line, every target]])

variant::One version of a library, built for one kind of consumer and tagged with attributes such as its target. (taught in [[21 One line, every target]])

actual typealias::Keeps an expect class by naming an existing platform class. (taught in [[22 expectactual or an interface]])

Bookmarks::Code name in puzzle 22's example. (taught in [[22 expectactual or an interface]])

DefaultsStorage::Code name in puzzle 22's example. (taught in [[22 expectactual or an interface]])

dependency injection::Handing an object what it depends on from outside, instead of letting it create it. (taught in [[22 expectactual or an interface]])

dependency injection framework::A library, such as Koin, that builds objects and hands each one what it needs, from rules you write. (taught in [[22 expectactual or an interface]])

FakeStorage::Code name in puzzle 22's example. (taught in [[22 expectactual or an interface]])

Koin::A dependency injection framework that works in common code. (taught in [[22 expectactual or an interface]])

PrefsStorage::Code name in puzzle 22's example. (taught in [[22 expectactual or an interface]])

Storage::Code name in puzzle 22's example. (taught in [[22 expectactual or an interface]])

-Xprofile-phases::The compiler option that prints the time each phase took. (taught in [[23 From IR to machine code]])

link stage::The second stage of a Kotlin/Native build: once per final binary, it reads every klib and makes machine code. (taught in [[23 From IR to machine code]])

LinkBitcodeDependencies::The link-stage phase that merges bitcode files, such as the runtime, into the program. (taught in [[23 From IR to machine code]])

linkDebugFrameworkIosArm64::The Gradle task that builds a debug framework for iosArm64. (taught in [[23 From IR to machine code]])

linkReleaseFrameworkIosArm64::The Gradle task that builds a release framework for iosArm64. (taught in [[23 From IR to machine code]])

LLVM::A collection of reusable compiler parts: an optimizer and code generators for many processors, used by Kotlin/Native and Clang. (taught in [[23 From IR to machine code]])

LLVM IR::LLVM's own intermediate representation: lower level than Kotlin's IR, already marked with the target, but not yet instructions. (taught in [[23 From IR to machine code]])

PsiToIr::The compiler phase that writes IR, as named in its profiling log. (taught in [[23 From IR to machine code]])

runtime.bc::The main file of Kotlin's runtime, as LLVM bitcode, merged in at the link stage. (taught in [[23 From IR to machine code]])

-dead_strip::The linker option that removes machine code nothing refers to. (taught in [[24 One binary the linker]])

linker::The program that joins object code into one binary and connects each call to an address. (taught in [[24 One binary the linker]])

object code::Machine instructions that aren't a finished program yet: calls to other code are left open and named. (taught in [[24 One binary the linker]])

symbol::The name of a function or global variable inside compiled code, used to connect calls to it. (taught in [[24 One binary the linker]])

dynamic library::A library that stays a separate file and is loaded and connected when the app starts. (taught in [[25 Static or dynamic]])

dynamic loader::The program that loads an app's dynamic libraries and connects calls to them when the app starts. (taught in [[25 Static or dynamic]])

executable::The app's own binary: the file the phone starts. (taught in [[25 Static or dynamic]])

isStatic::Framework setting: true puts a static library inside instead of a dynamic one. (taught in [[25 Static or dynamic]])

static library::A library whose code is copied into the app's executable when the app is built. (taught in [[25 Static or dynamic]])

architecture::The family of instructions a processor understands, such as arm64 or x86-64. (taught in [[26 Framework or XCFramework]])

assembleSharedReleaseXCFramework::The task that builds the release XCFramework of a module called shared. (taught in [[26 Framework or XCFramework]])

assembleXCFramework::The Gradle task that links every target in an XCFramework and gathers them. (taught in [[26 Framework or XCFramework]])

binaryOption::Sets a Kotlin/Native binary option on one binary, such as bundleId or smallBinary. (taught in [[26 Framework or XCFramework]])

bundleId::The binary option that sets the framework's bundle ID in its Info.plist. (taught in [[26 Framework or XCFramework]])

Info.plist::A framework's small settings file. (taught in [[26 Framework or XCFramework]])

lipo::Apple's tool that merges binaries for different architectures into one universal file. (taught in [[26 Framework or XCFramework]])

universal framework::One framework file whose binary merges builds for different architectures; also called a fat framework. (taught in [[26 Framework or XCFramework]])

x86_64::How Apple writes the x86-64 architecture. (taught in [[26 Framework or XCFramework]])

XCFramework()::Gradle code that declares an XCFramework to assemble. (taught in [[26 Framework or XCFramework]])

./gradlew :shared:embedAndSignAppleFrameworkForXcode::The command the Run Script phase runs: Gradle, in the shared module, runs the embedAndSign task. (taught in [[27 How Xcode builds your Kotlin]])

$SRCROOT::Xcode's name for the iOS project's folder. (taught in [[27 How Xcode builds your Kotlin]])

build phase::One step of Xcode's build of an app target, such as Compile Sources; they run in order. (taught in [[27 How Xcode builds your Kotlin]])

cd "$SRCROOT/.."::The script line that steps up from the iOS project to the Gradle project. (taught in [[27 How Xcode builds your Kotlin]])

derived data::The folder where Xcode keeps its own build output for a project. (taught in [[27 How Xcode builds your Kotlin]])

embedAndSignAppleFrameworkForXcode::The Gradle task Xcode's Run Script runs: it links the one framework Xcode needs, copies it into derived data, and embeds and signs it. (taught in [[27 How Xcode builds your Kotlin]])

import shared::Swift's line that imports the Kotlin framework. (taught in [[27 How Xcode builds your Kotlin]])

KOTLIN_FRAMEWORK_BUILD_TYPE::The Xcode setting that tells the task to link a Debug or Release framework. (taught in [[27 How Xcode builds your Kotlin]])

linkDebugFrameworkIosSimulatorArm64::The link task for a debug simulator framework. (taught in [[27 How Xcode builds your Kotlin]])

OVERRIDE_KOTLIN_BUILD_IDE_SUPPORTED::The variable the IDE sets so the Run Script skips a second build. (taught in [[27 How Xcode builds your Kotlin]])

Run Script phase::A build phase that runs a shell script you write. (taught in [[27 How Xcode builds your Kotlin]])

build host::The machine that runs the build. (taught in [[28 What has to match]])

deployment target::The oldest OS version an app supports. (taught in [[28 What has to match]])

backtrace::The chain of functions that were running in one thread, as addresses in each binary. (taught in [[29 Reading a crash from the field]])

build UUID::A unique ID the build writes into a binary and its dSYM; they match only when it's identical. (taught in [[29 Reading a crash from the field]])

crash report::What iOS collects when an app crashes, including a backtrace for each thread. (taught in [[29 Reading a crash from the field]])

dSYM::A separate file of debug information for one release binary, used for symbolication. (taught in [[29 Reading a crash from the field]])

dwarfdump::The command that prints a dSYM's build UUID with --uuid. (taught in [[29 Reading a crash from the field]])

load address::Where in memory iOS placed a binary in one run; it changes from launch to launch. (taught in [[29 Reading a crash from the field]])

symbolication::Turning a crash report's addresses into function names and line numbers. (taught in [[29 Reading a crash from the field]])

xcrun crashlog::Apple's command that symbolicates a whole crash report. (taught in [[29 Reading a crash from the field]])

~/.konan::Kotlin/Native's folder in your home directory: its downloaded tools and the compilation cache. (taught in [[30 Where the build minutes go]])

compilation cache::Already compiled libraries kept by Kotlin/Native so later debug builds skip that work. (taught in [[30 Where the build minutes go]])

configuration cache::Gradle's stored result of reading the build files, so later builds skip that step. (taught in [[30 Where the build minutes go]])

enableReleaseBinaryCache::The experimental option that lets release builds use the compilation cache. (taught in [[30 Where the build minutes go]])

Gradle build cache::Gradle's store of task outputs, reused when a task's inputs haven't changed. (taught in [[30 Where the build minutes go]])

link-time optimization::Optimizing all modules together during the link stage, as release builds do. (taught in [[30 Where the build minutes go]])

org.gradle.caching=true::The gradle.properties line that turns on Gradle's build cache. (taught in [[30 Where the build minutes go]])

org.gradle.configuration-cache=true::The gradle.properties line that turns on Gradle's configuration cache. (taught in [[30 Where the build minutes go]])

:db::An example module used inside the framework but not exported. (taught in [[31 Where the megabytes come from]])

smallBinary::A binary option that makes LLVM optimize release binaries for size. (taught in [[31 Where the megabytes come from]])

transitiveExport::Exports every dependency of each exported module too; not recommended. (taught in [[31 Where the megabytes come from]])
