---
course: "Kotlin Multiplatform, from the compiler up"
puzzle: 13
source: https://pachulski.dev/course/kmp/13-compose-in-one-puzzle
tags: [course/kmp]
---

# Compose in one puzzle

> [!summary] The idea to keep
> In Compose, a screen is a Kotlin function marked @Composable that describes the UI for the current data, instead of creating and updating view objects. When that data, its state, changes, Compose calls the affected functions again: recomposition. remember keeps a value across those calls. A compiler plugin rewrites every @Composable function so the runtime can track what each one showed and redo only what changed.

**Builds on:** [[00 One Kotlin function, two ways to run it]]

## The problem

With XML layouts, you build a view once, then change it by hand: `textView.text = name`. Compose has no such step: you write a function, and the screen follows your data. How does the screen update, if nothing tells it to?

## See it

![Compose in one puzzle](https://pachulski.dev/course/kmp/gifs/compose.gif)

Step through it: https://pachulski.dev/course/kmp/13-compose-in-one-puzzle

## The building block

A **composable** is a Kotlin function marked `@Composable` that takes data and describes the UI for it:

```kotlin
@Composable
fun Greeting(name: String) {
    Text("Hello, $name")
}
```

This Greeting returns Unit and creates no view objects you keep. Other composable functions can return values. It describes what the screen should look like for this `name`.

When the data changes, Compose calls the function again with the new value: **recomposition**. It's smart about it: only the functions whose inputs might have changed run again; the rest are skipped. Data that should trigger it is **state**, for example `var count by remember { mutableStateOf(0) }`; **remember** keeps that value across recompositions, so it isn't reset each time the function runs.

How can the runtime know which functions showed what? That's the **Compose compiler plugin**, a part of the Kotlin compiler from puzzle 0. It rewrites every `@Composable` function, adding hidden bookkeeping so Compose can track what each call showed and skip what didn't change.

## The analogy

A weather board that a printer reprints whenever the forecast changes, instead of a person climbing up to swap single letters. You only ever write what the board should say; the printer handles the rest, and only reprints the panels that changed.

## Check yourself

#flashcards/kmp

The `name` passed to `Greeting` changes. What makes the text update?::Compose calls `Greeting` again with the new name: recomposition. Data changes, functions run again.

Why does a counter need `remember`?::So its value survives each recomposition instead of resetting. Kept across calls.

What's the difference between a composable and the Compose compiler plugin?::A composable describes UI for its data, while the plugin rewrites composables so the runtime can track them. What you write vs what the compiler adds.

## Sources

- [Android Developers: Thinking in Compose](https://developer.android.com/develop/ui/compose/mental-model) ("you can build your user interface by defining a set of composable functions that take in data and emit UI elements"; "This annotation informs the Compose compiler that this function is intended to convert data into UI"; "Recomposition is the process of calling your composable functions again when inputs change. When Compose recomposes based on new inputs, it calls only the functions or lambdas that might have changed, and skips the rest.")
