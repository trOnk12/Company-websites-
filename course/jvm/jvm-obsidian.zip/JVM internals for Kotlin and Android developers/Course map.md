---
source: https://pachulski.dev/course/jvm/
tags: [course/jvm]
---

# JVM internals for Kotlin and Android developers

Trace a tiny bookmark program from compiled instructions to method frames, shared objects and reachability.

From [pachulski.dev](https://pachulski.dev/course/jvm/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## From source to a live object

Follow the same counter through four experiments.

- [[00 Which program did you actually run]]: Follow a source edit into the file the runtime reads.
- [[01 What does a method receive]]: Track one number across a call and back.
- [[02 Why do both names read eight]]: Predict which changes survive a method call.
- [[03 When can a counter be reclaimed]]: Trace which object the remaining variable can reach.

## Changing shared state

A change applied only when the current value matches the expected value.

- [[04 How can two increments produce eight]]: Follow two callers that both read seven before either saves.

## Reading bytecode

Read javap output line by line: the operand stack, the constant pool, the five calls, and what Kotlin compiles to.

- [[05 Where does the arithmetic happen]]: Puzzle 1 traced one addition. Now a method with two inputs, a multiplication and a local variable. Read every instruction and predict what the operand stack holds after each one.
- [[06 What does 7 point to]]: Puzzle 5's instructions carried small numbers inside themselves. Now score reads a field and multiplies by 100000. Follow the number after the instruction to the table where names and big numbers live.
- [[07 Which method does a call run]]: Puzzles 5 and 6 read arithmetic and fields. Now the instructions that call methods. There are five, and the compiler picks one for every call by asking a few questions about it.
- [[08 What did Kotlin write for you]]: You can now read stack instructions, the constant pool and the five calls. Point javap at a small Kotlin class and find the methods and classes you never wrote, and the hidden calls behind a property and a default argument.
- [[09 Where did my lambda go]]: Puzzle 7 met invokedynamic and its bootstrap method. Follow one Kotlin lambda passed to two functions, one plain and one inline, and compare what each leaves in the bytecode.
- [[10 How does a call find the override]]: Puzzle 7 said invokevirtual picks the method from the receiver's class. See how the JVM you run does that in one lookup, and why Kotlin's final-by-default classes change less about speed than you might expect.

## Loading and linking code

When a class arrives, who loads it, why two loaders mean two classes, and where class metadata lives.

- [[11 When does a class arrive]]: Module 2 read the bytecode inside a class file. Now watch when the JVM actually reads that file, checks it, and runs its static code, using a log of one tiny program.
- [[12 Why is it zero]]: Puzzle 11 showed that preparation fills static fields with defaults and initialization runs the static code once. Here is what goes wrong when that code reads a field before the line that sets it, or throws.
- [[13 Why can't Greeter be cast to Greeter]]: Puzzle 11 said loading finds a class's bytes and creates the class. Meet the objects that do the finding, the order they ask each other in, and why the same class file loaded twice gives two different classes.
- [[14 Not found, or no longer there]]: Puzzles 11 and 13 showed that a class is loaded at its first use, by a loader searching the class path. Run the same small app three ways with a class missing, and learn what each error says about the cause.
- [[15 Where do classes live, and how do they leak]]: Puzzle 13 created a new loader per plugin, and puzzle 3 showed that unreachable objects can be reclaimed. Put the two together and find out where a loaded class is stored, when it can be thrown away, and how one kept object stops that.

## Practice chapters

- [[Practice chapter 1|Reasoning across threads and requests]]
- [[Practice chapter 2|Loading code and diagnosing runtime limits]]
- [[Practice chapter 3|Diagnose a slow Java service from a thread dump to a recording]]

[[Final project]]


[[Glossary]]
