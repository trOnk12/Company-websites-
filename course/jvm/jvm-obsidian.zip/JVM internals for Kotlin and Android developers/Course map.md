---
source: https://pachulski.dev/course/jvm/
tags: [course/jvm]
---

# JVM internals for Kotlin and Android developers

Trace a tiny bookmark program from compiled instructions to method frames, shared objects and reachability.

From [pachulski.dev](https://pachulski.dev/course/jvm/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## From source to a live object

Follow the same counter through four experiments.

- [[00 Which program did you actually run]]: Follow a source edit into the file the runtime reads.
- [[01 What does a method receive]]: Track one number across a call and back.
- [[02 Why do both names read eight]]: Predict which changes survive a method call.
- [[03 When can a counter be reclaimed]]: Trace which object the remaining variable can reach.

## Changing shared state

A change applied only when the current value matches the expected value.

- [[04 How can two increments produce eight]]: Follow two callers that both read seven before either saves.

## Practice chapters

- [[Practice chapter 1|Reasoning across threads and requests]]
- [[Practice chapter 2|Loading code and diagnosing runtime limits]]

[[Final project]]


[[Glossary]]
