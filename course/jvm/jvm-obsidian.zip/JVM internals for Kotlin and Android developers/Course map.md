---
source: https://pachulski.dev/course/jvm/
tags: [course/jvm]
---

# JVM internals for Kotlin and Android developers

Trace a tiny bookmark program from compiled instructions to method frames, shared objects and reachability.

From [pachulski.dev](https://pachulski.dev/course/jvm/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## From source to a live object

Follow the same counter through four experiments.

- [[00 Which program did you actually run]]: Follow a source edit into the file the runtime reads, and see why an edit alone changes nothing that runs.
- [[01 What does a method receive]]: Track the number seven across the call to increment and back, instruction by instruction.
- [[02 Why do both names read eight]]: Predict which changes made inside a method survive the call, when the argument is an object rather than a number.
- [[03 When can a counter be reclaimed]]: Clear one of the two names from puzzle 2 and trace which objects the program can still reach, including two objects that only point at each other.

## Changing shared state

A change applied only when the current value matches the expected value.

- [[04 How can two increments produce eight]]: Follow two callers that both read seven before either saves, and see a write that checks the expected value first.

## Reading bytecode

Read javap output line by line: the operand stack, the constant pool, the five calls, and what Kotlin compiles to.

- [[05 Where does the arithmetic happen]]: Puzzle 1 traced one addition. Now a method with two inputs, a multiplication and a local variable. Read every instruction and predict what the operand stack holds after each one.
- [[06 What does 7 point to]]: Puzzle 5's instructions carried small numbers inside themselves. Now score reads a field and multiplies by 100000. Follow the number after the instruction to the table where names and big numbers live.
- [[07 Which method does a call run]]: Puzzles 5 and 6 read arithmetic and fields. Now the instructions that call methods. There are five, and the compiler picks one for every call by asking a few questions about it.
- [[08 What did Kotlin write for you]]: You can now read stack instructions, the constant pool and the five calls. Point javap at a small Kotlin class and find the methods and classes you never wrote, and the hidden calls behind a property and a default argument.
- [[09 Where did my lambda go]]: Puzzle 7 met invokedynamic and its bootstrap method. Follow one Kotlin lambda passed to two functions, one plain and one inline, and compare what each leaves in the bytecode.
- [[10 How does a call find the override]]: Puzzle 7 said invokevirtual picks the method from the receiver's class. See how the JVM you run does that in one lookup, and what marking a method final changes in it.

## Loading and linking code

When a class arrives, who loads it, why two loaders mean two classes, and where class metadata lives.

- [[11 When does a class arrive]]: Module 2 read the bytecode inside a class file. Now watch when the JVM actually reads that file, checks it, and runs its static code, using a log of one tiny program.
- [[12 Why is it zero]]: Puzzle 11 showed that preparation fills static fields with defaults and initialization runs the static code once. Here is what goes wrong when that code reads a field before the line that sets it.
- [[13 Why does the second try say something different]]: Puzzle 12 ran a class's static code top to bottom. Now one line of that code throws. Follow two attempts to use the class and see why the second error hides the first one's cause.
- [[14 Why can't Greeter be cast to Greeter]]: Puzzle 11 said loading finds a class's bytes and creates the class. Meet the objects that do the finding, the order they ask each other in, and why the same class file loaded twice gives two different classes.
- [[15 Not found, or no longer there]]: Puzzles 11 and 14 showed that a class is loaded at its first use, by a loader searching the class path. Run the same small app two ways with a class missing, and learn what each error says about who asked and why nothing was found.
- [[16 Can the JVM check before main runs]]: Puzzle 15's missing class was found only at its first use, an hour into the run. Put the same App and Helper into named groups that declare what they need, and see the JVM refuse to start instead.
- [[17 Where do classes live, and how do they leak]]: Puzzle 14 created a new loader per plugin, and puzzle 3 showed that unreachable objects can be reclaimed. Put the two together and find out where a loaded class is stored, when it can be thrown away, and how one kept object stops that.
- [[18 What does Android do with all this]]: Modules 2 and 3 followed class files into a JVM. An Android phone has no JVM. Follow the same Kotlin to a phone and see which ideas carry over unchanged and which ones Android replaces.

## Practice chapters

- [[Practice chapter 1|Reasoning across threads and requests]]
- [[Practice chapter 2|Loading code and diagnosing runtime limits]]
- [[Practice chapter 3|Diagnose a slow Java service from a thread dump to a recording]]

[[Final project]]


[[Glossary]]
