# Reasoning across threads and requests

## When can another thread see initialized state?

A happens-before relationship guarantees visibility and ordering of the relevant actions across threads. Task submission through an Executor creates such a boundary for actions performed before submission. Future.get also establishes a boundary for the completed computation. These guarantees do not automatically cover changes made by the submitting thread after handing off the task.

### Worked example

A caller fills a payload with value 7, submits a task that reads it, and leaves the payload alone. The task can rely on seeing that initialization. If the caller instead mutates the same value to 9 immediately after submission, the earlier handoff alone does not order the mutation against the read.

### Try it

How would you guarantee the worker always processes the value at submission time?

### Compare your answer

Copy the needed value into an immutable task input before submission and avoid sharing mutable nested state. Waiting for the result can establish visibility back to the caller, but does not retroactively freeze an object passed to the task.

[Source · Java 21 · Memory consistency properties](https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/package-summary.html)

## Why is a thread pool full while CPU use stays low?

A pool has workers that execute tasks and a queue for tasks waiting to start. A worker waiting for another resource still occupies its slot. In ThreadPoolExecutor, an unbounded work queue can make the maximum pool size ineffective after the core workers are active. Queue policy is part of the service's latency contract.

### Worked example

Four fixed workers wait for database connections. Twelve tasks are queued. CPU use can be low while no queued task starts. Capture thread stacks during the wait and compare connection checkout counts, queue depth and oldest task age. Increasing workers could merely move more waiting tasks to the connection pool.

### Try it

With four active workers and a bounded queue of eight already full, a new task arrives. Which caller-visible result should you expect?

### Compare your answer

Read the configured rejection policy. AbortPolicy throws RejectedExecutionException, while CallerRunsPolicy may execute the task on the submitting thread when the executor is running. Account for how either behavior changes response time, and test overload after the dependency recovers.

[Source · Java 21 · ThreadPoolExecutor](https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/ThreadPoolExecutor.html)

## Why does one request see the previous request's context?

A ThreadLocal associates a value with the current thread. A pool reuses worker threads across requests. The lifetime of the worker can exceed the lifetime of the user or trace identifier stored on it. A missing cleanup on an exceptional exit can leave stale state for subsequent work.

### Worked example

Worker A handles request 41 and sets its trace label to blue. Its handler throws before cleanup. Request 42 later runs on the same worker and reads the label before setting its own. Its logs can incorrectly say blue. Put the installation and removal around the entire unit of work with a finally block. If code supports nested scopes, restore the previous context on exit.

### Try it

Would a ThreadLocal automatically follow a request that resumes on another worker?

### Compare your answer

Ordinary ThreadLocal storage is per thread. Pass the request context explicitly or use a framework propagation mechanism with a defined lifetime. Test both an exceptional exit and a handoff between two named workers.

[Source · Java 21 · ThreadLocal](https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/lang/ThreadLocal.html)

[[Practice chapter 2|Loading code and diagnosing runtime limits]]

[[Course map]]