# Loading code and diagnosing runtime limits

## When are two classes with the same name different types?

A class file describes a type by binary name. In a running JVM, class identity also includes its defining class loader. Loading obtains a class definition, linking checks it and prepares it for use, and initialization executes the required class initialization code. An operation that loads a class does not necessarily initialize it.

### Worked example

A host application and a plugin each define their own copy of api.Event. The plugin can print the same class name the host expects and still fail the host cast. Log the defining loader of the interface expected by the host and the defining loader of the interface implemented by the plugin.

### Try it

Both plugins have their own private implementation classes. How can the host accept both through a common interface?

### Compare your answer

Arrange for both to resolve the shared API through the same defining loader, while retaining private implementations in the plugin loaders. Prove assignability across the actual plugin boundary. Identical source code or class-file checksums alone do not establish runtime identity.

[Source · Java Virtual Machine Specification · Loading, linking and initialization](https://docs.oracle.com/javase/specs/jvms/se21/html/jvms-5.html)

## What can a rising heap graph prove?

G1 manages the Java heap as regions and collects selected regions, evacuating live objects when appropriate. Allocating rapidly and retaining a growing set of objects cause different problems. Compare comparable workload phases, collection events and the post-collection live-data trend before diagnosing a leak.

### Worked example

During three similar ten-minute intervals, use grows to 700 MiB and falls to 210, 212 and 211 MiB after comparable collections. The peaks alone are weak evidence of unbounded retention. If comparable low points instead rise from 210 to 340 to 475 MiB, inspect reference paths, cache policy and the workload that produced the objects.

### Try it

The JVM process grows while the measured Java heap remains roughly flat. Would raising the heap limit be your first experiment?

### Compare your answer

Measure other contributors such as direct buffers, thread stacks and native allocations. Record process memory, heap and collection logs together. Increasing the maximum heap without evidence can leave less headroom for other memory within the container.

[Source · Java 21 · Garbage-first collection](https://docs.oracle.com/en/java/javase/21/gctuning/garbage-first-g1-garbage-collector1.html)

## Which bottleneck do virtual threads remove?

Virtual threads allow a large number of tasks to wait without requiring one permanently occupied platform thread per task. A database connection, CPU core and remote-service quota remain finite resources. Give each constrained dependency an explicit admission policy.

### Worked example

Five hundred concurrent requests use virtual threads, but only ten database connections exist. If each checkout occupies a connection for 50 ms, the idealized ceiling of that pool is about 200 operations per second. This estimate assumes continuous use, one checkout per operation and no other limit. Adding virtual threads cannot multiply the ten connections.

### Try it

How would you test whether the connection pool or the CPU sets the observed limit?

### Compare your answer

Sweep concurrency while recording throughput, checkout wait, connection hold time, CPU use and tail latency. Change one resource limit per run. A rising checkout wait with ten busy connections is direct evidence to investigate database demand before increasing concurrency.

[Source · JDK 21 · Virtual threads](https://docs.oracle.com/en/java/javase/21/core/virtual-threads.html)

[[Practice chapter 3|Diagnose a slow Java service from a thread dump to a recording]]

[[Course map]]