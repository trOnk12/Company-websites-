---
course: "JVM internals for Kotlin and Android developers"
puzzle: 3
source: https://pachulski.dev/course/jvm/03-reachability
tags: [course/jvm]
---

# When can a counter be reclaimed?

> [!summary] The idea to keep
> Losing one reference leaves the object reachable while another live reference still leads to it.

**Builds on:** [[02 Why do both names read eight]]

## The problem

The caller clears the second name and then reads the first. Did the object disappear when one name was cleared?

## See it

![When can a counter be reclaimed?](https://pachulski.dev/course/jvm/gifs/reachability.gif)

Step through it: https://pachulski.dev/course/jvm/03-reachability

## The building block

Draw locals first and objects second. After edit returns, first and second still point to the original counter. Clearing second removes one arrow. The subsequent read through first still reaches eight. The temporary counter created inside edit has no surviving reference in this example. The runtime may reclaim its storage. The printed values cannot establish when collection ran, or whether an optimizing runtime materialized that temporary allocation at all. This distinction matters when investigating a long-lived cache that still points to old objects.

## Try it

Complete experiment 4 in the [local JVM lab](https://github.com/trOnk12/Company-websites-/tree/main/labs/jvm). Record your prediction before running the program.

## Check yourself

#flashcards/jvm

What does the last printed eight demonstrate?::The original counter was still reachable. Losing one reference leaves the object reachable while another live reference still leads to it.

## Sources

- [Oracle Java reference](https://docs.oracle.com/javase/specs/jvms/se21/html/jvms-2.html)
