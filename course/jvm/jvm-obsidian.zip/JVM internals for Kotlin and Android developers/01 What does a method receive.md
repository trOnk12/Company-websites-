---
course: "JVM internals for Kotlin and Android developers"
puzzle: 1
source: https://pachulski.dev/course/jvm/01-frame
tags: [course/jvm]
---

# What does a method receive?

> [!summary] The idea to keep
> Each method invocation has its own frame with locals and an operand stack.

**Builds on:** [[00 Which program did you actually run]]

## The problem

Look at the increment instructions in the class file from the previous puzzle. The caller holds seven. A helper adds one and returns eight. Where did the seven go while the helper ran?

## See it

![What does a method receive?](https://pachulski.dev/course/jvm/gifs/frame.gif)

Step through it: https://pachulski.dev/course/jvm/01-frame

## The building block

A **stack frame** belongs to one method call. It holds local variables and an operand stack for intermediate values. Calling increment copies the integer argument into its local slot. Inspect increment with javap. The load instruction pushes seven. The next instruction pushes one. Addition consumes both values and pushes eight. The integer return sends eight to the caller and the helper frame is discarded. The original local in the caller still holds seven.

## Try it

Complete experiment 2 in the [local JVM lab](https://github.com/trOnk12/Company-websites-/tree/main/labs/jvm). Record your prediction before running the program.

## Check yourself

#flashcards/jvm

After the addition and before the return, what is on the helper stack?::One value, eight. Each method invocation has its own frame with locals and an operand stack.

## Sources

- [Oracle Java reference](https://docs.oracle.com/en/java/javase/21/docs/specs/man/javap.html)
