# Glossary: JVM internals for Kotlin and Android developers

Every word the course teaches, in the order it does. #flashcards/jvm/words

class file::A file describing a compiled type and the instructions for its methods. (taught in [[00 Which program did you actually run]])

stack frame::The local variables and operand stack of one method invocation. (taught in [[01 What does a method receive]])

reference::A value through which code can reach an object. (taught in [[02 Why do both names read eight]])

conditional write::A change applied only when the current value matches the expected value. (taught in [[04 How can two increments produce eight]])
