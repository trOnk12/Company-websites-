# Glossary: JVM internals for Kotlin and Android developers

Every word the course teaches, in the order it does. #flashcards/jvm/words

class file::A file describing a compiled type and the instructions for its methods. (taught in [[00 Which program did you actually run]])

iadd::Remove two integers from the operand stack and push their sum. (taught in [[00 Which program did you actually run]])

iconst_1::Push the integer constant one onto the operand stack. (taught in [[00 Which program did you actually run]])

iconst_2::Push the integer constant two onto the operand stack. (taught in [[00 Which program did you actually run]])

iload_0::Copy the integer in local slot zero onto the operand stack. (taught in [[00 Which program did you actually run]])

ireturn::Hand the integer on top of the operand stack to the caller and finish the call. (taught in [[00 Which program did you actually run]])

operand stack::The pile of values a frame's instructions take their inputs from and put their results on. (taught in [[01 What does a method receive]])

stack frame::The local variables and operand stack of one method invocation. (taught in [[01 What does a method receive]])

astore::Remove the reference on top of the stack and write it into a local slot. (taught in [[02 Why do both names read eight]])

putfield::Write the value on top of the stack into a field of the object whose reference is below it. (taught in [[02 Why do both names read eight]])

reference::A value through which code can reach an object. (taught in [[02 Why do both names read eight]])

garbage collector::The part of the runtime that automatically reclaims storage for objects the program can no longer reach. (taught in [[03 When can a counter be reclaimed]])

NullPointerException::Thrown when code reads a field or calls a method through a reference that is null. (taught in [[03 When can a counter be reclaimed]])

root::A starting point from which the runtime traces live references. (taught in [[03 When can a counter be reclaimed]])

AtomicInteger::A JDK class holding an int that offers indivisible operations such as compareAndSet. (taught in [[04 How can two increments produce eight]])

conditional write::A change applied only when the current value matches the expected value. (taught in [[04 How can two increments produce eight]])

SharedCounter::The lab program that replays two threads updating one AtomicInteger. (taught in [[04 How can two increments produce eight]])

bipush::Push a small integer carried in the instruction itself (one extra byte). (taught in [[05 Where does the arithmetic happen]])

byte offset::The number javap prints before an instruction: where it starts, counted in bytes from the start of the method. (taught in [[05 Where does the arithmetic happen]])

bytecode::The instructions inside a class file; each one starts with a one-byte opcode. (taught in [[05 Where does the arithmetic happen]])

GitHub::The website hosting Kotlin compiler releases. (taught in [[05 Where does the arithmetic happen]])

iload::Copy the integer in a local slot onto the operand stack. (taught in [[05 Where does the arithmetic happen]])

imul::Remove two integers from the operand stack and push their product. (taught in [[05 Where does the arithmetic happen]])

istore::Remove the integer on top of the operand stack and write it into a local slot. (taught in [[05 Where does the arithmetic happen]])

isub::Remove two integers and push the deeper one minus the top one. (taught in [[05 Where does the arithmetic happen]])

opcode::The single byte at the start of an instruction that says which operation to perform. (taught in [[05 Where does the arithmetic happen]])

ScoreKt::The class kotlinc creates for the top-level functions of Score.kt. (taught in [[05 Where does the arithmetic happen]])

SDKMAN::A command-line installer for JDKs and kotlinc on macOS and Linux. (taught in [[05 Where does the arithmetic happen]])

sipush::Push an integer carried in the instruction itself (two extra bytes). (taught in [[05 Where does the arithmetic happen]])

type letter::The first letter of many instruction names, giving the type it works on: i for int, l for long, a for a reference. (taught in [[05 Where does the arithmetic happen]])

constant pool::The numbered table near the start of a class file holding the names, texts and numbers its code refers to. (taught in [[06 What does 7 point to]])

descriptor::A type written in the class file short code: I for int, J for long, L plus a class name for a reference; for a method, (parameters) then the return type. (taught in [[06 What does 7 point to]])

Fieldref::A constant-pool entry describing a field: its class plus its name and descriptor. (taught in [[06 What does 7 point to]])

getstatic::Read a static field, named through the constant pool, and push its value. (taught in [[06 What does 7 point to]])

ldc::Push a constant stored in the constant pool. (taught in [[06 What does 7 point to]])

NameAndType::A constant-pool entry pairing a name with a descriptor. (taught in [[06 What does 7 point to]])

symbolic reference::A reference to a class, field or method by its name and descriptor, which the JVM looks up while the program runs. (taught in [[06 What does 7 point to]])

Utf8::A constant-pool entry holding a piece of text. (taught in [[06 What does 7 point to]])

<init>::The name a constructor has inside a class file. (taught in [[07 Which method does a call run]])

aload::Copy the reference in a local slot onto the operand stack. (taught in [[07 Which method does a call run]])

bootstrap method::A method an invokedynamic instruction names; the JVM runs it once, the first time, to decide what the call does. (taught in [[07 Which method does a call run]])

DefaultImpls::The class kotlinc emits beside an interface, forwarding to its default methods. (taught in [[07 Which method does a call run]])

getfield::Read a field of the object whose reference is on top of the stack. (taught in [[07 Which method does a call run]])

InterfaceMethod::How javap labels a constant-pool reference to a method of an interface. (taught in [[07 Which method does a call run]])

invokedynamic::A call whose target a bootstrap method decides the first time it runs. (taught in [[07 Which method does a call run]])

invokeinterface::Call a method through an interface type, choosing the version in the receiver class. (taught in [[07 Which method does a call run]])

invokespecial::Call exactly the named instance method: a constructor, a super call, a Kotlin private method. (taught in [[07 Which method does a call run]])

invokestatic::Call a static method: exactly the one the constant pool names. (taught in [[07 Which method does a call run]])

invokevirtual::Call a method through a class type, choosing the version in the receiver class. (taught in [[07 Which method does a call run]])

istore_1::Store the top integer in local slot 1. (taught in [[07 Which method does a call run]])

JEP::JDK Enhancement Proposal: the document that describes a change to the JDK. (taught in [[07 Which method does a call run]])

receiver::The object a method is called on; inside the method it arrives in local slot 0. (taught in [[07 Which method does a call run]])

@JvmName::Kotlin annotation: choose the JVM name of a generated method. (taught in [[08 What did Kotlin write for you]])

@JvmOverloads::Kotlin annotation: generate one overload per default argument for Java callers. (taught in [[08 What did Kotlin write for you]])

@JvmStatic::Kotlin annotation: also generate a real static method for a companion function. (taught in [[08 What did Kotlin write for you]])

Bookmark$Companion::The class kotlinc generates for the companion object of Bookmark. (taught in [[08 What did Kotlin write for you]])

BookmarkKt::The class holding the top-level functions of Bookmark.kt. (taught in [[08 What did Kotlin write for you]])

checkNotNullParameter::The Kotlin runtime check that throws when a non-null parameter receives null. (taught in [[08 What did Kotlin write for you]])

getIsOpen::The getter name Kotlin does not generate for isOpen. (taught in [[08 What did Kotlin write for you]])

getter::A generated method that returns a property field, such as getVisits(). (taught in [[08 What did Kotlin write for you]])

getUrl::The getter kotlinc generates for val url. (taught in [[08 What did Kotlin write for you]])

getVisits::The getter for var visits. (taught in [[08 What did Kotlin write for you]])

iand::Remove two integers and push the bits set in both. (taught in [[08 What did Kotlin write for you]])

iconst_0::Push the integer constant zero. (taught in [[08 What did Kotlin write for you]])

ifeq::Jump to the given offset if the integer on top is zero. (taught in [[08 What did Kotlin write for you]])

isOpen::A property name starting with is, whose getter keeps the name. (taught in [[08 What did Kotlin write for you]])

MainActivity::An example class name in an Android app. (taught in [[08 What did Kotlin write for you]])

mask::The extra int a $default method receives: bit n is set when argument n was left out. (taught in [[08 What did Kotlin write for you]])

setter::A generated method that stores its argument in a property field, such as setVisits(int). (taught in [[08 What did Kotlin write for you]])

setVisits::The setter for var visits. (taught in [[08 What did Kotlin write for you]])

visit$default::The method kotlinc generates to fill in default arguments of visit. (taught in [[08 What did Kotlin write for you]])

call site::One place in the code where a call is written, such as one invokedynamic instruction. (taught in [[09 Where did my lambda go]])

function object::An object with one invoke() method that runs a lambda, carrying the values the lambda captured. (taught in [[09 Where did my lambda go]])

Function0::Kotlin interface for a function with no parameters; its method is invoke(). (taught in [[09 Where did my lambda go]])

hidden class::A class created while the program runs, with no class file, that no other bytecode can name. (taught in [[09 Where did my lambda go]])

inline function::A Kotlin function whose body, and the lambdas passed to it, kotlinc copies into each caller. (taught in [[09 Where did my lambda go]])

istore_0::Store the top integer in local slot 0. (taught in [[09 Where did my lambda go]])

JvmSerializableLambda::Kotlin annotation: compile this one lambda to its own class, the pre-2.0 way. (taught in [[09 Where did my lambda go]])

LambdaMetafactory::The JDK class whose bootstrap method creates lambda classes while the program runs. (taught in [[09 Where did my lambda go]])

LambdasKt::The class holding the top-level functions of Lambdas.kt. (taught in [[09 Where did my lambda go]])

main$lambda$0::The private static method holding the lambda body. (taught in [[09 Where did my lambda go]])

HotSpot::The JVM inside OpenJDK, the one java runs in this course. (taught in [[10 How does a call find the override]])

method table::HotSpot per-class list with one entry per overridable method, at the same position as in the parent class. (taught in [[10 How does a call find the override]])

OpenJDK::The open-source project that builds the JDK, including HotSpot. (taught in [[10 How does a call find the override]])

class loading::Finding a class file bytes and creating the class in memory, the first time code needs the class. (taught in [[11 When does a class arrive]])

Class.forName::Load a class by a name given as a string. (taught in [[11 When does a class arrive]])

initialization::Running a class static code, once, at its first real use. (taught in [[11 When does a class arrive]])

linking::Verification, preparation and resolution: making a loaded class ready to run. (taught in [[11 When does a class arrive]])

preparation::The linking step that creates a class static fields with default values (0, null). (taught in [[11 When does a class arrive]])

resolution::Turning a symbolic reference into the real class, field or method it names. (taught in [[11 When does a class arrive]])

verification::The linking step that checks a class bytecode is safe to run before any of it runs. (taught in [[11 When does a class arrive]])

<clinit>::The class-file name of a class's static initializer. (taught in [[12 Why is it zero]])

jar::One zip file holding class files, which can be listed on a class path like a folder. (taught in [[12 Why is it zero]])

putstatic::Write the value on top of the stack into a static field. (taught in [[12 Why is it zero]])

static initializer::All of a class's static code, compiled into one method, <clinit>, that initialization runs once. (taught in [[12 Why is it zero]])

ExceptionInInitializerError::Thrown the first time a class's static initializer throws; its cause is the real error. (taught in [[13 Why does the second try say something different]])

NoClassDefFoundError::Thrown when running code needs a class that can't be used: gone since compilation, or failed to initialize. (taught in [[13 Why does the second try say something different]])

NumberFormatException::Thrown when text can't be read as a number. (taught in [[13 Why does the second try say something different]])

AppClassLoader::How the application (system) class loader prints itself. (taught in [[14 Why can't Greeter be cast to Greeter]])

checkcast::The instruction a cast in code compiles to: check the object is an instance of a class, or throw ClassCastException. (taught in [[14 Why can't Greeter be cast to Greeter]])

class loader::An object that finds a class's bytes by name and asks the JVM to create the class from them. (taught in [[14 Why can't Greeter be cast to Greeter]])

class path::The list of folders and jars, given with -cp, where the application class loader looks for classes. (taught in [[14 Why can't Greeter be cast to Greeter]])

ClassCastException::Thrown when an object is cast to a class it isn't an instance of. (taught in [[14 Why can't Greeter be cast to Greeter]])

ClassLoader::The JDK class every class loader except bootstrap is an instance of. (taught in [[14 Why can't Greeter be cast to Greeter]])

defining loader::The class loader that actually created a class; with the name, it identifies the class while the program runs. (taught in [[14 Why can't Greeter be cast to Greeter]])

LinkageError::Thrown when linking finds an inconsistency, such as two loaders disagreeing about a class. (taught in [[14 Why can't Greeter be cast to Greeter]])

parent delegation::The rule that a class loader asks its parent for a class before looking in its own places. (taught in [[14 Why can't Greeter be cast to Greeter]])

PlatformClassLoader::How the platform class loader prints itself. (taught in [[14 Why can't Greeter be cast to Greeter]])

SE::Java SE: the standard Java platform the JDK implements. (taught in [[14 Why can't Greeter be cast to Greeter]])

URLClassLoader::A JDK class loader that reads class files from the folders or jars you give it. (taught in [[14 Why can't Greeter be cast to Greeter]])

ClassNotFoundException::Thrown when code asks a loader for a class by a name in a string and no loader has it. (taught in [[15 Not found, or no longer there]])

NoSuchMethodError::Thrown when compiled code calls a method the loaded class doesn't have. (taught in [[15 Not found, or no longer there]])

FindException::Thrown at startup when a required module isn't on the module path. (taught in [[16 Can the JVM check before main runs]])

Java module::A named set of packages whose module-info file says which other modules it requires and which packages it exports. (taught in [[16 Can the JVM check before main runs]])

module path::The list of folders and jars holding Java modules, given with -p; required modules are checked before main runs. (taught in [[16 Can the JVM check before main runs]])

class unloading::Freeing a loader's classes together with the loader, once nothing reachable leads to them. (taught in [[17 Where do classes live, and how do they leak]])

CompressedClassSpaceSize::The HotSpot option that sets the size of the compressed class space. (taught in [[17 Where do classes live, and how do they leak]])

heap::The memory where objects live, managed by the garbage collector. (taught in [[17 Where do classes live, and how do they leak]])

MaxMetaspaceSize::The HotSpot option that sets an upper limit on metaspace. (taught in [[17 Where do classes live, and how do they leak]])

metaspace::Memory outside the heap where HotSpot keeps class metadata, in chunks owned by each class loader. (taught in [[17 Where do classes live, and how do they leak]])

OutOfMemoryError::Thrown when the JVM can't get memory it needs; its message names which kind, such as Metaspace. (taught in [[17 Where do classes live, and how do they leak]])

PermGen::The permanent generation: where class metadata lived on the heap before JDK 8. (taught in [[17 Where do classes live, and how do they leak]])

ThreadLocal::A JDK class that keeps one value per thread. (taught in [[17 Where do classes live, and how do they leak]])

d8::The Android build tool that converts class files into DEX. (taught in [[18 What does Android do with all this]])

desugaring::d8 rewriting Java features ART cannot run as written, such as invokedynamic lambdas, into ordinary code; lambdas are always rewritten into classes. (taught in [[18 What does Android do with all this]])

ExternalSynthetic::The separator R8 and d8 put in the names of classes they generate. (taught in [[18 What does Android do with all this]])

ExternalSyntheticLambda::The part of a d8-generated lambda class name after the containing class. (taught in [[18 What does Android do with all this]])

MyActivity::An example class name from Android's R8 documentation. (taught in [[18 What does Android do with all this]])

PathClassLoader::The class loader Android uses for apps. (taught in [[18 What does Android do with all this]])

register::In DEX, a numbered slot of the method's frame that an instruction names as an input or output. (taught in [[18 What does Android do with all this]])

string_ids::The DEX table listing every string a DEX file uses. (taught in [[18 What does Android do with all this]])

vAA::A register operand in Android's DEX instruction reference. (taught in [[18 What does Android do with all this]])

vBB::A register operand in Android's DEX instruction reference. (taught in [[18 What does Android do with all this]])

vCC::A register operand in Android's DEX instruction reference. (taught in [[18 What does Android do with all this]])

code cache::The memory where HotSpot keeps the machine code its compilers produce.

invocation counter::A number HotSpot keeps per method and increases on every call, to find the methods worth compiling.

nanoTime::System.nanoTime(): a clock reading in nanoseconds, for measuring how long something took.

template interpreter::HotSpot interpreter: for each opcode it jumps to a small piece of machine code, the template, that carries out that instruction.

Xint::The java option that turns the compilers off: every method is interpreted.

C1::HotSpot's quick compiler: compiles a method fast, with simple optimizations, and can add profiling code.

C2::HotSpot's optimizing compiler: compiles slowly but produces the fastest code, using the method profile.

method profile::What HotSpot records while a method runs: how often each branch went each way and which classes each call met.

MethodData::The object in which HotSpot keeps a method profile.

on-stack replacement::Switching a method that is still running, inside a long loop, from the interpreter to compiled code.

PrintCompilation::The HotSpot option that prints a line each time a method is compiled or its compiled code is retired.

tiered compilation::Moving a hot method through levels: interpreter, then C1 with profiling, then C2.

TieredStopAtLevel::The HotSpot option that sets the highest compilation level used.

CompileCommand::The HotSpot option that applies a command or option to chosen methods.

FreqInlineSize::C2 inlines a frequently called method only if its bytecode is at most this many bytes (325 on x86-64).

inline cache::A call site in compiled code that remembers the last receiver class and jumps straight to its method.

inlining::A compiler copying a called method's body into the caller's compiled code, so the call disappears.

MaxInlineSize::C2 inlines a rarely called method only if its bytecode is at most this many bytes (35).

megamorphic::A call site that has met too many receiver classes to inline them; it keeps the method-table lookup.

MixedKt::The class holding the top-level functions of Mixed.kt.

monomorphic::A call site that has met only one receiver class.

PrintInlining::The diagnostic HotSpot option that prints each inlining decision.

type profile::The part of a method profile that counts which receiver classes a call site met.

TypeProfile::How PrintInlining shows which receiver classes a call site met.

UnlockDiagnosticVMOptions::The HotSpot option that makes diagnostic options such as PrintInlining available.

DoEscapeAnalysis::The HotSpot option that turns escape analysis on (the default) or off.

escape analysis::C2's check of whether a new object can be reached outside the compiled method and its inlined calls.

EscapeKt::The class holding the top-level functions of Escape.kt.

getThreadAllocatedBytes::Returns how many bytes a thread has allocated on the heap so far.

scalar replacement::Replacing an object that doesn't escape by its fields, kept as local values: the object is never allocated.

ThreadMXBean::A JDK interface that reports per-thread numbers, such as bytes allocated.

BranchKt::The class holding the top-level functions of Branch.kt.

class hierarchy analysis::Checking the classes loaded so far to prove an open method has no override, so it can be called directly.

deoptimization::Discarding compiled code whose assumption no longer holds and continuing the method in the interpreter.

HotKt::The class holding the top-level functions of Hot.kt.

LogCompilation::The diagnostic HotSpot option that writes every compiler event to an XML log file.

uncommon trap::A spot in compiled code, for a case the profile never saw, that deoptimizes if that case happens.

Blackhole::The JMH object that consumes a value so the compiler cannot treat it as unused.

dead code elimination::A compiler removing code whose result is never used.

JMH::The Java Microbenchmark Harness: an OpenJDK tool that warms code up, keeps results alive and runs each benchmark in a fresh JVM.

warm-up::The start of a run, while methods are still interpreted or compiled at lower levels.

AOT cache::JDK 24's successor to the CDS archive: classes already loaded and linked, and from JDK 25 method profiles too.

AOTCache::JDK 24+ option that names the AOT cache to use.

AOTCacheOutput::JDK 25+ option: do a training run and write an AOT cache in one command.

ArchiveClassesAtExit::The option that writes the classes a run loaded into a CDS archive when it exits.

CDS archive::The file class data sharing maps into memory: classes already parsed, in the form HotSpot keeps them.

class data sharing::Loading classes from a prepared archive file instead of reading and parsing class files.

SharedArchiveFile::The option that names the CDS archive to use.

StartKt::The class holding the top-level functions of Start.kt.

training run::A run of the application whose only purpose is to record what a later cache should contain.
