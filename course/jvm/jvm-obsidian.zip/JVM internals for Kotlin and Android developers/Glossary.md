# Glossary: JVM internals for Kotlin and Android developers

Every word the course teaches, in the order it does. #flashcards/jvm/words

class file::A file describing a compiled type and the instructions for its methods. (taught in [[00 Which program did you actually run]])

iadd::Remove two integers from the operand stack and push their sum. (taught in [[01 What does a method receive]])

iconst_1::Push the integer constant one onto the operand stack. (taught in [[01 What does a method receive]])

iload_0::Copy the integer in local slot zero onto the operand stack. (taught in [[01 What does a method receive]])

ireturn::Hand the integer on top of the operand stack to the caller and finish the call. (taught in [[01 What does a method receive]])

stack frame::The local variables and operand stack of one method invocation. (taught in [[01 What does a method receive]])

reference::A value through which code can reach an object. (taught in [[02 Why do both names read eight]])

garbage collector::The part of the runtime that automatically reclaims storage for objects the program can no longer reach. (taught in [[03 When can a counter be reclaimed]])

root::A starting point from which the runtime traces live references. (taught in [[03 When can a counter be reclaimed]])

conditional write::A change applied only when the current value matches the expected value. (taught in [[04 How can two increments produce eight]])

bipush::Push a small integer carried in the instruction itself (one extra byte). (taught in [[05 Where does the arithmetic happen]])

byte offset::The number javap prints before an instruction: where it starts, counted in bytes from the start of the method. (taught in [[05 Where does the arithmetic happen]])

bytecode::The instructions inside a class file; each one starts with a one-byte opcode. (taught in [[05 Where does the arithmetic happen]])

iconst_2::Push the integer constant two onto the operand stack. (taught in [[05 Where does the arithmetic happen]])

iload::Copy the integer in a local slot onto the operand stack. (taught in [[05 Where does the arithmetic happen]])

imul::Remove two integers from the operand stack and push their product. (taught in [[05 Where does the arithmetic happen]])

istore::Remove the integer on top of the operand stack and write it into a local slot. (taught in [[05 Where does the arithmetic happen]])

isub::Remove two integers and push the deeper one minus the top one. (taught in [[05 Where does the arithmetic happen]])

opcode::The single byte at the start of an instruction that says which operation to perform. (taught in [[05 Where does the arithmetic happen]])

ScoreKt::The class kotlinc creates for the top-level functions of Score.kt. (taught in [[05 Where does the arithmetic happen]])

sipush::Push an integer carried in the instruction itself (two extra bytes). (taught in [[05 Where does the arithmetic happen]])

type letter::The first letter of many instruction names, giving the type it works on: i for int, l for long, a for a reference. (taught in [[05 Where does the arithmetic happen]])

constant pool::The numbered table at the start of a class file holding the names, texts and numbers its code refers to. (taught in [[06 What does 7 point to]])

descriptor::A type written in the class file short code: I for int, J for long, L plus a class name for a reference; for a method, (parameters) then the return type. (taught in [[06 What does 7 point to]])

Fieldref::A constant-pool entry describing a field: its class plus its name and descriptor. (taught in [[06 What does 7 point to]])

getstatic::Read a static field, named through the constant pool, and push its value. (taught in [[06 What does 7 point to]])

ldc::Push a constant stored in the constant pool. (taught in [[06 What does 7 point to]])

NameAndType::A constant-pool entry pairing a name with a descriptor. (taught in [[06 What does 7 point to]])

symbolic reference::A reference to a class, field or method by its name and descriptor, which the JVM looks up while the program runs. (taught in [[06 What does 7 point to]])

Utf8::A constant-pool entry holding a piece of text. (taught in [[06 What does 7 point to]])

<init>::The name a constructor has inside a class file. (taught in [[07 Which method does a call run]])

aload::Copy the reference in a local slot onto the operand stack. (taught in [[07 Which method does a call run]])

astore::Remove the reference on top of the stack and write it into a local slot. (taught in [[07 Which method does a call run]])

bootstrap method::A method an invokedynamic instruction names; the JVM runs it once, the first time, to decide what the call does. (taught in [[07 Which method does a call run]])

getfield::Read a field of the object whose reference is on top of the stack. (taught in [[07 Which method does a call run]])

invokedynamic::A call whose target a bootstrap method decides the first time it runs. (taught in [[07 Which method does a call run]])

invokeinterface::Call a method declared in an interface, choosing the version in the receiver class. (taught in [[07 Which method does a call run]])

invokespecial::Call exactly the named instance method: a constructor, a super call, a Kotlin private method. (taught in [[07 Which method does a call run]])

invokestatic::Call a static method: exactly the one the constant pool names. (taught in [[07 Which method does a call run]])

invokevirtual::Call a method declared in a class, choosing the version in the receiver class. (taught in [[07 Which method does a call run]])

istore_1::Store the top integer in local slot 1. (taught in [[07 Which method does a call run]])

receiver::The object a method is called on; inside the method it arrives in local slot 0. (taught in [[07 Which method does a call run]])

@JvmName::Kotlin annotation: choose the JVM name of a generated method. (taught in [[08 What did Kotlin write for you]])

@JvmOverloads::Kotlin annotation: generate one overload per default argument for Java callers. (taught in [[08 What did Kotlin write for you]])

@JvmStatic::Kotlin annotation: also generate a real static method for a companion function. (taught in [[08 What did Kotlin write for you]])

Bookmark$Companion::The class kotlinc generates for the companion object of Bookmark. (taught in [[08 What did Kotlin write for you]])

BookmarkKt::The class holding the top-level functions of Bookmark.kt. (taught in [[08 What did Kotlin write for you]])

checkNotNullParameter::The Kotlin runtime check that throws when a non-null parameter receives null. (taught in [[08 What did Kotlin write for you]])

getIsOpen::The getter name Kotlin does not generate for isOpen. (taught in [[08 What did Kotlin write for you]])

getter::A generated method that returns a property field, such as getVisits(). (taught in [[08 What did Kotlin write for you]])

getUrl::The getter kotlinc generates for val url. (taught in [[08 What did Kotlin write for you]])

getVisits::The getter for var visits. (taught in [[08 What did Kotlin write for you]])

iand::Remove two integers and push the bits set in both. (taught in [[08 What did Kotlin write for you]])

iconst_0::Push the integer constant zero. (taught in [[08 What did Kotlin write for you]])

ifeq::Jump to the given offset if the integer on top is zero. (taught in [[08 What did Kotlin write for you]])

isOpen::A property name starting with is, whose getter keeps the name. (taught in [[08 What did Kotlin write for you]])

mask::The extra int a $default method receives: bit n is set when argument n was left out. (taught in [[08 What did Kotlin write for you]])

setter::A generated method that stores its argument in a property field, such as setVisits(int). (taught in [[08 What did Kotlin write for you]])

setVisits::The setter for var visits. (taught in [[08 What did Kotlin write for you]])

visit$default::The method kotlinc generates to fill in default arguments of visit. (taught in [[08 What did Kotlin write for you]])

call site::One place in the code where a call is written, such as one invokedynamic instruction. (taught in [[09 Where did my lambda go]])

function object::An object with one invoke() method that runs a lambda, carrying the values the lambda captured. (taught in [[09 Where did my lambda go]])

Function0::Kotlin interface for a function with no parameters; its method is invoke(). (taught in [[09 Where did my lambda go]])

inline function::A Kotlin function whose body, and the lambdas passed to it, kotlinc copies into each caller. (taught in [[09 Where did my lambda go]])

istore_0::Store the top integer in local slot 0. (taught in [[09 Where did my lambda go]])

LambdaMetafactory::The JDK class whose bootstrap method creates lambda classes while the program runs. (taught in [[09 Where did my lambda go]])

LambdasKt::The class holding the top-level functions of Lambdas.kt. (taught in [[09 Where did my lambda go]])

main$lambda$0::The private static method holding the lambda body. (taught in [[09 Where did my lambda go]])

HotSpot::The JVM inside OpenJDK, the one java runs in this course. (taught in [[10 How does a call find the override]])

method table::HotSpot per-class list with one entry per overridable method, at the same position as in the parent class. (taught in [[10 How does a call find the override]])

OpenJDK::The open-source project that builds the JDK, including HotSpot. (taught in [[10 How does a call find the override]])

class loading::Finding a class file bytes and creating the class in memory, the first time code needs the class. (taught in [[11 When does a class arrive]])

initialization::Running a class static code, once, at its first real use. (taught in [[11 When does a class arrive]])

linking::Verification, preparation and resolution: making a loaded class ready to run. (taught in [[11 When does a class arrive]])

preparation::The linking step that creates a class static fields with default values (0, null). (taught in [[11 When does a class arrive]])

resolution::Turning a symbolic reference into the real class, field or method it names. (taught in [[11 When does a class arrive]])

verification::The linking step that checks a class bytecode is safe to run before any of it runs. (taught in [[11 When does a class arrive]])

<clinit>::The class-file name of a class's static initializer. (taught in [[12 Why is it zero]])

ExceptionInInitializerError::Thrown the first time a class's static initializer throws; its cause is the real error. (taught in [[12 Why is it zero]])

NoClassDefFoundError::Thrown when running code needs a class that can't be used: gone since compilation, or failed to initialize. (taught in [[12 Why is it zero]])

NumberFormatException::Thrown when text can't be read as a number. (taught in [[12 Why is it zero]])

putstatic::Write the value on top of the stack into a static field. (taught in [[12 Why is it zero]])

static initializer::All of a class's static code, compiled into one method, <clinit>, that initialization runs once. (taught in [[12 Why is it zero]])

AppClassLoader::How the application (system) class loader prints itself. (taught in [[13 Why can't Greeter be cast to Greeter]])

class loader::An object that finds a class's bytes by name and asks the JVM to create the class from them. (taught in [[13 Why can't Greeter be cast to Greeter]])

class path::The list of folders and jars, given with -cp, where the application class loader looks for classes. (taught in [[13 Why can't Greeter be cast to Greeter]])

ClassCastException::Thrown when an object is cast to a class it isn't an instance of. (taught in [[13 Why can't Greeter be cast to Greeter]])

ClassLoader::The JDK class every class loader except bootstrap is an instance of. (taught in [[13 Why can't Greeter be cast to Greeter]])

defining loader::The class loader that actually created a class; with the name, it identifies the class while the program runs. (taught in [[13 Why can't Greeter be cast to Greeter]])

LinkageError::Thrown when linking finds an inconsistency, such as two loaders disagreeing about a class. (taught in [[13 Why can't Greeter be cast to Greeter]])

parent delegation::The rule that a class loader asks its parent for a class before looking in its own places. (taught in [[13 Why can't Greeter be cast to Greeter]])

PlatformClassLoader::How the platform class loader prints itself. (taught in [[13 Why can't Greeter be cast to Greeter]])

URLClassLoader::A JDK class loader that reads class files from the folders or jars you give it. (taught in [[13 Why can't Greeter be cast to Greeter]])

Class.forName::Load a class by a name given as a string. (taught in [[14 Not found, or no longer there]])

ClassNotFoundException::Thrown when code asks a loader for a class by a name in a string and no loader has it. (taught in [[14 Not found, or no longer there]])

FindException::Thrown at startup when a required module isn't on the module path. (taught in [[14 Not found, or no longer there]])

module path::The list of folders and jars holding Java modules, given with -p; required modules are checked before main runs. (taught in [[14 Not found, or no longer there]])

NoSuchMethodError::Thrown when compiled code calls a method the loaded class doesn't have. (taught in [[14 Not found, or no longer there]])

class unloading::Freeing a loader's classes together with the loader, once nothing reachable leads to them. (taught in [[15 Where do classes live, and how do they leak]])

heap::The memory where objects live, managed by the garbage collector. (taught in [[15 Where do classes live, and how do they leak]])

MaxMetaspaceSize::The HotSpot option that sets an upper limit on metaspace. (taught in [[15 Where do classes live, and how do they leak]])

metaspace::Memory outside the heap where HotSpot keeps class metadata, in chunks owned by each class loader. (taught in [[15 Where do classes live, and how do they leak]])

OutOfMemoryError::Thrown when the JVM can't get memory it needs; its message names which kind, such as Metaspace. (taught in [[15 Where do classes live, and how do they leak]])

PermGen::The permanent generation: where class metadata lived on the heap before JDK 8. (taught in [[15 Where do classes live, and how do they leak]])

ThreadLocal::A JDK class that keeps one value per thread. (taught in [[15 Where do classes live, and how do they leak]])
