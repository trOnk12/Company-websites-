# Glossary: JVM internals for Kotlin and Android developers

Every word the course teaches, in the order it does. #flashcards/jvm/words

class file::A file describing a compiled type and the instructions for its methods. (taught in [[00 Which program did you actually run]])

iconst_1::Push the integer constant one onto the operand stack. (taught in [[01 What does a method receive]])

iload_0::Copy the integer in local slot zero onto the operand stack. (taught in [[01 What does a method receive]])

stack frame::The local variables and operand stack of one method invocation. (taught in [[01 What does a method receive]])

reference::A value through which code can reach an object. (taught in [[02 Why do both names read eight]])

garbage collector::The part of the runtime that automatically reclaims storage for objects the program can no longer reach. (taught in [[03 When can a counter be reclaimed]])

root::A starting point from which the runtime traces live references. (taught in [[03 When can a counter be reclaimed]])

conditional write::A change applied only when the current value matches the expected value. (taught in [[04 How can two increments produce eight]])
