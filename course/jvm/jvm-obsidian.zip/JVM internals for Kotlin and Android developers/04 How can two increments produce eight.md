---
course: "JVM internals for Kotlin and Android developers"
puzzle: 4
source: https://pachulski.dev/course/jvm/04-shared-counter
tags: [course/jvm]
---

# How can two increments produce eight?

> [!summary] The idea to keep
> Checking the expected value and changing it in one indivisible step detects the stale increment.

**Builds on:** [[02 Why do both names read eight]]

## The problem

Two callers hold references to the same counter. Both want to add one. Starting at seven, could both finish their writes and leave eight?

## See it

![How can two increments produce eight?](https://pachulski.dev/course/jvm/gifs/shared-counter.gif)

Step through it: https://pachulski.dev/course/jvm/04-shared-counter

## The building block

Write each caller's calculation on paper. A reads seven and calculates eight. B reads seven and also calculates eight. A writes eight. B writes eight. The second write used an old observation. Reading and writing a value safely as separate operations still leaves a gap between them.

A **conditional write** changes a value only if it still matches an expected value. Java's atomic integer offers a method that compares and writes as one indivisible step. A supplies seven as the expected value and eight as the replacement. It succeeds. B supplies the same pair and gets false because the counter already holds eight. B still owes one increment. The lab finishes it with a single operation that adds one to the current value.

| Event | A's observed value | B's observed value | Shared counter |
| --- | --- | --- | --- |
| Both read | 7 | 7 | 7 |
| A compares seven and replaces it with eight | 7 | 7 | 8 |
| B compares seven and proposes eight | 7 | 7 | 8 |
| B reads again, compares eight and proposes nine | 7 | 8 | 9 |

The final row assumes no other writer changes eight before B's comparison. If another writer does, B must calculate a fresh candidate again. Reporting success after B's first rejected attempt would quietly lose a requested increment. Java also supplies an atomic increment operation when adding one is the entire rule.

Now change the rule: both callers want to claim the final seat. A changes one to zero. B's original comparison fails. A fresh read for B returns zero. Retrying the business decision now means declining the reservation. Whether to try another write depends on what the operation promises. A single shared counter in one JVM only coordinates callers using that same object. Two servers with separate counters need a shared authority for the last seat.

## The analogy

Two clerks copy the same tally from a shared sheet. If each replaces the tally with their pencilled answer, one arrival disappears. If the clerk checks and changes the tally while holding the sheet, the second clerk can see the mismatch.

## Try it

[Run the browser experiment](https://pachulski.dev/labs/jvm-workbench/#04-shared-counter)

### Optional local lab

Run the following command from the [JVM source files](https://github.com/trOnk12/Company-websites-/tree/main/labs/jvm).

```sh
java SharedCounter.java
```

The statements replay one possible order so you can reproduce it on every run. Before running, write down both return values and the total after each write. Then move B's read just after A's first write in the separate-writes experiment. Predict the result and update the assertion for that experiment. Reset both snapshots to seven before the conditional experiment.

## Check yourself

#flashcards/jvm

B reads only after A writes eight. What does B calculate?::Nine. B reads eight and adds one.

Both expect seven. A succeeds. What does B's conditional write report?::False. The rejected write leaves eight in place.

A claims the final seat. B's comparison fails and a fresh read returns zero. What should B do?::Decline the reservation. Repeat the business decision using the fresh count.

## Sources

- [Java 21 atomic integer, compareAndSet](https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/atomic/AtomicInteger.html#compareAndSet(int,int)) — “False return indicates that the actual value was not equal to the expected value.”
