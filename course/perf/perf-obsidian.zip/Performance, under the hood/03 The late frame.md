---
course: "Performance, under the hood"
puzzle: 3
source: https://pachulski.dev/course/perf/03-the-late-frame
tags: [course/perf]
---

# The late frame

> [!summary] The idea to keep
> FrameTimeline gives every frame two slices: the Expected Timeline, the window the app was given, and the Actual Timeline, from Choreographer's callback to when the frame was posted and the GPU finished. Actual past the deadline is jank; FrameTimeline says whether the app or SurfaceFlinger was late. Then read the late frame's main thread and RenderThread: states, then flame chart.

**Builds on:** [[02 Slow isn't always busy]]

## The problem

Users say scrolling stutters, but only sometimes. In a trace there are hundreds of frames. Which ones were late, by how much, and was it your app's fault, or the display side's?

## See it

![The late frame](https://pachulski.dev/course/perf/gifs/frametl.gif)

Step through it: https://pachulski.dev/course/perf/03-the-late-frame

## The building block

In the Android course you saw a frame's work: the main thread measures, lays out and draws, the RenderThread hands it to the GPU, and the result must be ready for the next **vsync**, the display's signal that it's about to show a new frame. Since Android 12, Perfetto's **FrameTimeline** draws that contract for each frame, as two slices under your app:

- **Expected Timeline**: the window the app was given for this frame. It starts when the Choreographer callback was scheduled; its end is the frame's **deadline**.
- **Actual Timeline**: what really happened. It starts when `Choreographer#doFrame` started running and ends at whichever came later: the frame being posted to **SurfaceFlinger**, Android's service that combines every app's frames onto the display, (the RenderThread hands the finished frame over), or the GPU finishing.

When Actual ends after the deadline, the frame is janky, and FrameTimeline labels whose fault it was. "App Deadline Missed" means your app ran longer than expected. Other labels blame SurfaceFlinger or the display, and "Buffer Stuffing" means your app queued frames faster than they could be shown.

Notice that the GPU counts. A frame whose main thread finished early can still be late if the GPU work was too heavy.

So the method is: find the late frames on the Actual Timeline, then zoom into that frame's main thread and RenderThread. Read their states (puzzle 2) first, then the flame chart (puzzle 1) for the Running parts.

## The analogy

A train timetable next to the actual arrival board. The timetable (Expected) says when each train should arrive; the board (Actual) says when it did. A late train is easy to spot, and the board even says whether it was the driver or the station.

## Check yourself

#flashcards/perf

A frame's main thread finished well before the deadline, but FrameTimeline marks it late. What can explain it?::The GPU finished after the deadline, and that counts too. Actual ends at max(GPU, post time).

A frame is marked "App Deadline Missed". Where do you look next?::At that frame's main thread and RenderThread, states first. The app was late: read the app's threads.

What's the difference between the Expected Timeline and the Actual Timeline?::Expected is the window the app was given, while Actual is when its work really ran. Budget vs what happened.

## Sources

- [Perfetto: Android Jank detection with FrameTimeline](https://perfetto.dev/docs/data-sources/frametimeline) ("FrameTimeline requires Android 12(S) or higher"; "Expected Timeline: Each slice represents the time given to the app for rendering the frame… The start time is the time the Choreographer callback was scheduled to run"; "Actual Timeline: These slices represent the actual time an app took to complete the frame (including GPU work) and send it to SurfaceFlinger for composition… The end time of the slices here represent max(gpu time, post time)"; "AppDeadlineMissed: The app ran longer than expected causing a jank.")
- [Android Studio: UI jank detection](https://developer.android.com/studio/profile/jank-detection) (the threads relevant to a janky frame: "the UI thread, RenderThread, and the GPU completion thread")
