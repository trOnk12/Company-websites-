# Glossary: Performance, under the hood

Every word the course teaches, in the order it does. #flashcards/perf/words

call stack::The chain of function calls a thread is inside right now, from the first caller to the running function. (taught in [[00 A photo or a diary]])

instrumentation::Extra code injected into your app to record what it does; it slows the app down. (taught in [[00 A photo or a diary]])

method tracing::Recording a timestamp at the start and end of every method call, by instrumenting the code. (taught in [[00 A photo or a diary]])

sample::A snapshot of a thread's call stack, taken by the kernel every so many CPU events. (taught in [[00 A photo or a diary]])

trace section::A named span you mark yourself with trace("name") { }, recorded in a system trace. (taught in [[00 A photo or a diary]])

call chart::Each call drawn as a bar along a timeline, callees under their caller. (taught in [[01 Reading the flames]])

flame chart::The call chart with identical call stacks merged; width is total time, not a timeline. (taught in [[01 Reading the flames]])

self time::Time a function spent running its own code, not the functions it called. (taught in [[01 Reading the flames]])

total time::Self time plus the time spent in everything the function called. (taught in [[01 Reading the flames]])

Runnable::The thread is ready to run but waiting for a free CPU. (taught in [[02 Slow isn't always busy]])

Running::The thread is on a CPU, executing. (taught in [[02 Slow isn't always busy]])

Sleeping::The thread is waiting for something: a lock, a Binder reply, a message. (taught in [[02 Slow isn't always busy]])

thread state::What a thread is doing according to the kernel: running, runnable, sleeping, or in uninterruptible sleep. (taught in [[02 Slow isn't always busy]])

Uninterruptible Sleep::The thread is waiting inside the kernel, usually for disk I/O. (taught in [[02 Slow isn't always busy]])

Actual Timeline::When the app's frame work really started and ended, GPU included. (taught in [[03 The late frame]])

deadline::The end of a frame's expected window: finish after it and the frame is late. (taught in [[03 The late frame]])

Expected Timeline::The time window the app was given to render a frame. (taught in [[03 The late frame]])

FrameTimeline::Perfetto's view of every frame: when it was expected to finish and when it really did. (taught in [[03 The late frame]])

vsync::The display's regular signal that it's about to show a new frame. (taught in [[03 The late frame]])

allocation churn::Creating many short-lived objects, which makes the collector run often. (taught in [[04 What the collector costs]])

Concurrent Copying::ART's default garbage collector since Android 8: it moves live objects while your threads keep running. (taught in [[04 What the collector costs]])

garbage collector::The part of ART that finds objects nothing can reach and frees their memory. (taught in [[04 What the collector costs]])

heap::The memory where an app's objects live. (taught in [[04 What the collector costs]])

TLAB::A thread's own slice of the heap; allocating there is a pointer bump, with no lock. (taught in [[04 What the collector costs]])

young GC::A collection of only recently created objects, which mostly die young; cheap and frequent. (taught in [[04 What the collector costs]])

GC root::A starting point the collector always keeps: a thread's local variables, static fields, and the like. (taught in [[05 What a heap dump proves]])

heap dump::A snapshot of every object in the app's heap and who refers to whom. (taught in [[05 What a heap dump proves]])

leak::An object that's no longer needed but is still reachable from a GC root, so it's never freed. (taught in [[05 What a heap dump proves]])

retained size::The memory that would be freed if this object were freed: itself plus all it alone keeps alive. (taught in [[05 What a heap dump proves]])

shallow size::The memory one object takes by itself. (taught in [[05 What a heap dump proves]])
