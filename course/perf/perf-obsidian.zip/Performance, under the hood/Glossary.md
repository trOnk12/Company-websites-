# Glossary: Performance, under the hood

Every word the course teaches, in the order it does. #flashcards/perf/words

CPU core::One part of the processor that executes instructions; it runs one thread at a time. (taught in [[00 Threads take turns]])

preemption::The scheduler taking a core away from a running thread so another gets a turn. (taught in [[00 Threads take turns]])

run queue::The line of threads that are ready to run, waiting for a CPU core. (taught in [[00 Threads take turns]])

scheduler::The part of the kernel that decides which thread runs on which CPU. (taught in [[00 Threads take turns]])

wake::The kernel putting a sleeping thread back in a run queue once what it waited for has arrived. (taught in [[00 Threads take turns]])

Perfetto::The tool that records traces on an Android phone and draws them in the browser. (taught in [[01 What a trace is]])

slice::A named span on a track, with a start and an end; a slice under another happened inside it. (taught in [[01 What a trace is]])

trace::One continuous recording of timestamped events, detailed enough to rebuild the timeline. (taught in [[01 What a trace is]])

track::One row in a trace view, usually one thread's. (taught in [[01 What a trace is]])

call stack::The chain of function calls a thread is inside right now, from the first caller to the running function. (taught in [[02 A photo or a diary]])

CPU cycle::One tick of the processor's clock. (taught in [[02 A photo or a diary]])

instrumentation::Extra code injected into your app to record what it does; it slows the app down. (taught in [[02 A photo or a diary]])

method tracing::Recording a timestamp at the start and end of every method call, by instrumenting the code. (taught in [[02 A photo or a diary]])

native code::Code compiled straight to the processor's instructions, like the C and C++ inside Android and ART. (taught in [[02 A photo or a diary]])

sample::A snapshot of a thread's call stack, taken by the kernel every so many CPU events. (taught in [[02 A photo or a diary]])

trace section::A named span you mark yourself with trace("name") { }, recorded in a system trace. (taught in [[02 A photo or a diary]])

call chart::Each call drawn as a bar along a timeline, callees under their caller. (taught in [[03 Reading the flames]])

callee::A function called by another one, its caller. (taught in [[03 Reading the flames]])

flame chart::The call chart with identical call stacks merged; width is total time, not a timeline. (taught in [[03 Reading the flames]])

self time::Time a function spent running its own code, not the functions it called. (taught in [[03 Reading the flames]])

total time::Self time plus the time spent in everything the function called. (taught in [[03 Reading the flames]])

Runnable::The thread is ready to run but waiting for a free CPU. (taught in [[04 Slow isn't always busy]])

Running::The thread is on a CPU, executing. (taught in [[04 Slow isn't always busy]])

Sleeping::The thread is waiting for something: a lock, a Binder reply, a message. (taught in [[04 Slow isn't always busy]])

thread state::What a thread is doing according to the kernel: running, runnable, sleeping, or in uninterruptible sleep. (taught in [[04 Slow isn't always busy]])

Uninterruptible Sleep::The thread is waiting inside the kernel, usually for disk I/O. (taught in [[04 Slow isn't always busy]])

buffer::A block of memory that holds one picture, filled by the GPU and handed to SurfaceFlinger. (taught in [[05 Who puts pixels on screen]])

composite::Combining the latest buffer of every visible window into the one picture the display shows. (taught in [[05 Who puts pixels on screen]])

GPU::The graphics processor: the part of the chip built to fill millions of pixels at once. (taught in [[05 Who puts pixels on screen]])

SurfaceFlinger::The system service that combines every app's frames onto the display. (taught in [[05 Who puts pixels on screen]])

vsync::The display's regular signal that it's about to show a new frame. (taught in [[05 Who puts pixels on screen]])

Actual Timeline::When the app's frame work really started and ended, GPU included. (taught in [[06 The late frame]])

deadline::The end of a frame's expected window: finish after it and the frame is late. (taught in [[06 The late frame]])

Expected Timeline::The time window the app was given to render a frame. (taught in [[06 The late frame]])

FrameTimeline::Perfetto's view of every frame: when it was expected to finish and when it really did. (taught in [[06 The late frame]])

garbage::An object no chain of references from any root leads to; its memory can be reused. (taught in [[07 What garbage is]])

garbage collector::The part of ART that finds objects nothing can reach and frees their memory. (taught in [[07 What garbage is]])

GC root::A starting point the collector always keeps: a thread's local variables, static fields, and the like. (taught in [[07 What garbage is]])

heap::The memory where an app's objects live. (taught in [[07 What garbage is]])

reachable::An object a chain of references leads to from a GC root; some code could still use it. (taught in [[07 What garbage is]])

reference::A value that points at an object in the heap; variables and fields hold references, not objects. (taught in [[07 What garbage is]])

allocation churn::Creating many short-lived objects, which makes the collector run often. (taught in [[08 What the collector costs]])

Concurrent Copying::ART's default garbage collector since Android 8: it moves live objects while your threads keep running. (taught in [[08 What the collector costs]])

pause::A moment when the garbage collector stops your threads. (taught in [[08 What the collector costs]])

TLAB::A thread's own piece of the heap; allocating there is a pointer bump, with no lock. (taught in [[08 What the collector costs]])

young GC::A collection of only recently created objects, which mostly die young; cheap and frequent. (taught in [[08 What the collector costs]])

heap dump::A snapshot of every object in the app's heap and who refers to whom. (taught in [[09 What a heap dump proves]])

leak::An object that's no longer needed but is still reachable from a GC root, so it's never freed. (taught in [[09 What a heap dump proves]])

native memory::Memory outside the heap that the garbage collector doesn't manage. (taught in [[09 What a heap dump proves]])

retained size::The memory that would be freed if this object were freed: itself plus all it alone keeps alive. (taught in [[09 What a heap dump proves]])

shallow size::The memory one object takes by itself. (taught in [[09 What a heap dump proves]])
