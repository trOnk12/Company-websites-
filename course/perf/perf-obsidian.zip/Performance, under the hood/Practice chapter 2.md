# Memory under pressure

## Budget image pixels in bytes

A compressed image file and its decoded pixels have different sizes. For a tightly packed 32-bit ARGB bitmap, estimate width × height × 4 bytes before padding and other allocations. Bitmap pixel storage has varied by Android version; native allocations can matter even when the managed wrapper is small.

### Worked example

A 4000 by 3000 image needs about 48,000,000 bytes, or 45.8 MiB, for one tightly packed buffer. Four decoded copies need roughly 183 MiB before temporary buffers. A 1000 by 750 preview needs about 2.86 MiB in the same format. Measure the actual allocation on the target device.

### Try it

The network file shrinks from 2 MB to 1 MB but decode size stays 4000 by 3000. How much did your decoded estimate fall?

### Compare your answer

It stayed at about 45.8 MiB for that pixel format. Decode near the display size and bound the number of concurrent images to reduce this cost.

[Source · Android · Managing bitmap memory](https://developer.android.com/topic/performance/graphics/manage-memory)

## Interpret a low-memory process death

System pressure concerns many processes and multiple kinds of memory. Android's low memory killer daemon can terminate less important processes under pressure. Process importance, pressure signals and device policy influence selection; there is no universal app-size threshold that predicts every kill.

### Worked example

After visiting a gallery, an app enters the background and later returns in a new process. Check process identity and available exit evidence, then compare memory across a representative device and workload. A fresh process proves recreation; on its own it does not establish an out-of-memory exception or a leaking Activity.

### Try it

Would raising the app's managed heap limit guarantee the cached process remains alive?

### Compare your answer

No. A managed allocation limit and system-wide process reclaim are different boundaries. Reduce dispensable memory and persist the state needed to recover from any process death.

[Source · AOSP · Low memory killer daemon](https://source.android.com/docs/core/perf/lmkd)

## Trim by recovery cost and visibility

Classify memory as durable user data, essential working state or rebuildable caches. When the UI is no longer visible, some caches can be reduced or dropped. Android trim callbacks and supported levels vary by API version; correctness must survive even if no warning arrives.

### Worked example

A thumbnail cache occupies 80 MiB and a transient full-size preview holds 46 MiB. Closing the viewer releases the preview. After backgrounding, shrinking the cache to 20 MiB can free another 60 MiB of retained cache entries. Releasing references makes memory eligible for reuse; it does not guarantee an immediate equal fall in reported process size.

### Try it

A draft is stored only inside the thumbnail cache entry. Is clearing it safe under memory pressure?

### Compare your answer

Persist the user’s draft independently before eviction. A cache is safe to discard only if its contents can be rebuilt without losing the user’s work.

[Source · Android · Manage your app’s memory](https://developer.android.com/topic/performance/memory)

## Distinguish allocation rate from retained growth

Allocation tracking records which code creates objects over a selected interval. Heap inspection asks which objects are still reachable at a chosen time. A high allocation rate can create churn, while a low rate can still hide a slow leak. Repeat one controlled interaction to separate the two.

### Worked example

A scroll creates 6,000 temporary objects per second with a mean of 80 bytes: roughly 480,000 bytes per second allocated before overhead. If they become unreachable promptly, retained heap may stay flat. Conversely, retaining a single 4 MiB bitmap per visit grows retained data by about 40 MiB after ten visits.

### Try it

Which experiment distinguishes these mechanisms when both appear during gallery navigation?

### Compare your answer

Record allocations during a fixed scroll, then compare heap snapshots after repeated open-close cycles at the same resting screen. Inspect retaining paths and native bitmap memory as well as managed object counts.

[Source · Android Studio · Record Java/Kotlin allocations](https://developer.android.com/studio/profile/record-java-kotlin-allocations)

[[Final project]]

[[Course map]]