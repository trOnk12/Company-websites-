---
course: "Performance, under the hood"
puzzle: 5
source: https://pachulski.dev/course/perf/05-what-a-heap-dump-proves
tags: [course/perf]
---

# What a heap dump proves

> [!summary] The idea to keep
> A heap dump is a snapshot of every object and who refers to whom. Shallow size is one object alone; retained size is everything that would be freed with it. A leak is an object you're done with that's still reachable from a GC root, often a destroyed Activity held by something long-lived. The path from the root shows exactly which reference to cut.

**Builds on:** what you know from [Android from the foundation](https://pachulski.dev/android/)

## The problem

After rotating the phone ten times, your app uses 80 MB more than at start. The garbage collector frees everything that's unreachable, so whatever is left must still be reachable. From where? And which object, among millions, is the one to fix?

## See it

![What a heap dump proves](https://pachulski.dev/course/perf/gifs/heap.gif)

Step through it: https://pachulski.dev/course/perf/05-what-a-heap-dump-proves

## The building block

A **heap dump** is a snapshot of every object in your app's heap, with every reference between them. Android Studio lists them by class with two sizes:

- **Shallow size**: the memory one object takes by itself, its own fields. An Activity is a few hundred bytes.
- **Retained size**: the memory that would be freed if this object were freed: itself, plus everything only it keeps alive. That same Activity can retain megabytes: its screen and its Compose state. (Bitmap pixels live in native memory, shown separately as Native Size.)

The collector (puzzle 4) starts from **GC roots**, the references it always keeps: local variables of running threads, static fields, and the like. Whatever it reaches stays; the rest is freed. So a **leak** in a garbage-collected app is an object you're finished with that's still reachable from a root.

The classic case: on rotation, your Activity is destroyed and a new one created (the Android course, module 4). If a long-lived object, such as a listener registered in a `companion object` or a singleton, still refers to the old Activity, the old Activity stays reachable, and everything it retains stays too. Ten rotations, ten old Activities.

The heap dump proves it. Android Studio's "Show activity/fragment leaks" filter finds destroyed Activities still in memory. For each instance it shows its depth, the shortest number of references from a GC root, and the reference chain. Cut one link in that chain, usually by unregistering the listener when the Activity is destroyed, and the whole retained size is freed.

## The analogy

A hotel cleans every room whose guest has checked out (the collector). A guest who left but whose name is still on a booking (a reference from a root) keeps the room, and everything in it, forever. The booking list is the chain: cancel that one booking, and the whole room is freed.

## Check yourself

#flashcards/perf

An old Activity has a shallow size of 400 bytes and a retained size of 12 MB. What does freeing it save?::About 12 MB, since everything only it keeps alive goes too. Retained size is what you really get back.

The GC frees whatever it can't reach. How can an app leak?::An object it no longer needs is still reachable from a GC root. Reachable but unneeded.

What's the difference between shallow size and retained size?::Shallow size is the object alone, while retained size adds everything it alone keeps alive. One object vs what goes with it.

## Sources

- [Android Studio: Capture a heap dump](https://developer.android.com/studio/profile/capture-heap-dump) ("Shallow Size: Size of this instance in Java memory. Retained Size: Size of memory that this instance dominates"; "Depth: The shortest number of hops from any GC root to the selected instance"; "Show activity/fragment leaks: Shows classes that are causing memory leaks"; "leaking the host Activity will retain the entire Compose hierarchy and all active state trees in memory"; "Long-lived references to Activity or Context")
- [Android Developers: Overview of memory management](https://developer.android.com/topic/performance/memory-overview) ("Garbage collection has two goals: find data objects in a program that cannot be accessed in the future; and reclaim the resources used by those objects.")
