# Measure a real user journey

## Design a repeatable Macrobenchmark

Macrobenchmark drives an installed app from a separate benchmark process and measures a user journey on a device. The build, startup mode, compilation state, device and initial data are part of the experiment. Separate setup actions from the measured block so results match the question.

### Worked example

Five illustrative cold-start measurements are 405, 390, 710, 400 and 395 ms. Sorted, their median is 400 ms. A single 390 ms run hides the 710 ms outlier. Compare repeated control and candidate runs, inspect traces and investigate thermal state or unrelated activity before attributing the difference.

### Try it

The candidate was measured after the notes database had warmed; the control also performed its first migration. What would you rerun?

### Compare your answer

Measure both variants under the same migration and cache conditions. If first install matters, run a separate first-install journey and label it clearly.

[Source · Android · Write a Macrobenchmark](https://developer.android.com/topic/performance/benchmarking/macrobenchmark-overview)

## Control compilation with a Baseline Profile

A Baseline Profile describes important code paths so ART can compile selected methods ahead of time under supported installation and compilation conditions. It can reduce interpretation or just-in-time compilation on early journeys. It cannot remove an unnecessary network wait or disk access.

### Worked example

A startup trace spends 70 ms executing a hot method and 250 ms waiting for data. Compare otherwise identical builds and device compilation modes with and without the intended profile. Confirm that the startup journey is in the profile, then inspect which trace intervals actually change.

### Try it

Why can comparing a profiled release build against a debug build give the wrong reason for a speedup?

### Compare your answer

Compilation, optimization and debug instrumentation all changed. Hold the build type and other inputs constant, explicitly control compilation and compare the same journey.

[Source · Android · Baseline Profiles overview](https://developer.android.com/topic/performance/baselineprofiles/overview)

## Name the startup finish line

A cold startup begins without an app process. A warm or hot start reuses some prior work. Time to initial display measures the first frame, while time to full display tracks the app’s declaration that meaningful content is ready. Define what useful means for the screen before instrumenting it.

### Worked example

The launch starts at 0 ms. The first frame with placeholders appears at 340 ms. A readable, tappable notes list appears at 920 ms. Recording full display at the placeholder would hide 580 ms. If network data is optional, define whether usable local content satisfies the contract.

### Try it

A release improves first display by 100 ms while full display worsens by 200 ms. Did startup improve?

### Compare your answer

The initial frame appeared sooner while useful content arrived later. Report both changes, inspect the first-use path and choose the metric that matches the product promise.

[Source · Android · App startup time](https://developer.android.com/topic/performance/vitals/launch-time)

## Query trace slices without double counting

Perfetto exposes timestamped events as tables. A slice has a name, start timestamp, duration and track. Timestamp and duration in the standard slice table are in nanoseconds. Filter by the correct track and interval before interpreting totals; nested or overlapping slices can double count wall time.

### Worked example

For your own instrumented slice named DecodeThumbnail, start with SELECT track_id, ts, dur / 1000000.0 AS ms FROM slice WHERE name = 'DecodeThumbnail' AND dur >= 0 ORDER BY ts. A parent lasting 18 ms may contain a 12 ms child. Adding them gives 30 ms of labels inside only 18 ms of elapsed parent time.

### Try it

Two decoder tracks each show 15 ms in the same 15 ms interval. Does that prove the UI blocked for 30 ms?

### Compare your answer

No. Identify which thread the UI awaited, align events on the timeline and inspect scheduling or dependencies. Concurrent elapsed intervals and nested durations cannot simply be summed into UI latency.

[Source · Perfetto · Getting started with PerfettoSQL](https://perfetto.dev/docs/analysis/perfetto-sql-getting-started)

[[Practice chapter 2|Memory under pressure]]

[[Course map]]