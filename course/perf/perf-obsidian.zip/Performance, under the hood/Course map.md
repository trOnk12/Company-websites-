---
source: https://pachulski.dev/course/perf/
tags: [course/perf]
---

# Performance, under the hood

What the profiler is really showing you: how a sample differs from a trace, how to read a flame chart, why a slow function isn't always busy, when a frame is late, what the garbage collector actually costs, and what a heap dump proves. Built from the kernel up, one small puzzle at a time.

From [pachulski.dev](https://pachulski.dev/course/perf/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: What the profiler is really showing you

Samples and traces, flame charts, thread states, late frames, the garbage collector and heap dumps.

- [[00 A photo or a diary]]: Android Studio offers to take snapshots of what your app is running, or to record every method. They answer different questions, and one of them changes the timings it measures. Here's what each actually records.
- [[01 Reading the flames]]: The profiler draws the same recording two ways. In one, left to right is time; in the other, it isn't. Here's how to read each, and where a slow function really spends its time.
- [[02 Slow isn't always busy]]: A trace section on your main thread takes 120 ms, but a sample of the same moment shows almost nothing running. Both are right. Here's the line under every thread in a system trace that explains it.
- [[03 The late frame]]: The Android course showed that a frame must be ready before the screen's next refresh. Perfetto draws that limit for every frame, next to when the frame really finished. Here's how to read the two lines, and tell your app's lateness from someone else's.
- [[04 What the collector costs]]: "Freeing memory paused my app" was true on old Android. Modern ART collectors barely pause. Here's how ART allocates and collects, and the way it can still cost you frames.
- [[05 What a heap dump proves]]: Puzzle 4's collector frees everything it can't reach. So how does memory get stuck in a garbage-collected app? Here's what a snapshot of memory records, the two sizes it shows, and the chain that proves memory is stuck.

## Coming next

- Module 2: Measuring for real (coming): Macrobenchmark and why one run proves nothing; baseline profiles and what ART compiles ahead of time; startup traced end to end; reading a Perfetto trace with SQL.
- Module 3: Memory under pressure (coming): Native memory and bitmaps, the low memory killer, trimming memory, and allocation tracking.

[[Glossary]]
