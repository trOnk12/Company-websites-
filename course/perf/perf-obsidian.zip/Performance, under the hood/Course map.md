---
source: https://pachulski.dev/course/perf/
tags: [course/perf]
---

# Performance, under the hood

What the profiler is really showing you, built from the ground up: how threads take turns on the processor, what a trace records, how a sample differs from a trace, how to read a flame chart, why a slow function isn't always busy, how pixels reach the screen and when a frame is late, what garbage is and what collecting it costs, and what a heap dump proves. One small puzzle at a time.

From [pachulski.dev](https://pachulski.dev/course/perf/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: Where the time goes

How threads take turns on the CPU, what a trace records, samples and traces, flame charts, and why a slow span may not be busy.

- [[00 Threads take turns]]: Your app runs dozens of threads, and so does every other app, on a phone that can run only a handful at once. Something has to decide who runs. Here's the kernel's turn-taking, the building block under every profiler chart in this course.
- [[01 What a trace is]]: Every performance tool in this course ends up drawing the same picture: rows of coloured bars over time. Before reading any of them, here's what that recording is, who writes it, and how to read one row.
- [[02 A photo or a diary]]: Android Studio offers to take snapshots of what your app is running, or to record every method. They answer different questions, and one of them changes the timings it measures. Here's what each actually records.
- [[03 Reading the flames]]: The profiler draws the same recording two ways. In one, left to right is time; in the other, it isn't. Here's how to read each, and where a slow function really spends its time.
- [[04 Slow isn't always busy]]: A trace section on your main thread takes 120 ms, but a sample of the same moment shows almost nothing running. Both are right. Here's the line under every thread in a system trace that explains it.

## Module 2: Frames and memory

How pixels reach the screen and when a frame is late; what garbage is, what collecting it costs, and what a heap dump proves.

- [[05 Who puts pixels on screen]]: Your app never touches the display. It fills a block of memory with pixels and hands it to someone else, who combines it with every other window on screen. Here's that hand-off, the path every frame takes.
- [[06 The late frame]]: Puzzle 5 showed that a frame's buffer must be ready before the display's next refresh. Perfetto draws that limit for every frame, next to when the frame really finished. Here's how to read the two lines, and tell your app's lateness from someone else's.
- [[07 What garbage is]]: In Kotlin you create objects and never free them. Something else decides when an object's memory can be reused. Here's the rule it follows, which is the rule behind both memory puzzles that come next.
- [[08 What the collector costs]]: "Freeing memory freezes my app" was true on old Android. Modern ART collectors barely stop it. Here's how ART allocates and collects, and the way it can still cost you frames.
- [[09 What a heap dump proves]]: Puzzle 8's collector frees everything it can't reach. So how does memory get stuck in a garbage-collected app? Here's what a snapshot of memory records, the two sizes it shows, and the chain that proves memory is stuck.

[[Final project]]

## Coming next

- Module 3: Measuring for real (coming): Macrobenchmark and why one run proves nothing; baseline profiles and what ART compiles ahead of time; startup traced end to end; reading a Perfetto trace with SQL.
- Module 4: Memory under pressure (coming): Native memory and bitmaps, the low memory killer, trimming memory, and allocation tracking.

[[Glossary]]
