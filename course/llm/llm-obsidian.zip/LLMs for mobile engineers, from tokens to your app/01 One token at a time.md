---
course: "LLMs for mobile engineers, from tokens to your app"
puzzle: 1
source: https://pachulski.dev/course/llm/01-one-token-at-a-time
tags: [course/llm]
---

# One token at a time

> [!summary] The idea to keep
> A language model reads and writes tokens: words, pieces of words, characters. It produces an answer by next-token prediction: given all the text so far, pick one next token, append it, and run again, until it stops. Limits, latency and price are all counted in tokens, and longer answers take longer because each token is one more step.

**Builds on:** [[00 What a language model is]]

## The problem

Your app sends "Summarise this review" with a 300-word review, and gets a 60-word summary back. The API bill doesn't count words at all. The response time grows mostly with the length of the answer, much less with the question. What is the model actually doing?

## See it

![One token at a time](https://pachulski.dev/course/llm/gifs/tokens.gif)

Step through it: https://pachulski.dev/course/llm/01-one-token-at-a-time

## The building block

A language model doesn't see letters or words. Text is first cut into **tokens**: common words are one token, rarer words are split into pieces, and emoji or unusual characters can take several. On Anthropic's earlier Claude models, one token was about 3.5 English characters; other languages and other models differ. The API's token counting tells you exactly.

Then the model does one thing, over and over: **next-token prediction**. Given all the tokens so far, the prompt plus whatever it has written, it picks the next token. That token is appended, and the model runs again on the slightly longer text. It stops when it picks an end-of-answer token, or hits the maximum length you set (the next puzzle shows where). (The prompt itself is read in one go; only the answer is written step by step. That's why a long answer costs more time than a long question.)

Three consequences you'll feel in an app:

| | Because |
|---|---|
| A long answer takes longer than a short one | each token is one more run of the model |
| Limits and prices are in tokens | that's the unit the model reads and writes |
| The same text costs different amounts in different languages | the split into tokens differs |

## The analogy

A typist who can only see what's already on the page, and adds one word at a time, each time rereading the page to decide the next. The page is never planned in advance: every word is chosen when it's time.

## Check yourself

#flashcards/llm

Why does a 300-token answer take longer than a 30-token one?::Each token is one more run of the model, one after another. One token per step.

The same text in Polish costs more tokens than in English. Why?::The text is split into more tokens, since the split depends on the language. Different languages, different splits.

What's the difference between a token and a word?::A token is the model's unit, which can be a word, part of one, or a character. The model's unit, not the dictionary's.

## Sources

- [Anthropic: Glossary](https://docs.anthropic.com/en/docs/about-claude/glossary) ("Tokens are the smallest individual units of a language model, and can correspond to words, subwords, characters, or even bytes"; earlier models: "a token represents approximately 3.5 English characters"; "autoregressive language models… are pretrained to predict the next word, given the previous context of text")
