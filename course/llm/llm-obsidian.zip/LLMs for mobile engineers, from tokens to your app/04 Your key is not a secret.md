---
course: "LLMs for mobile engineers, from tokens to your app"
puzzle: 4
source: https://pachulski.dev/course/llm/04-your-key-is-not-a-secret
tags: [course/llm]
---

# Your key is not a secret

> [!summary] The idea to keep
> Anything in your APK can be extracted, so an API key in the app belongs to anyone who downloads it, and they can spend your money. Call the model through a proxy backend: the app authenticates the user to your server, and the server adds the key, applies per-user limits and calls the model. The key never leaves the server.

**Builds on:** [[01 Why answers stream]]

## The problem

You put the model provider's key in `BuildConfig`, obfuscated with R8, and call the API straight from the app. It works. Then your usage dashboard shows calls your app never made, around the clock, with prompts that have nothing to do with your feature. How did anyone get the key?

## See it

![Your key is not a secret](https://pachulski.dev/course/llm/gifs/proxy.gif)

Step through it: https://pachulski.dev/course/llm/04-your-key-is-not-a-secret

## The building block

An **API key** is a password for your account: whoever sends it, gets served, and you get billed. And an APK is a file anyone can download and unpack. Strings in it can be found; obfuscation renames code but a key is still a string the app must send; and even if you hide it well, the key travels in every request from a phone the attacker controls, where they can intercept their own traffic. Google Cloud's guidance is plain: don't include API keys in client code.

So the key lives on a server you control, a **proxy backend**:

1. The app calls **your** server, authenticated as the user (your normal login token).
2. Your server checks who it is, applies limits per user ("20 requests a day on the free plan"), and builds the request: your system prompt, the user's message.
3. Your server adds the API key and calls the model, streaming the answer back to the app (puzzle 1).

The key never leaves the server. If one user abuses the feature, you block that user, not your whole account. And your instructions to the model and the model choice can change without an app release.

## The analogy

A company card. You don't hand the card to every customer and trust them to buy only what you meant. A cashier holds it, checks who's asking, applies the limit, and pays.

## Check yourself

#flashcards/llm

The key is in the APK, obfuscated by R8. Is it safe?::No: the app must send it, so it can be found in the APK or in the app's traffic. If the app can send it, users can read it.

With a proxy backend, one user floods the AI feature. What can you do?::Limit or block that user on your server, without changing the key. The server sees users, not only a key.

What's the difference between an API key and the user's login token?::The API key bills your account with the provider, while the login token says who the user is to your server. Your account vs your user.

## Sources

- [Google Cloud: Best practices for managing API keys](https://cloud.google.com/docs/authentication/api-keys-best-practices) ("Don't include API keys in client code or commit them to code repositories. API keys hardcoded in the source code or stored in a repository are open to interception or theft by bad actors. The client should pass requests to the server, which can add the credential and issue the request.")
