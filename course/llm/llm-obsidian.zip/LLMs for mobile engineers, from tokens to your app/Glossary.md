# Glossary: LLMs for mobile engineers, from tokens to your app

Every word the course teaches, in the order it does. #flashcards/llm/words

language model::A program trained on huge amounts of text that continues any text you give it. (taught in [[00 What a language model is]])

LLM::A large language model, too big for a phone, run on a provider's servers. (taught in [[00 What a language model is]])

training::How a model learned: shown huge amounts of text and corrected, again and again, at predicting what comes next. (taught in [[00 What a language model is]])

next-token prediction::What the model does: given the text so far, pick the next token, add it, and repeat. (taught in [[01 One token at a time]])

token::The unit a language model reads and writes: a word, part of a word, a character or a byte. (taught in [[01 One token at a time]])

max_tokens::The most tokens the model may write in its answer. (taught in [[02 Your first call]])

messages::The conversation sent with each request: a list of turns marked user or assistant. (taught in [[02 Your first call]])

stop_reason::Why the answer ended: end_turn when finished, max_tokens when cut off. (taught in [[02 Your first call]])

turn::One message in the conversation, marked user (your side) or assistant (the model's). (taught in [[02 Your first call]])

usage::The input and output tokens a call used: what you pay for. (taught in [[02 Your first call]])

server-sent events::A way for a server to send a stream of small events over one open HTTP response. (taught in [[03 Why answers stream]])

streaming::Receiving the answer token by token as it's generated, instead of all at once at the end. (taught in [[03 Why answers stream]])

time to first token::How long until the first token of the answer arrives: what makes an app feel responsive. (taught in [[03 Why answers stream]])

context window::The text the model can see for one request, including its answer: its working memory. (taught in [[04 It remembers nothing]])

stateless::Keeping nothing between requests: every request must carry everything needed. (taught in [[04 It remembers nothing]])

probability::How likely something is, as a share of 100%. (taught in [[05 Same question, different answers]])

sampling::Choosing the next token at random, weighted by how likely the model thinks each one is. (taught in [[05 Same question, different answers]])

temperature::A setting for how random the choice of next token is: higher is more varied, lower more predictable. (taught in [[05 Same question, different answers]])

API key::A secret that lets whoever holds it call a paid API on your account. (taught in [[06 Your key is not a secret]])

login token::The token your app gets when the user signs in, which proves to your server who they are. (taught in [[06 Your key is not a secret]])

obfuscation::Scrambling names in code to make it harder to read. (taught in [[06 Your key is not a secret]])

proxy backend::Your own server that the app calls; it checks the user, adds the API key, and calls the model. (taught in [[06 Your key is not a secret]])

AICore::Android's system service that runs Gemini Nano on the device and keeps it updated. (taught in [[07 On the phone or in the cloud]])

on-device model::A model that runs on the phone itself, with no network call. (taught in [[07 On the phone or in the cloud]])

quota::A cap on how many requests an app may make in a period. (taught in [[07 On the phone or in the cloud]])
