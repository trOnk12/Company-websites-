# Glossary: LLMs for mobile engineers, from tokens to your app

Every word the course teaches, in the order it does. #flashcards/llm/words

next-token prediction::What the model does: given the text so far, pick the next token, add it, and repeat. (taught in [[00 One token at a time]])

token::The unit a language model reads and writes: a word, part of a word, a character or a byte. (taught in [[00 One token at a time]])

server-sent events::A way for a server to send a stream of small events over one open HTTP response. (taught in [[01 Why answers stream]])

streaming::Receiving the answer token by token as it's generated, instead of all at once at the end. (taught in [[01 Why answers stream]])

time to first token::How long until the first token of the answer arrives: what makes an app feel responsive. (taught in [[01 Why answers stream]])

context window::The text the model can see for one request, including its answer: its working memory. (taught in [[02 It remembers nothing]])

stateless::Keeping nothing between requests: every request must carry everything needed. (taught in [[02 It remembers nothing]])

sampling::Choosing the next token at random, weighted by how likely the model thinks each one is. (taught in [[03 Same question, different answers]])

temperature::A setting for how random the choice of next token is: higher is more varied, lower more predictable. (taught in [[03 Same question, different answers]])

API key::A secret that lets whoever holds it call a paid API on your account. (taught in [[04 Your key is not a secret]])

proxy backend::Your own server that the app calls; it checks the user, adds the API key, and calls the model. (taught in [[04 Your key is not a secret]])

AICore::Android's system service that runs Gemini Nano on the device and keeps it updated. (taught in [[05 On the phone or in the cloud]])

on-device model::A model that runs on the phone itself, with no network call. (taught in [[05 On the phone or in the cloud]])
