---
course: "LLMs for mobile engineers, from tokens to your app"
puzzle: 5
source: https://pachulski.dev/course/llm/05-same-question-different-answers
tags: [course/llm]
---

# Same question, different answers

> [!summary] The idea to keep
> At each step the model gives every possible next token a probability, and the next token is chosen by sampling from them. Temperature sets how adventurous that choice is: higher gives more varied text, lower sticks to the most likely tokens. Even at temperature 0 the output isn't fully deterministic, so test model features on properties, not exact strings.

**Builds on:** [[02 Your first call]]

## The problem

Your test calls the model with the same review and asserts the summary equals a saved string. It flips between passing and failing. Users also notice: "regenerate" gives a different answer each time. Is the model broken?

## See it

![Same question, different answers](https://pachulski.dev/course/llm/gifs/sampling.gif)

Step through it: https://pachulski.dev/course/llm/05-same-question-different-answers

## The building block

Puzzle 1 said the model picks the next token. More precisely, at each step it gives every possible next token a **probability**, a share of 100% saying how likely it is: "Great" 60%, "Good" 30%, "Fine" 10%. Then one is chosen by **sampling**: at random, weighted by those scores. Usually the likely one; sometimes not. Once a different token is picked, everything after it can go differently.

**Temperature** controls how adventurous the sampling is:

- Higher: less likely tokens get picked more often. More varied, more creative, sometimes less accurate.
- Lower: the most likely tokens win more often. More predictable, more repetitive.

For an app feature that must be consistent, like extracting fields or summarising, use a low temperature when the chosen model supports it. For brainstorming, compare settings on representative examples. Some models do not accept a temperature parameter.

But Anthropic's documentation is explicit: even at temperature 0, results aren't fully deterministic (the same input always giving the same output), and identical inputs might produce different outputs. A low temperature can reduce variation; it does not promise identical outputs across runs, model revisions or serving configurations. So tests can't compare exact strings. Test what must be true: valid JSON, the required fields present, length under a limit, no forbidden words. For quality, keep a set of example inputs and check the answers in bulk.

## The analogy

A jazz musician playing a standard. Ask for a strict take (low temperature) and you get nearly the same performance every night. Ask for a free one (high temperature) and every night is different. Even the strict take isn't a recording: tiny differences still creep in.

## Check yourself

#flashcards/llm

You set temperature to 0. Can you now assert the exact output string in a test?::No: even at 0 the output isn't guaranteed to be identical. Test properties, not strings.

Your app extracts a date and an amount from a receipt photo. Which temperature suits it?::A low one, since you want the most likely, consistent answer. Consistency wants low temperature.

What's the difference between sampling and temperature?::Sampling is choosing the next token at random by likelihood, while temperature sets how adventurous that choice is. The choice vs the knob on it.

## Sources

- [Anthropic: Glossary, Temperature](https://docs.anthropic.com/en/docs/about-claude/glossary) ("Temperature is a parameter that controls the randomness of a model's predictions during text generation. Higher temperatures lead to more creative and diverse outputs… Lower temperatures result in more conservative and deterministic outputs that stick to the most probable phrasing and answers"; "Even with temperature set to 0, the results will not be fully deterministic, and identical inputs might produce different outputs across API calls.")
