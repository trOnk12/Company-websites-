---
course: "LLMs for mobile engineers, from tokens to your app"
puzzle: 0
source: https://pachulski.dev/course/llm/00-what-a-language-model-is
tags: [course/llm]
---

# What a language model is

> [!summary] The idea to keep
> A language model is a program trained on huge amounts of text until, given any text, it can score which words are likely to come next, and so continue it: answer a question, summarise a review. Hosted ones run on a provider's servers (Anthropic's Claude, Google's Gemini), and your app reaches them through an API: an HTTP request with your text, and a response with the continuation.

## The problem

Your product team wants "summarise this review" in the app. People call the thing that does it an AI or a model. Before any code: what is it, where does it run, and what does your app actually talk to?

## See it

![What a language model is](https://pachulski.dev/course/llm/gifs/model.gif)

Step through it: https://pachulski.dev/course/llm/00-what-a-language-model-is

## The building block

A **language model** is a program that continues text. Give it "The capital of France is" and it continues with "Paris". Give it a review and "Summary:" and it continues with a summary.

It learned to do that in **training**: it was shown huge amounts of text and, again and again, asked what comes next, and adjusted every time it was wrong. The result is a program that, given any text, can score how likely each possible next word is. Picking likely words, one after another, produces an answer. (The next puzzle shows the exact unit it picks.)

The big ones are called large language models, **LLM**s. Some run on phones. Hosted models run on a provider's servers: Anthropic's models are called Claude, Google's are called Gemini.

Your app reaches one through an **API**: an HTTP request to the provider, with your text in the body and a secret key that identifies your account, and a response with the continuation in it. To your code, it's a slow, expensive, very capable endpoint.

## The analogy

Autocomplete on your keyboard, scaled up by a factor of millions. Your keyboard suggests the next word from what you typed; a language model does the same with whole paragraphs, because it has read far more.

## Check yourself

#flashcards/llm

What does a language model do with the text you send it?::It continues it, one likely word after another. It continues text.

Where does a large language model like Claude usually run when your app uses it?::On the provider's servers, reached through an API. On servers, through an API.

What's the difference between training and using a model?::Training is how it learned from text, while using it means sending text and getting a continuation. Learning vs answering.

## Sources

- [Anthropic: Glossary, LLM](https://docs.anthropic.com/en/docs/about-claude/glossary) ("Large language models (LLMs) are AI language models with many parameters that are capable of performing a variety of surprisingly useful tasks. These models are trained on vast amounts of text data and can generate human-like text, answer questions, summarize information, and more"; models are "pretrained to predict the next word, given the previous context of text")
