---
source: https://pachulski.dev/course/llm/
tags: [course/llm]
---

# LLMs for mobile engineers, from tokens to your app

What actually happens when your app calls a language model: tokens, one at a time; why answers stream; why the model remembers nothing; why the same question gets different answers; where the API key must never live; and when the model should run on the phone instead. One small puzzle at a time.

From [pachulski.dev](https://pachulski.dev/course/llm/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: A model in your app

Tokens, streaming, statelessness and the context window, temperature, keys, and on-device models.

- [[00 What a language model is]]: Before anything else, the one idea everything stands on. You send a model some text; it continues it. Here's what that program is, where it runs, and how your app reaches it.
- [[01 One token at a time]]: You send a prompt and get a paragraph back. It looks like the model writes the answer the way you would. It doesn't. Here's the loop that produces every word, and the unit everything is measured and billed in.
- [[02 Your first call]]: Puzzle 1 said the model works in tokens. Now one real call, so everything after it has something concrete to stand on: what your app sends, what comes back, and the three numbers that matter in the response.
- [[03 Why answers stream]]: Your chat screen shows a spinner for eight seconds, then the whole answer at once. Users think it's broken. The model had the first words after half a second. Here's how to show them, and what changes in your networking code.
- [[04 It remembers nothing]]: Your chatbot answers the first question well, then forgets it on the second. Or it remembers everything, and each message gets slower and more expensive. Both come from one fact about the API. Here's what your app must send, every time.
- [[05 Same question, different answers]]: Your unit test checks the model's summary against an expected string. It passes, then fails, then passes, with no code change. Here's where the randomness comes from, the knob that turns it down, and why it never reaches zero.
- [[06 Your key is not a secret]]: The quickest way to ship an AI feature is to put the provider's key in the app and call the model directly. A week later the bill is ten times your users' usage. Here's why a key inside an APK isn't hidden, and the small backend that fixes it.
- [[07 On the phone or in the cloud]]: Puzzle 6 put a server between your app and the model. For some features you can skip the server and the network entirely: Android ships a model that runs on the phone. Here's what it's good at, what it costs you, and how to choose.

## Module 2: Text retrieval and evidence

Compare two ways to find text, and test selection separately from the claims an assistant makes.

- [[08 Find evidence before asking the model]]: A support assistant needs the correct help article. Compare two ways to select it for the same question.
- [[09 Which step failed the answer]]: Keep the same help question and find whether the problem happened during search or writing.

## Coming next

- Next: what a call costs and how it fails (coming): max_tokens and a cut-off answer, why output tokens cost more than input, rate limits and retries, prompt caching, and structured output you can parse.
- Module 3: Tool use and chat assistants (coming): Compare model tool calling and reusable skills with the same text cases. Under explicit permissions, connect a chat interface to a read-only test tool and inspect the tool logs.
- Module 4: Shipping it (coming): Prompt caching and cost, evaluating answers, guardrails, latency budgets on mobile, and fallbacks when the model is down.

[[Glossary]]
