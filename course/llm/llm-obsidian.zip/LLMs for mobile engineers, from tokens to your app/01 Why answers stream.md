---
course: "LLMs for mobile engineers, from tokens to your app"
puzzle: 1
source: https://pachulski.dev/course/llm/01-why-answers-stream
tags: [course/llm]
---

# Why answers stream

> [!summary] The idea to keep
> Because the model writes one token at a time, the API can stream: send each piece as it's generated, over one open HTTP response, as server-sent events. Time to first token, not total time, is what makes an app feel fast. On mobile, the stream is a long-lived request: keep it on a background coroutine, append to UI state as events arrive, and cancel it when the user leaves.

**Builds on:** [[00 One token at a time]]

## The problem

Your app calls the model and waits for the full answer: eight seconds of spinner, then a wall of text. In the model's own playground, words start appearing almost at once. Same model, same prompt. What does the playground do that your app doesn't?

## See it

![Why answers stream](https://pachulski.dev/course/llm/gifs/stream.gif)

Step through it: https://pachulski.dev/course/llm/01-why-answers-stream

## The building block

Puzzle 0 showed the model produces an answer one token at a time. So the first tokens exist long before the last one. If the API waits for the whole answer, your user waits for all of it.

With **streaming**, the API sends each new piece as soon as it's generated. Anthropic's API does this when you set `"stream": true`: one HTTP response stays open, and pieces arrive as **server-sent events**, small text events on the same connection.

Two numbers now matter:

- **Time to first token**: how long until the first words appear. This is what the user feels.
- Total time: about the same as before. Streaming doesn't make the model faster; it stops hiding its progress.

On Android, the stream is a long-lived request, so it changes your code more than a normal call:

- Run it on a coroutine that the screen's ViewModel owns, and append each piece to the UI state as it arrives.
- Cancel it when the user leaves or taps stop: you pay for every token generated, wanted or not. If the stream goes through your own server (puzzle 4), the server must cancel its request to the model too, or generation and billing carry on.
- OkHttp has an SSE add-on (`okhttp-sse`), and Anthropic publishes a Java SDK that streams.
- A dropped connection mid-answer is normal on mobile (puzzle 0 of the Mobile system design course): keep what arrived, show it, and offer to retry.

## The analogy

A friend reading you a letter over the phone. You could wait until they've read it all to themselves and then hear a summary, or hear each sentence as they read it. The letter takes the same time; one way you're listening from the first line.

## Check yourself

#flashcards/llm

Streaming is turned on. What gets faster?::The time to first token, since words show as soon as they exist. Sooner, not faster.

The user leaves the chat screen mid-answer. Why cancel the stream?::Every generated token costs money and battery, even if nobody reads it. Unread tokens are still paid for.

What's the difference between time to first token and total time?::Time to first token is when the answer starts, while total time is when it ends. Start vs end.

## Sources

- [Anthropic: Streaming messages](https://docs.anthropic.com/en/docs/build-with-claude/streaming) ("When creating a Message, you can set \"stream\": true to incrementally stream the response using server-sent events (SSE).")
- [Anthropic: Glossary, TTFT](https://docs.anthropic.com/en/docs/about-claude/glossary) ("Time to first token (TTFT) is a performance metric that measures the time it takes for a language model to generate the first token of its output after receiving a prompt. It is an important indicator of the model's responsiveness")
