# Trust, identity and access

## Pair once, remember deliberately

Pairing establishes security material for a connection. Bonding retains keys so the same peers can establish trusted connections later. The pairing association model depends on device capabilities and security requirements. Just Works can support encryption but supplies no user-verified authentication of the peer during pairing.

### Worked example

Two devices with suitable displays can ask their users to confirm a matching number. A screenless sensor might offer no comparable confirmation. For an application controlling access, decide how to establish that this physical sensor is the intended one and where authorization is enforced.

### Try it

After the phone forgets a bond but the peripheral retains its old keys, what should a support procedure check?

### Compare your answer

Check bond state on both peers and provide a deliberate reset and re-pairing path. Treat creating a new bond and granting application access as separate decisions.

[Source · Bluetooth Core Specification · Security Manager](https://www.bluetooth.com/wp-content/uploads/Files/Specification/HTML/Core-54/out/en/index-en.html)

## Ask the OS for the operation you need

Android apps targeting Android 12 or later generally request nearby-device runtime permissions corresponding to discovery and communication. BLUETOOTH_SCAN covers scanning and BLUETOOTH_CONNECT covers communication with paired devices; advertising has its own permission. Older Android versions use a different permission model. Check current grants at the feature boundary.

### Worked example

A user wants to find a strap, grants scan access, then declines the permission needed to connect. The screen can explain the second operation and preserve the selected device independently of connection state. Permission denial should end that attempt without pretending the peripheral disappeared.

### Try it

Your app only connects to an already known device and does not advertise. Should the onboarding flow request advertising permission?

### Compare your answer

Request the operations the feature actually uses. Re-evaluate the scan and connection requirements for the supported OS and target versions, and leave advertising out of a client-only flow.

[Source · Android Developers · Bluetooth permissions](https://developer.android.com/develop/connectivity/bluetooth/bt-permissions)

## Make Bluetooth permission intelligible on iOS

For modern iOS apps using Bluetooth, supply the required Bluetooth purpose string in the application bundle. Explain the concrete reason for access. The displayed system authorization state, the radio’s power state and the remote device’s availability answer different questions.

### Worked example

“Connect to your heart-rate strap during a workout” describes an action the user recognizes. With access denied, show how to revisit the decision. With Bluetooth powered off, guide the user toward enabling it. Only after the app is authorized and Bluetooth is available does an empty scan describe discovery.

### Try it

A screen shows “No sensors nearby” before the user has answered the permission prompt. What state should it represent instead?

### Compare your answer

Represent authorization as pending and defer the empty-results message until a permitted scan has actually run. If access was denied, make that state actionable.

[Source · Apple · NSBluetoothAlwaysUsageDescription](https://developer.apple.com/documentation/bundleresources/information-property-list/nsbluetoothalwaysusagedescription)

[[Final project]]

[[Course map]]