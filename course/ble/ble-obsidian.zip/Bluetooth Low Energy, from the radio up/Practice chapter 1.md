# Size, speed and recovery

## How much of a notification is yours?

ATT, the Attribute Protocol, carries operations on attribute handles. An ATT maximum transmission unit (MTU) limits the entire ATT message. For a normal single-handle notification, one opcode byte and two handle bytes precede the value. The default LE ATT MTU of 23 therefore leaves up to 20 bytes for this value. Other operations have different headers.

### Worked example

A sensor wants to send 48 application bytes. At MTU 23 it takes at least three such notifications. If each part also carries a two-byte application sequence number, the usable part size becomes 18. An agreed MTU of 64 has room for all 48 bytes and the sequence number in one notification.

### Try it

You negotiated MTU 64 and need to send 122 measurement bytes with a two-byte part header in every notification. How many notifications?

### Compare your answer

Each carries at most 64 − 3 − 2 = 59 measurement bytes. Send three parts of 59, 59 and 4. Add a message identity if multiple messages can overlap.

[Source · Bluetooth Core Specification · Attribute Protocol](https://www.bluetooth.com/wp-content/uploads/Files/Specification/HTML/Core-54/out/en/index-en.html)

## Separate packet length from radio speed

The ATT MTU governs the upper-layer message. Data Length Extension changes how much data the link layer can carry per packet. The 2M PHY changes the symbol rate over the radio. Negotiating a larger ATT message can reduce application framing even when the controller still fragments it across several link packets. Both devices must support the selected link features.

### Worked example

Assume measured delivery of four notifications per 30 ms event, with 20 useful bytes each. Application throughput is 80 / 0.030 ≈ 2,667 bytes/s. The event interval, packets actually delivered, retransmissions and useful payload determine the observed rate. Selecting a faster PHY alone does not tell you those values.

### Try it

With 100 usable bytes per delivered notification, two notifications per event, and a 50 ms interval, estimate useful throughput and the ideal transfer time for 40,000 bytes.

### Compare your answer

200 / 0.050 = 4,000 bytes/s, giving ten seconds before setup and other delays. Verify the delivered bytes over elapsed wall time on both devices.

[Source · Bluetooth Core Specification · LE radio and Link Layer](https://www.bluetooth.com/wp-content/uploads/Files/Specification/HTML/Core-54/out/en/index-en.html)

## Give every asynchronous operation a completion point

Use a per-connection queue for GATT procedures that expect a callback. Starting a characteristic read or descriptor write asks the stack to begin work; immediate acceptance does not tell you that the remote operation succeeded. Advance the queue after the matching terminal callback. Handle an immediate rejection separately because no completion may follow.

### Worked example

The queue contains discovery, a descriptor write and a read of a separate readable battery-level characteristic. Discover on this connection, select the returned handles, then write the subscription descriptor. If its callback reports failure, record that subscription failed. Issuing all operations at once makes it difficult to associate an outcome with the step that needed it.

### Try it

A callback from a discarded connection arrives after a reconnect. Should it release the new connection’s next operation?

### Compare your answer

No. Associate callbacks with a connection instance and current operation. End the old queue and ignore its late completion. Start the new session with fresh discovery where required.

[Source · Android BluetoothGatt API](https://developer.android.com/reference/android/bluetooth/BluetoothGatt)

## Diagnose a generic GATT error

Android stacks have used decimal 133 (hexadecimal 0x85) as a generic GATT error. It identifies a failed operation without identifying a physical cause. Record the last successful transition, operation, callback, elapsed time, connection instance and permission state. A single number cannot distinguish a missing peripheral from an interrupted connection procedure.

### Worked example

Run A fails during connection, before any service discovery. Run B connects and discovers services, then fails writing a descriptor. Investigate different boundaries even if both present 133. End the failed session, release the connection resource and allow a bounded fresh attempt when the device is still wanted.

### Try it

A tester wants to add an unlimited immediate retry whenever 133 appears. What evidence and policy would improve the diagnosis?

### Compare your answer

Keep separate counts by stage and device pair, measure recovery for a small bounded number of delayed attempts, and stop when the user cancels or prerequisites change. Report the original stage even if a later attempt succeeds.

[Source · Android Bluetooth stack · GATT status definitions](https://android.googlesource.com/platform/system/bt/+/1f118853c585488577a1d929014973a6a9a04064/stack/include/gatt_api.h)

[[Practice chapter 2|Trust, identity and access]]

[[Course map]]