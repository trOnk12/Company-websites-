---
course: "Bluetooth Low Energy, from the radio up"
puzzle: 4
source: https://pachulski.dev/course/ble/04-dont-ask-get-told
tags: [course/ble]
---

# Don't ask, get told

> [!summary] The idea to keep
> A notification is the server sending a characteristic's value by itself when it changes. It only starts after the client writes the CCCD descriptor on the device. On Android, setCharacteristicNotification() alone isn't enough: you also writeDescriptor() the CCCD.

**Builds on:** [[03 The filing cabinet]]

## The problem

In puzzle 3, the phone read the battery level by asking: "read 2A19". Imagine showing a live heart rate the same way: the phone would have to ask at every connection event. That's a request and an answer each time, even when the value didn't change, and each read waits for a meeting to ask and for the answer (puzzle 3), so the value can be old by the time it arrives. Can the strap just tell the phone when the value changes? For the heart rate, that's the only way the standard allows.

## See it

![Don't ask, get told](https://pachulski.dev/course/ble/gifs/notify.gif)

Step through it: https://pachulski.dev/course/ble/04-dont-ask-get-told

## The building block

Yes: that's a **notification**. The GATT server sends a characteristic's new value by itself when the server queues an update and the link can carry it, without a separate read request. The meetings still happen; what's saved is the request and answer packets, and delivery still depends on the sensor, radio schedule and available capacity.

But the strap doesn't notify everyone by default. A characteristic can carry extra settings called **descriptors**. Descriptors have UUIDs too, and a client can write them. One of them, the **CCCD** (Client Characteristic Configuration Descriptor, UUID 2902), holds a switch per client: bit 0 on means "notify me". The client turns notifications on by writing that descriptor on the device.

On Android, your app gets a `BluetoothGatt` object when it connects: Android's handle for that connection's GATT client. After service discovery you find the characteristic by its UUIDs. Then turning notifications on takes two separate steps: `setCharacteristicNotification()` on the phone, and `writeDescriptor()` to the strap. A short UUID like 2902 is written in full as Bluetooth's standard base number with those four digits in it, which is the long string in the code.

```kotlin
val characteristic = gatt.getService(HEART_RATE).getCharacteristic(MEASUREMENT)   // HEART_RATE and MEASUREMENT: your UUID constants
gatt.setCharacteristicNotification(characteristic, true)   // 1. on the phone: pass these to my app
val cccd = characteristic.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))   // 2902, written in full
gatt.writeDescriptor(cccd, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)   // 2. on the strap: bit 0 on
```

`setCharacteristicNotification()` only tells your own phone to hand this characteristic's notifications to your app. It sends nothing to the strap. `writeDescriptor()` is what flips the switch on the strap. Skip it, and the strap never sends a thing: the classic "connected, but no data" bug.

## The analogy

Instead of phoning the newsroom every hour to ask "anything new?", you subscribe. But the subscription has two halves: you tell your own mailbox to accept the paper, and you send the form to the newspaper. Do only the first, and your mailbox waits forever.

## Check yourself

#flashcards/ble

Your app calls `setCharacteristicNotification(characteristic, true)` and nothing else. The heart rate changes. What arrives?::Nothing: the CCCD on the strap was never written. Two steps: your phone, and the switch on the strap.

Why are notifications cheaper than reading again and again?::Because it sends one packet only when the value changes, with no request first. No request, and nothing sent when nothing changed.

What's the difference between a characteristic and a descriptor?::A characteristic holds a value, while a descriptor is a setting attached to it. Value vs a setting about that value.

## Sources

- [Bluetooth Core Specification 5.4, Vol 3, Part G: GATT](https://www.bluetooth.com/wp-content/uploads/Files/Specification/HTML/Core-54/out/en/host/generic-attribute-profile--gatt-.html) (Client Characteristic Configuration: "Bit 0: Notification. The Characteristic Value shall be notified"; the descriptor value is kept per client)
- [Bluetooth SIG assigned numbers: descriptors](https://bitbucket.org/bluetooth-SIG/public/src/main/assigned_numbers/uuids/descriptors.yaml) (`0x2902`: Client Characteristic Configuration)
- [Android Developers: Transfer BLE data](https://developer.android.com/develop/connectivity/bluetooth/ble/transfer-ble-data) (the sample calls `setCharacteristicNotification()` and then writes the descriptor with `ENABLE_NOTIFICATION_VALUE`)
- [Bluetooth SIG: Heart Rate Service 1.0](https://www.bluetooth.com/wp-content/uploads/Files/Specification/HTML/HRS_v1.0/out/en/index-en.html) (characteristic table: "Heart Rate Measurement / M / Notify / None", no Read property)
