---
source: https://pachulski.dev/course/ble/
tags: [course/ble]
---

# Bluetooth Low Energy, from the radio up

Why a heart-rate strap lasts a year on a coin battery, how your phone finds it, and why your notifications never arrive. BLE's strange rules all come from one idea; this course builds them from it, one small puzzle at a time.

From [pachulski.dev](https://pachulski.dev/course/ble/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: Over the air

How a device that sleeps almost all the time can still be found, connected to, and heard.

- [[00 Months on a coin battery]]: A heart-rate strap runs for months on a battery the size of a coin. Here's the one idea that makes that possible, and that every later puzzle follows from.
- [[01 Shouting into the room]]: In puzzle 0, the strap's radio slept almost all the time. Here's how a device that's nearly always asleep still gets found.
- [[02 A timetable for two]]: In puzzle 1, the phone found the strap by listening to its advertisements. Now two devices that both sleep need to talk again and again, without missing each other.
- [[03 The filing cabinet]]: In puzzle 2, the phone and the strap met on a timetable. Now they need to agree on what the data is: which value is the heart rate, and which is the battery level.
- [[04 Don't ask, get told]]: In puzzle 3, the phone read the battery level by asking for it. A live heart rate can't work that way: asking again and again wastes radio time, and the standard doesn't even allow reading it. Here's how the strap tells the phone instead, and the one step everyone forgets.

## Coming next

- Module 2: Making it fast and reliable (coming): Why only 20 bytes per packet (MTU, Data Length Extension, 2M PHY), throughput math, Android's one-operation-at-a-time rule and status 133.
- Module 3: Trust and permissions (coming): Pairing and bonding, why "Just Works" doesn't stop a man in the middle, Android 12+ and iOS permissions.

[[Glossary]]
