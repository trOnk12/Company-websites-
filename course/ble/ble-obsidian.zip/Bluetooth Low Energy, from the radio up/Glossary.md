# Glossary: Bluetooth Low Energy, from the radio up

Every word the course teaches, in the order it does. #flashcards/ble/words

BLE::Bluetooth Low Energy: the kind of Bluetooth built for tiny batteries. (taught in [[00 Months on a coin battery]])

radio::The part of a device that sends and listens over the air. (taught in [[00 Months on a coin battery]])

advertising::Sending short packets that say "I'm here", over and over, for anyone listening. (taught in [[01 Shouting into the room]])

advertising interval::The time between two advertisements, plus a small random delay. (taught in [[01 Shouting into the room]])

channel::One of 40 narrow slices of the airwaves BLE uses; 3 are for advertising. (taught in [[01 Shouting into the room]])

packet::One short burst of data sent over the air. (taught in [[01 Shouting into the room]])

scanning::Listening on the advertising channels for advertisements. (taught in [[01 Shouting into the room]])

central::The side of a connection that sets the timetable: usually the phone. (taught in [[02 A timetable for two]])

connection::Two devices that agreed to meet on a timetable to exchange data. (taught in [[02 A timetable for two]])

connection event::One meeting in a connection: both wake, exchange packets, sleep. (taught in [[02 A timetable for two]])

connection interval::How often the two sides of a connection meet: 7.5 ms to 4 s. (taught in [[02 A timetable for two]])

peripheral::The other side of a connection: usually the small device. (taught in [[02 A timetable for two]])

characteristic::One value inside a service, that a client can read, write or be told about. (taught in [[03 The filing cabinet]])

GATT::The way a BLE device organizes its data: services holding characteristics. (taught in [[03 The filing cabinet]])

GATT client::The side that reads and writes it (usually the phone). (taught in [[03 The filing cabinet]])

GATT server::The side that holds the data (usually the small device). (taught in [[03 The filing cabinet]])

service::A group of related values, like Heart Rate or Battery. (taught in [[03 The filing cabinet]])

UUID::The number that names a service or characteristic. (taught in [[03 The filing cabinet]])

BluetoothGatt::Android's object for one connection's GATT client. (taught in [[04 Don't ask, get told]])

CCCD::The descriptor that switches notifications on or off for one client. (taught in [[04 Don't ask, get told]])

descriptor::An extra setting attached to a characteristic. (taught in [[04 Don't ask, get told]])

notification::A value the server sends by itself when it changes, without a request. (taught in [[04 Don't ask, get told]])

setCharacteristicNotification()::Android: route this characteristic's notifications to your app. (taught in [[04 Don't ask, get told]])

writeDescriptor()::Android: write a descriptor on the device, such as the CCCD. (taught in [[04 Don't ask, get told]])
