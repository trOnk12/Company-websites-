---
source: https://pachulski.dev/course/ios/
tags: [course/ios]
---

# iOS for Android developers

You already know Android's building blocks. This course maps each one onto its iOS twin, and shows exactly where the twins differ: the app that freezes instead of stopping, the run loop, queues instead of handlers, the main actor, and memory without a garbage collector.

From [pachulski.dev](https://pachulski.dev/course/ios/), free. Each note builds on the ones it links to: open the graph view to see the building blocks. The "Check yourself" lines are flashcards for the Spaced Repetition plugin.

## Module 1: The Android blocks, on iOS

Lifecycle, threads, queues, concurrency and memory: what's the same, and what isn't.

- [[00 Frozen, not stopped]]: On Android, an app in the background keeps its process, and its threads can keep running. On iOS, a few seconds after the user leaves, your app stops running any code at all. Here's what that means for your work.
- [[01 The run loop is your Looper]]: On Android, the main thread runs a Looper: take a message from the queue, run it, repeat. iOS has the same idea under another name. Here it is, and the one way it differs.
- [[02 Queues, not handlers]]: On Android, you post work to the main thread with a Handler and run slow work on another thread or a coroutine on another thread. iOS has one system for both. Here it is.
- [[03 The main actor]]: In puzzle 2, you moved work between queues by hand. Kotlin did the same job with coroutines and withContext. Swift has its own version, with one idea Kotlin doesn't have built in.
- [[04 Counting, not collecting]]: On Android, objects nothing uses anymore are found and freed for you, cycles included. Swift doesn't work that way. Here's what it does instead, and the leak it can't see.

## Coming next

- Module 2: Screens and the system (coming): Scenes and windows, SwiftUI's rendering model vs UIKit, background execution and Jetsam, launch time.
- Module 3: Shipping (coming): Xcode builds, signing, frameworks and Swift packages, profiling with Instruments, Swift 6 data-race safety.

[[Glossary]]
