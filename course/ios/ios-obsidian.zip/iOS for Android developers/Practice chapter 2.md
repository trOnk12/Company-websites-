# Screens and the system

## Restore windows independently

A scene manages one instance of the user interface; a window presents content for that scene. Scene activation describes whether that particular interface can interact. Sharing the app process gives scenes access to common resources while leaving each one's navigation independent.

### Worked example

Scene A shows note 17; scene B shows settings. A backgrounds while B remains active. Save A's restoration identity with its scene, then rebuild it from note 17 if the scene reconnects later.

### Try it

Should A entering background unconditionally tear down a database connection needed by B?

### Compare your answer

Coordinate process-wide resources across users. Treat A's lifecycle as the end of A's immediate interaction, not proof that all scenes stopped.

[Source · Apple · UIKit scenes](https://developer.apple.com/documentation/uikit/scenes)

## Compare a view description with a controller

SwiftUI's body produces a description from current state. Updating state can cause SwiftUI to reevaluate affected view descriptions while preserving storage associated with view identity. A UIKit view controller instead owns and coordinates a view hierarchy and receives explicit lifecycle callbacks.

### Worked example

A counter in SwiftUI stores its value with @State. A button changes the value and a Text reads it during body evaluation. In UIKit, an action changes the model and explicitly refreshes a label or uses a binding mechanism. UIKit viewDidLoad concerns loading the view hierarchy; it is not called for every value change.

### Try it

Why can a network request launched unconditionally while computing body issue several copies?

### Compare your answer

SwiftUI may reevaluate body multiple times. Attach work to an appropriate lifecycle-aware task or model, give it a stable identity and handle cancellation.

[Source · Apple · Managing user interface state](https://developer.apple.com/documentation/swiftui/managing-user-interface-state)

## Choose a background execution strategy

Background execution is granted for particular purposes under system control. A short finishing task asks for time to complete work already in progress. Scheduled background tasks run when the system decides conditions are suitable. A background URL session is intended for supported transfers.

### Worked example

The user starts uploading a large attachment and leaves. Persist its local identity and use a suitable background transfer mechanism. On a later callback reconnect the transfer result with that identity. Do not keep success only inside the old view controller.

### Try it

A periodic refresh was requested for 09:00. Can the app promise it finished at exactly 09:00?

### Compare your answer

No. Treat the schedule as an opportunity, persist the last successful update and expose data age. Handle expiration without losing the pending work.

[Source · Apple · Choosing Background Strategies for Your App](https://developer.apple.com/documentation/backgroundtasks/choosing-background-strategies-for-your-app)

## Interpret a jetsam report

Under memory pressure the system may terminate a process. A jetsam report describes memory conditions and the terminated process. A relaunch with missing volatile state is a symptom, not by itself proof of a particular crash or a reference cycle.

### Worked example

An image editor disappears under pressure. Match its process and termination reason in the jetsam report. Reproduce the image workflow and inspect memory growth while decoding, rendering and releasing images. Persist edits during normal operation.

### Try it

Does receiving a memory warning guarantee enough time to save every open document before termination?

### Compare your answer

No. Reduce expendable memory when possible and persist meaningful user changes before termination becomes imminent.

[Source · Apple · Identifying high-memory use with jetsam event reports](https://developer.apple.com/documentation/xcode/identifying-high-memory-use-with-jetsam-event-reports)

## Measure launch through the first useful interaction

Launch includes loading the executable and dependencies, application initialization and drawing the first content. Work before the first frame can delay display; moving work after it can still delay the first useful interaction. Measure both boundaries on comparable launches.

### Worked example

A navigation shell appears after 320 ms and stored notes appear at 870 ms. Deferring a 150 ms synchronous index build may advance the first frame while leaving the list unusable until the same data arrives. Track when the user can open the first note.

### Try it

The shell is faster but tapping a row freezes for 180 ms. What do you measure next?

### Compare your answer

Trace the tap and the main thread during the first interaction. Distinguish work removed from startup from work merely shifted onto the critical interaction.

[Source · Apple · Reducing your app’s launch time](https://developer.apple.com/documentation/xcode/reducing-your-app-s-launch-time)

[[Practice chapter 3|Build, distribute and diagnose]]

[[Course map]]