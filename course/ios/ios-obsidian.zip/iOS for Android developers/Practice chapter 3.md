# Build, distribute and diagnose

## Trace a target through the build graph

An Xcode target describes a product and its build settings, source files and dependencies. A scheme selects targets and configurations for actions such as running or archiving. Compiling source produces inputs for linking; copying resources and signing affect the final bundle.

### Worked example

A Debug simulator run succeeds, but a Release archive misses a JSON file. Check target membership, copy-resource phases and configuration-dependent settings in the actual archive. Successfully compiling a reference to a resource name says nothing about whether the resource was bundled.

### Try it

Changing a library rebuilds unexpectedly many targets. What evidence do you inspect?

### Compare your answer

Inspect the build report, dependency graph, changed interfaces and script inputs or outputs. Compare incremental builds with the same configuration before reorganizing modules.

[Source · Apple · Build system](https://developer.apple.com/documentation/xcode/build-system)

## Explain why a signed archive may fail distribution

Code signing binds code to a signing identity; provisioning for a distribution route governs which app identity and capabilities are allowed. Development, testing and distribution use different conditions. Inspect the archive and its entitlements when the failing path differs from a simulator run.

### Worked example

A push-enabled app runs in Simulator but its distribution archive fails entitlement validation. Compare the app identifier and capabilities configured for the target with the entitlements authorized for the signing route. Build a fresh archive and validate it again.

### Try it

Would changing Swift source fix a mismatch between an enabled entitlement and the selected provisioning profile?

### Compare your answer

Correct the capability and signing configuration and validate the resulting signed artifact. A source change that happens to trigger a rebuild does not establish the cause.

[Source · Apple · Distributing your app for beta testing and releases](https://developer.apple.com/documentation/xcode/distributing-your-app-for-beta-testing-and-releases)

## Separate dependency delivery from its linked product

A Swift package describes products, targets and dependencies. Xcode resolves package versions and builds the chosen product. A framework bundles a module and related resources or code. A package can expose a library or deliver a binary framework, so packaging and dependency resolution answer different questions.

### Worked example

An app adds a package and selects its Core library product for the app target. The project may resolve the package even if the target never links that product. Start with the failing target's product linkage when an import fails only in an extension.

### Try it

A clean machine uses a different dependency revision. What input would you compare first?

### Compare your answer

Compare package constraints and the resolved versions used by the two builds. Then verify the target, platform and destination support the same product.

[Source · Apple · Adding package dependencies to your app](https://developer.apple.com/documentation/xcode/adding-package-dependencies-to-your-app)

## Distinguish CPU samples from elapsed time in Instruments

Time Profiler samples executing stacks. More samples in a function can indicate CPU cost, while a long wall-clock interval may include time waiting. Use an interval around one reproducible interaction and compare allocations or other instruments when CPU alone cannot explain the delay.

### Worked example

Opening a gallery takes 700 ms. The main thread has 60 ms of decode samples but spends a long interval waiting for a storage read. A faster decoder can address the measured CPU portion; trace the separate wait before estimating the overall saving.

### Try it

One profile includes initial import of thumbnails and the next uses a warm cache. Can you attribute the whole improvement to the code change?

### Compare your answer

Repeat comparable cold and warm cases separately. Keep device, dataset, build and measurement boundary consistent, then inspect the remaining wait or hot stack.

[Source · Apple · Improving your app’s performance](https://developer.apple.com/documentation/xcode/improving-your-app-s-performance)

## Make the owner of mutable state explicit in Swift 6

Swift's data-race safety checks use isolation and transfer rules to limit unsafe simultaneous access. An actor serializes access to its isolated state. Sendable describes values suitable for crossing concurrency domains under the applicable rules. Suspension allows other work to enter an actor between two segments.

### Worked example

An Inventory actor checks stock == 1, awaits an external confirmation, then decrements. Another task can enter during the await and observe the same stock. Reserve the right inside one synchronous actor-isolated step and define how failure releases it.

### Try it

If the compiler accepts the program, can two customers still receive an invalid business outcome?

### Compare your answer

Yes. Type-checked isolation addresses data races. An invariant spanning a suspension or an external system still needs a state-transition design and failure tests.

[Source · Swift · Data race safety](https://www.swift.org/migration/documentation/swift-6-concurrency-migration-guide/dataracesafety/)

[[Final project]]

[[Course map]]