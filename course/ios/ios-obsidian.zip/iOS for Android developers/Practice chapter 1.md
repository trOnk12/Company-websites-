# Swift and the app’s front door

## Read a nullable Swift value

Swift's let binds a constant and var permits reassignment. An optional explicitly represents either a wrapped value or its absence. Unwrap it before using a nonoptional operation. A forced unwrap transfers the missing-value check to a runtime trap.

### Worked example

A route contains a note ID as text. Int("17") yields an optional containing 17. Int("river") yields nil. Use guard let id = Int(raw) else { return } before loading the note, and decide how the screen presents an invalid route.

### Try it

Is an empty note list the same state as failing to parse the requested ID?

### Compare your answer

No. Empty is a valid collection value. A missing or invalid route is a different input outcome and should be handled at the navigation boundary.

[Source · The Swift Programming Language · The Basics](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/)

## Follow a struct copy and a class reference

Swift structures have value semantics: changing a copied value does not change the original value. Classes have reference semantics and can be shared by multiple variables. A struct can contain a reference property, in which case copying the struct copies that reference as part of its value.

### Worked example

With struct Draft { var title: String }, set b = a, then b.title = "Lake". The title of a stays River. If Draft is a class and both variables point to the same instance, mutating b.title is visible through a.

### Try it

A struct stores a class-based Editor. After copying the struct, do both copies see a change made to that same Editor?

### Compare your answer

Yes. The copied properties refer to one Editor instance. Use an independent value representation or intentionally create a new editor when isolation is required.

[Source · The Swift Programming Language · Structures and Classes](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/classesandstructures/)

## Start an app and identify a scene

The @main App type is the entry point for a SwiftUI app. Its body describes scenes, and a WindowGroup can host separate instances of a window's content. A process may own several scene sessions with different selections and lifecycle states.

### Worked example

A notes app's WindowGroup opens a root list. One window edits note 17 and another edits 29. Both can share the persisted note repository while keeping their navigation selection attached to the individual scene.

### Try it

A single global selectedNote changes both windows when one user navigates. What should move?

### Compare your answer

Move selection to scene- or view-owned state. Keep genuinely shared data, such as saved notes, in a separate shared model.

[Source · Apple · SwiftUI App](https://developer.apple.com/documentation/swiftui/app)

## Separate a Task from an awaited call

An async function may suspend. Calling it with await does not by itself start independent concurrent work or move CPU-heavy code off an actor. Task creates unstructured work with a handle and can inherit the surrounding actor context. Actor isolation governs access to mutable state.

### Worked example

A main-actor action creates Task { await refresh() }. When refresh awaits network data other main-actor work may proceed. Synchronously decoding a huge document on that same actor can still block input. Identify the executor or isolation of each expensive step.

### Try it

Two taps start independent refreshes. Why can an older response still replace a newer one despite main-actor writes?

### Compare your answer

Serialization of individual state updates does not impose request order across suspension. Cancel superseded work or validate an operation generation before publishing it.

[Source · The Swift Programming Language · Concurrency](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/concurrency/)

[[Practice chapter 2|Screens and the system]]

[[Course map]]