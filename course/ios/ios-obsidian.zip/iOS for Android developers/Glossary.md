# Glossary: iOS for Android developers

Every word the course teaches, in the order it does. #flashcards/ios/words

active::In front and receiving touches. (taught in [[00 Frozen, not stopped]])

app state::Where an app is in its life: not running, inactive, active, background or suspended. (taught in [[00 Frozen, not stopped]])

suspended::Still in memory, but running no code at all. (taught in [[00 Frozen, not stopped]])

UIKit::Apple's framework that runs an iOS app's screens and tells it about its state. (taught in [[00 Frozen, not stopped]])

run loop::A thread's event loop: wait for work, handle it, sleep when there's none. iOS's Looper. (taught in [[01 The run loop is your Looper]])

concurrent::A queue that can run several tasks at the same time. (taught in [[02 Queues, not handlers]])

dispatch queue::A first-in, first-out line of tasks that GCD runs on its threads. (taught in [[02 Queues, not handlers]])

DispatchQueue.main.async::Puts a task on the main queue: iOS's handler.post. (taught in [[02 Queues, not handlers]])

GCD::Grand Central Dispatch: Apple's system of queues that run your tasks on threads it manages. (taught in [[02 Queues, not handlers]])

serial::A queue that runs one task at a time, in order. (taught in [[02 Queues, not handlers]])

actor::An object that lets only one task at a time touch its data. (taught in [[03 The main actor]])

async function::A Swift function that can give up its thread while it waits: Swift's suspend. (taught in [[03 The main actor]])

await::Marks the point where an async function may give up its thread. (taught in [[03 The main actor]])

main actor::The actor that protects all UI data: iOS's Dispatchers.Main. (taught in [[03 The main actor]])

ARC::Automatic Reference Counting: frees an object the moment nothing refers to it. (taught in [[04 Counting, not collecting]])

strong reference::A reference that keeps an object alive. (taught in [[04 Counting, not collecting]])

strong reference cycle::Two objects holding strong references to each other, so neither is ever freed. (taught in [[04 Counting, not collecting]])

weak reference::A reference that doesn't keep the object alive, and becomes nil when it's freed. (taught in [[04 Counting, not collecting]])
